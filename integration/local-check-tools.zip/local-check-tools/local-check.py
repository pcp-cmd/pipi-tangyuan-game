#!/usr/bin/env python3
"""Run your own project locally and write a source-bound, self-reported check.

This is not an upload evaluator, sandbox, signed review, or learning certificate.
Only use it with your own registered learning projects. Standard library only.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import signal
import subprocess
import sys
import tempfile
import threading
import time
import unittest

TOOL = Path(__file__).resolve()
PROFILES = TOOL.with_name("local-check-profiles.json")
REPORT_NAME = "LOCAL-CHECK.json"
MAX_REPORT = 64 * 1024
MAX_TESTS = 256
IGNORED = {".git", ".venv", "venv", "node_modules", "__pycache__"}


def load_profiles():
    return json.loads(PROFILES.read_text(encoding="utf-8"))["tasks"]


def input_allowed(name, profile):
    return name != REPORT_NAME and not name.startswith(("work/", "evidence/")) and name not in {
        "CHECKPOINT.json", "RESULT.json", "MANIFEST.json"} and name.endswith((".py", ".json", ".csv")) and (
        name in profile["allowedFiles"] or re.fullmatch(r"tests/test_[A-Za-z0-9_-]{1,60}\.py", name) is not None)


def snapshot(root, profile):
    rows = []
    for base, directories, files in os.walk(root, followlinks=False):
        directories[:] = sorted(name for name in directories if name not in IGNORED)
        for name in sorted(files):
            path = Path(base) / name
            relative = path.relative_to(root).as_posix()
            if not input_allowed(relative, profile):
                continue
            if path.is_symlink() or any(part.is_symlink() for part in path.parents if part != root):
                raise ValueError("Do not use linked input files: " + relative)
            if path.stat().st_size > MAX_REPORT:
                raise ValueError("Input exceeds 64 KiB: " + relative)
            raw = path.read_bytes()
            if raw.startswith(b'\xef\xbb\xbf'):
                raise ValueError("Save this file as UTF-8 without BOM, then rerun: " + relative)
            content = raw.decode("utf-8", errors="strict")
            if "\0" in content or "\ufffd" in content:
                raise ValueError("Input must be readable UTF-8 text: " + relative)
            rows.append({"path": relative, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()})
    rows.sort(key=lambda row: row["path"])
    if len(rows) > 96 or sum(row["bytes"] for row in rows) > 512 * 1024:
        raise ValueError("Check inputs exceed 96 files or 512 KiB; use a dedicated project folder.")
    return rows


class RecordedResult(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.entries = {}
        self.message_budget = 6000

    def record(self, test, outcome, message=""):
        ident = test.id()
        if len(ident) > 240:
            ident = ident[:220] + "#" + hashlib.sha256(ident.encode()).hexdigest()[:16]
        prior = self.entries.get(ident)
        if prior and prior["outcome"] in {"failed", "error", "unexpected-success"} and outcome == "passed":
            return
        message = message.replace(str(Path.cwd()), "<project>")
        message = message[-min(700, self.message_budget):] if self.message_budget else ""
        self.message_budget -= len(message)
        self.entries[ident] = {"id": ident, "outcome": outcome, "message": message}

    def startTest(self, test):
        super().startTest(test)
        self.record(test, "incomplete")

    def addSuccess(self, test):
        super().addSuccess(test)
        self.record(test, "passed")

    def addFailure(self, test, err):
        super().addFailure(test, err)
        self.record(test, "failed", self._exc_info_to_string(err, test))

    def addError(self, test, err):
        super().addError(test, err)
        self.record(test, "error", self._exc_info_to_string(err, test))

    def addSkip(self, test, reason):
        super().addSkip(test, reason)
        self.record(test, "skipped", reason)

    def addExpectedFailure(self, test, err):
        super().addExpectedFailure(test, err)
        self.record(test, "expected-failure", self._exc_info_to_string(err, test))

    def addUnexpectedSuccess(self, test):
        super().addUnexpectedSuccess(test)
        self.record(test, "unexpected-success")

    def addSubTest(self, test, subtest, err):
        super().addSubTest(test, subtest, err)
        if err:
            state = "failed" if issubclass(err[0], test.failureException) else "error"
            self.record(test, state, str(subtest) + "\n" + self._exc_info_to_string(err, test))


def run_worker(task_id, project, result_path):
    profile = load_profiles()[task_id]
    root = Path(project).resolve()
    os.chdir(root)
    sys.path[:0] = [str(root), str(root / "tests")]
    loader = unittest.TestLoader()
    suite = loader.discover(str(root / "tests"), pattern="test_*.py",
                            top_level_dir=str(root) if profile["topLevel"] == "." else None)
    discovered = suite.countTestCases()
    if discovered > MAX_TESTS:
        raise ValueError("Too many test cases for one local report (maximum 256).")
    result = unittest.TextTestRunner(verbosity=2, resultclass=RecordedResult).run(suite)
    payload = {"discovered": discovered, "tests": list(result.entries.values())}
    Path(result_path).write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    if discovered == 0:
        return 3
    return 0 if result.wasSuccessful() else 1


class BoundedPipe:
    def __init__(self, pipe, limit=8192):
        self.pipe, self.limit, self.value, self.truncated = pipe, limit, bytearray(), False
        self.thread = threading.Thread(target=self.read, daemon=True)
        self.thread.start()

    def read(self):
        try:
            while True:
                data = self.pipe.read(4096)
                if not data:
                    break
                available = self.limit - len(self.value)
                self.value.extend(data[:available])
                if len(data) > available:
                    self.truncated = True
        finally:
            self.pipe.close()

    def text(self):
        self.thread.join(timeout=2)
        return bytes(self.value).decode("utf-8", errors="replace")


def stop_tree(process):
    if os.name == "nt":
        try:
            subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5, check=False)
        except (OSError, subprocess.TimeoutExpired):
            process.kill()
    else:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)


def write_report(path, report):
    raw = (json.dumps(report, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8")
    if len(raw) > MAX_REPORT:
        raise ValueError("Report exceeds 64 KiB; reduce unusually long test names or failure messages and rerun.")
    with tempfile.NamedTemporaryFile(prefix=".local-check-", suffix=".tmp", dir=path.parent, delete=False) as handle:
        temporary = Path(handle.name)
        handle.write(raw)
    try:
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def main():
    if len(sys.argv) == 5 and sys.argv[1] == "--worker":
        return run_worker(sys.argv[2], sys.argv[3], sys.argv[4])
    profiles = load_profiles()
    parser = argparse.ArgumentParser(description="Run your own project's public unittest checks and write LOCAL-CHECK.json (self-reported, not a trusted review).")
    parser.add_argument("--task", choices=sorted(profiles), required=True)
    parser.add_argument("--project", type=Path, required=True)
    parser.add_argument("--timeout-seconds", type=int, default=60, choices=range(1, 301), metavar="1..300")
    args = parser.parse_args()
    root = args.project.resolve(strict=True)
    if not root.is_dir() or not (root / "tests").is_dir():
        raise ValueError("Choose the dedicated project root containing tests/.")
    profile = profiles[args.task]
    before = snapshot(root, profile)
    paths = {row["path"] for row in before}
    missing = [name for name in profile["requiredFiles"] if input_allowed(name, profile) and name not in paths]
    if missing or not any(re.fullmatch(r"tests/test_[A-Za-z0-9_-]{1,60}\.py", name) for name in paths):
        raise ValueError("Missing required source or a tests/test_*.py file: " + ", ".join(missing))
    started = time.monotonic()
    timed_out, result, diagnostic = False, None, ""
    with tempfile.TemporaryDirectory(prefix="pipi-local-check-") as temporary:
        result_path = Path(temporary) / "worker-result.json"
        environment = dict(os.environ)
        environment["PYTHONUTF8"] = "1"
        environment["PYTHONDONTWRITEBYTECODE"] = "1"
        environment["PYTHONPATH"] = os.pathsep.join([str(root), str(root / "tests")])
        process = subprocess.Popen([sys.executable, "-I", "-B", str(TOOL), "--worker", args.task, str(root), str(result_path)],
                                   cwd=root, env=environment, stdin=subprocess.DEVNULL,
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=os.name != "nt")
        output, errors = BoundedPipe(process.stdout), BoundedPipe(process.stderr)
        try:
            process.wait(timeout=args.timeout_seconds)
        except subprocess.TimeoutExpired:
            timed_out = True
            stop_tree(process)
        stdout, stderr = output.text(), errors.text()
        # A child left holding a pipe is not a completed local check.
        if output.thread.is_alive() or errors.thread.is_alive():
            stop_tree(process)
            timed_out = True
            stdout, stderr = output.text(), errors.text()
        print((stdout + stderr)[-10000:], end="")
        if result_path.exists() and result_path.stat().st_size <= MAX_REPORT:
            try:
                result = json.loads(result_path.read_text(encoding="utf-8"))
            except (ValueError, UnicodeError):
                diagnostic = "The test process produced an unreadable result."
        if result is None and not timed_out:
            diagnostic = diagnostic or "The test process exited without structured results. Read the terminal error and rerun."
    after = snapshot(root, profile)
    before_map = {row["path"]: row for row in before}
    after_map = {row["path"]: row for row in after}
    changed = sorted(name for name in before_map.keys() | after_map.keys() if before_map.get(name) != after_map.get(name))
    report = {
        "schema": "pipi-local-check/v1", "taskId": args.task, "contractRevision": profile["contractRevision"],
        "profileId": profile["profileId"], "createdAt": int(time.time() * 1000),
        "environment": {"python": platform.python_version(), "platform": sys.platform, "toolVersion": "1"},
        "command": profile["command"],
        "process": {"exitCode": process.returncode, "timedOut": timed_out, "durationMs": int((time.monotonic() - started) * 1000),
                    "timeoutSeconds": args.timeout_seconds, "outputTruncated": output.truncated or errors.truncated},
        "inputs": before, "changedPaths": changed, "result": result, "diagnostic": diagnostic,
    }
    write_report(root / REPORT_NAME, report)
    complete = bool(result and result.get("discovered") and len(result.get("tests", [])) == result["discovered"] and
                    all(row.get("outcome") == "passed" for row in result["tests"]))
    success = complete and process.returncode == 0 and not timed_out and not changed
    print("\n" + json.dumps({"report": REPORT_NAME, "selfReportedChecksPassed": success,
                              "inputFiles": len(before), "changedPaths": changed, "trustedReview": False}, ensure_ascii=False))
    return 0 if success else 3 if timed_out else 2


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, UnicodeError) as error:
        print("Local check could not finish: " + str(error), file=sys.stderr)
        raise SystemExit(4)
