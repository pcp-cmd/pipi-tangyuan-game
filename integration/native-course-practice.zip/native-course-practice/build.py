"""Create a redistributable .pyz containing student code, not a Python runtime."""
import argparse
from pathlib import Path
import shutil
import tempfile
import zipapp


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("output", nargs="?", default="stockledger.pyz")
    output = Path(parser.parse_args().output).resolve()
    source = Path(__file__).resolve().parent / "stockledger"
    with tempfile.TemporaryDirectory() as folder:
        target = Path(folder) / "stockledger"
        shutil.copytree(source, target, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
        (Path(folder) / "__main__.py").write_text("from stockledger.cli import main\nraise SystemExit(main())\n", encoding="utf-8")
        zipapp.create_archive(folder, output)
    print(output)


if __name__ == "__main__":
    main()
