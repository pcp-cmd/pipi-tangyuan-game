import unittest
from stockledger.core import parse_quantities, prepare_report


class ParsingTests(unittest.TestCase):
    def test_repeated_and_zero(self):
        self.assertEqual(parse_quantities("item,qty\n灯,2\n灯,3\n绳,0\n"), {"灯": 5, "绳": 0})

    def test_quoting_and_integer_syntax(self):
        text = 'item,qty\r\n"灯,笼", +2 \r\n"多\n行",３\r\n 留白 ,0_4\r\n'
        self.assertEqual(parse_quantities(text), {"灯,笼": 2, "多\n行": 3, " 留白 ": 4})

    def test_header_only(self):
        self.assertEqual(parse_quantities("item,qty\n"), {})

    def test_invalid_inputs(self):
        for text in ["", "qty,item\n2,灯\n", "item,qty,extra\n", "item,qty\n灯\n",
                     "item,qty\n灯,2,多\n", "item,qty\n,2\n", "item,qty\n灯,-1\n",
                     "item,qty\n灯,1.5\n", "item,qty\n灯,no\n", "item,qty\n\n",
                     'item,qty\n"灯"x,2\n', 'item,qty\n"灯,2\n', "item,qty\n  ,2\n"]:
            with self.subTest(text=text), self.assertRaises(ValueError):
                parse_quantities(text)


class DecisionTests(unittest.TestCase):
    def test_complete_deduction_without_mutation(self):
        stock, orders = {"灯": 8, "绳": 3}, {"灯": 5, "纸": 0}
        actual = prepare_report(stock, orders)
        self.assertEqual(actual, {"ready": True, "stock": {"灯": 3, "绳": 3, "纸": 0}, "missing": {}})
        self.assertIs(actual["ready"], True)
        self.assertEqual(stock, {"灯": 8, "绳": 3})
        self.assertEqual(orders, {"灯": 5, "纸": 0})
        actual["stock"]["灯"] = 100
        self.assertEqual(stock["灯"], 8)

    def test_shortage_does_not_partially_deduct(self):
        stock = {"灯": 8}
        result = prepare_report(stock, {"灯": 2, "绳": 3, "水": 1})
        self.assertEqual(result, {"ready": False, "stock": {"灯": 8}, "missing": {"绳": 3, "水": 1}})
        self.assertIs(result["ready"], False)
        result["stock"]["灯"] = 99
        self.assertEqual(stock["灯"], 8)

    def test_empty_order_and_exact_boundary(self):
        self.assertEqual(prepare_report({}, {}), {"ready": True, "stock": {}, "missing": {}})
        self.assertEqual(prepare_report({"灯": 2}, {"灯": 2})["stock"], {"灯": 0})


if __name__ == "__main__":
    unittest.main()
