import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from stockledger.files import build_report

ROOT = Path(__file__).resolve().parents[1]


class DeliveryTests(unittest.TestCase):
    def setUp(self):
        self.workspace = tempfile.TemporaryDirectory()
        self.addCleanup(self.workspace.cleanup)
        self.folder = Path(self.workspace.name)
        self.stock, self.orders, self.report = [self.folder / name for name in ("库存.csv", "订单.csv", "报告.json")]
        self.stock.write_text("item,qty\n灯,8\n", encoding="utf-8")
        self.orders.write_text("item,qty\n灯,3\n", encoding="utf-8")
        self.report.write_bytes("原报告\r\n".encode("utf-8"))

    def test_real_files_and_source_preservation(self):
        before = (self.stock.read_bytes(), self.orders.read_bytes())
        result = build_report(self.stock, self.orders, self.report)
        self.assertEqual(result, {"ready": True, "stock": {"灯": 5}, "missing": {}})
        self.assertIs(result["ready"], True)
        self.assertEqual(json.loads(self.report.read_text(encoding="utf-8")), result)
        self.assertEqual((self.stock.read_bytes(), self.orders.read_bytes()), before)

    def test_invalid_tail_preserves_report(self):
        for bad_path in (self.stock, self.orders):
            original = bad_path.read_bytes()
            bad_path.write_text("item,qty\n灯,3\n坏项,no\n", encoding="utf-8")
            before = self.report.read_bytes()
            with self.assertRaises(ValueError):
                build_report(self.stock, self.orders, self.report)
            self.assertEqual(self.report.read_bytes(), before)
            bad_path.write_bytes(original)

    def test_invalid_csv_quotes_preserve_report_and_inputs(self):
        for bad_path in (self.stock, self.orders):
            original = bad_path.read_bytes()
            for invalid in ['item,qty\n"灯"x,2\n', 'item,qty\n"灯,2\n']:
                with self.subTest(path=bad_path, invalid=invalid):
                    bad_path.write_text(invalid, encoding="utf-8")
                    input_before = bad_path.read_bytes()
                    before = self.report.read_bytes()
                    with self.assertRaises(ValueError):
                        build_report(self.stock, self.orders, self.report)
                    self.assertEqual(self.report.read_bytes(), before)
                    self.assertEqual(bad_path.read_bytes(), input_before)
            bad_path.write_bytes(original)

    def test_module_process_and_bad_data_status(self):
        result = subprocess.run([sys.executable, "-m", "stockledger", str(self.stock), str(self.orders), str(self.report)], cwd=ROOT, text=True, capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(self.report.read_text(encoding="utf-8"))["stock"]["灯"], 5)
        self.orders.write_text("item,qty\n灯,bad\n", encoding="utf-8")
        before = self.report.read_bytes()
        failure = subprocess.run([sys.executable, "-m", "stockledger", str(self.stock), str(self.orders), str(self.report)], cwd=ROOT, text=True, capture_output=True)
        self.assertEqual(failure.returncode, 2)
        self.assertTrue(failure.stderr.strip())
        self.assertEqual(self.report.read_bytes(), before)

    def test_zipapp_runs_from_another_directory(self):
        archive = self.folder / "delivery.pyz"
        built = subprocess.run([sys.executable, str(ROOT / "build.py"), str(archive)], cwd=ROOT, text=True, capture_output=True)
        self.assertEqual(built.returncode, 0, built.stderr)
        result = subprocess.run([sys.executable, str(archive), str(self.stock), str(self.orders), str(self.report)], cwd=self.folder, text=True, capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(self.report.read_text(encoding="utf-8"))["stock"]["灯"], 5)

        self.orders.write_text("item,qty\n灯,bad\n", encoding="utf-8")
        failure = subprocess.run([sys.executable, str(archive), str(self.stock), str(self.orders), str(self.report)], cwd=self.folder, text=True, capture_output=True)
        self.assertEqual(failure.returncode, 2, failure.stderr)

    def test_missing_arguments_have_nonzero_status(self):
        result = subprocess.run([sys.executable, "-m", "stockledger"], cwd=ROOT, text=True, capture_output=True)
        self.assertEqual(result.returncode, 2)
        self.assertIn("usage", result.stderr.lower())


if __name__ == "__main__":
    unittest.main()
