"""The I/O boundary. Relative import uses the package, not the working folder."""
from .core import parse_quantities, prepare_report


def build_report(stock_path, orders_path, report_path):
    """Read UTF-8 CSVs and write a UTF-8 JSON report, returning the same data.

    Both inputs must be completely validated before opening the report to write.
    Preserve input bytes and close all files on successful and failed paths.
    Input/output paths in this exercise are distinct. Failed writes are not
    promised crash-safe; protecting a preexisting report on invalid input is.
    """
    raise NotImplementedError("Connect pure rules to files in files.py")
