"""Independent stock-ledger practice. Public contracts are in README.md."""
