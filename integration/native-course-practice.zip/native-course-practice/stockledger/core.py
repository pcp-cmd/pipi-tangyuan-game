"""Pure data rules: no file access, no print, no global ledger."""


def parse_quantities(text):
    """CSV item,qty -> {name: total}. Preserve names; require nonnegative integers.

    Accept quoted commas/newlines and repeat rows. Reject malformed quotes, wrong headers, row
    widths, blank-only names, blank data rows, bad integer text and negatives with ValueError.
    Python's int(text) syntax is the quantity contract (signs/space are valid).
    """
    raise NotImplementedError("Implement CSV parsing and validation in core.py")


def prepare_report(stock, orders):
    """Return {'ready': bool, 'stock': dict, 'missing': dict} without input mutation.

    If any shortage exists, report all positive gaps and retain stock values.
    Otherwise deduct all order quantities in a new stock dict. Zero quantities
    remain meaningful; an ordered zero-quantity absent item becomes a zero key.
    """
    raise NotImplementedError("Implement the all-or-nothing decision in core.py")
