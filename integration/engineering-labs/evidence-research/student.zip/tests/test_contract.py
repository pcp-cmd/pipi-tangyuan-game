"""Public, reproducible contract checks. These are practice fixtures, not a blind exam."""
from copy import deepcopy
import hashlib
import importlib
import json
import math
import os
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

import research_lab
from research_lab import context, engine, evaluation, evidence, memory, retrieval, strategy
from research_lab.adapter import CorpusTools
from research_lab.boundary import (ContextBudgetError, StaleIndexError, json_bytes,
                                   load_documents, read_json, write_new_json)
from research_lab.cli import citation_checker, corpus_digest

DATA = Path(__file__).resolve().parents[1] / "data"
AS_OF = "2026-11-01"
SESSION = {"user": "alice", "allowed_access": ["public"]}
LIMITS = {"searches": 24, "reads": 96, "drafts": 64, "context_chars": 18000}


def source(identity="one", text="opening = 8 ; booked visitors only", **updates):
    row = {"id": identity, "version": "1", "issuer": "desk", "issued": "2026-01-01",
           "effective": "2026-01-01", "access": ["public"], "supersedes": [], "text": text,
           "vector": {"space": "toy-v1", "values": [1, 0]}}
    row.update(updates)
    row["file"] = identity + ".json"
    raw = {key: value for key, value in row.items() if key not in {"file", "sha256"}}
    row["sha256"] = hashlib.sha256(json_bytes(raw)).hexdigest()
    return row


def question(identity="open", field="opening"):
    return {"id": identity, "field": field, "query": field,
            "vector": {"space": "toy-v1", "values": [1, 0]}}


def proposal(document, field="opening", value=None):
    prefix = field + " = "
    line = next(line for line in document["text"].splitlines() if line.startswith(prefix))
    start = document["text"].index(line)
    return {"kind": "answer", "citation": document["id"], "field": field,
            "answer": line[len(prefix):] if value is None else value, "quote": line,
            "start": start, "end": start + len(line)}


def citation(document, field="opening"):
    checked = evidence.validate_claim({"field": field}, proposal(document, field), document)
    return checked["citation"]


class InMemoryTools:
    def __init__(self, docs):
        self.docs = deepcopy(docs)
        self.calls = {"searches": 0, "reads": 0, "drafts": 0}

    def search(self, query, q):
        self.calls["searches"] += 1
        return [{"id": doc["id"]} for doc in self.docs]

    def read(self, identity):
        self.calls["reads"] += 1
        return deepcopy(next(doc for doc in self.docs if doc["id"] == identity))

    def propose(self, q, d):
        self.calls["drafts"] += 1
        return strategy.propose(q, d)


def once(q, history, preview):
    return {"query": q["query"], "reason": "public single-query fixture"} if not history else None


class RetrievalContract(unittest.TestCase):
    def test_unique_query_words_and_punctuation(self):
        self.assertEqual(retrieval.tokens("  Library, CLOSES! Straße ... "), ["library", "closes", "strasse"])
        self.assertEqual(retrieval.keyword_score("Library library closes", "library closes."), 2)

    def test_cosine_removes_length_and_covers_directions(self):
        self.assertAlmostEqual(retrieval.cosine([1, 0], [8, 6]), 0.8)
        self.assertAlmostEqual(retrieval.cosine([1, 0], [1, 0]), 1)
        self.assertEqual(retrieval.cosine([1, 0], [0, 1]), 0)
        self.assertAlmostEqual(retrieval.cosine([1, 0], [-1, 0]), -1)
        self.assertEqual(retrieval.cosine([0, 0], [4, 2]), 0)

    def test_cosine_rejects_bad_coordinates(self):
        for a, b in [([], []), ([1], [1, 2]), ([True], [1]), ([math.nan], [1]), ([1], [math.inf]), ("x", [1])]:
            with self.subTest(a=a, b=b), self.assertRaises(ValueError):
                retrieval.cosine(a, b)

    def test_cosine_extreme_finite_float_is_stable(self):
        self.assertAlmostEqual(retrieval.cosine([1e308, 1e308], [1e308, 1e308]), 1)

    def test_rrf_hand_calculation_and_duplicate_vote(self):
        result = retrieval.rrf([["a", "a", "b"], ["c", "a"]], k=1)
        self.assertEqual([row["id"] for row in result], ["a", "c", "b"])
        self.assertAlmostEqual(result[0]["score"], 1 / 2 + 1 / 3)
        self.assertEqual(retrieval.rrf([[], []]), [])
        for bad in (True, 0, -1, math.inf, math.nan):
            with self.assertRaises(ValueError):
                retrieval.rrf([["a"]], bad)

    def test_reranker_cannot_rewrite_provenance(self):
        candidates = [{"id": "b", "nested": {"text": "original"}}, {"id": "a", "nested": {"text": "original"}}]
        before = deepcopy(candidates)
        def scorer(q, item):
            item["nested"]["text"] = "forged"
            return 1
        ranked = retrieval.rerank("q", candidates, scorer, 2)
        self.assertEqual(candidates, before)
        self.assertEqual([row["id"] for row in ranked], ["a", "b"])
        self.assertTrue(all(row["nested"]["text"] == "original" for row in ranked))

    def test_reranker_errors_and_bad_limits_are_visible(self):
        def broken(q, c):
            raise OSError("scorer unavailable")
        with self.assertRaises(OSError):
            retrieval.rerank("q", [{"id": "a"}], broken)
        with self.assertRaises(ValueError):
            retrieval.rerank("q", [{"id": "a"}], lambda q, c: True)
        with self.assertRaises(ValueError):
            retrieval.rerank("q", [{"id": "a"}], lambda q, c: 1, True)

    def test_index_preserves_original_paragraph_position_and_offsets(self):
        doc = source(text="  one  \n\n   \n\n two ")
        chunks = retrieval.build_index([doc])["chunks"]
        self.assertEqual([c["id"] for c in chunks], ["one:0", "one:2"])
        for chunk in chunks:
            self.assertEqual(doc["text"][chunk["start"]:chunk["end"]], chunk["text"])

    def test_authorization_precedes_scoring_and_topk(self):
        private = source("secret", "opening private", access=["staff"])
        public = source("public", "opening")
        docs = [private, public]
        calls = []
        original = retrieval.keyword_score
        def watch(q, text):
            calls.append(text)
            return original(q, text)
        with patch.object(retrieval, "keyword_score", watch):
            hits = retrieval.search(retrieval.build_index(docs), docs, "opening private", SESSION, AS_OF,
                                    question()["vector"], "opening", 1, "keyword")
        self.assertEqual([h["id"] for h in hits], ["public"])
        self.assertEqual(calls, ["opening"])

    def test_future_and_no_keyword_match_do_not_become_hits(self):
        docs = [source(effective="2027-01-01"), source("other", "unrelated")]
        index = retrieval.build_index(docs)
        self.assertEqual(retrieval.search(index, docs, "opening", SESSION, AS_OF, question()["vector"], "opening", mode="keyword"), [])

    def test_changed_bytes_membership_and_access_require_reindex(self):
        docs = [source()]
        index = retrieval.build_index(docs)
        variants = [[source(text="opening = 10")], [source(access=["staff"])], [source(), source("added")], []]
        for changed in variants:
            with self.subTest(changed=changed), self.assertRaises(StaleIndexError):
                retrieval.search(index, changed, "opening", SESSION, AS_OF, question()["vector"], "opening")

    def test_vector_space_mismatch_is_not_hidden_by_equal_dimensions(self):
        docs = [source(vector={"space": "other-v1", "values": [1, 0]})]
        with self.assertRaises(ValueError):
            retrieval.search(retrieval.build_index(docs), docs, "opening", SESSION, AS_OF, question()["vector"], "opening")

    def test_same_document_chunks_cannot_consume_all_slots(self):
        docs = [source("many", "opening first\n\nopening second"), source("another", "opening third")]
        before = deepcopy(docs)
        hits = retrieval.search(retrieval.build_index(docs), docs, "opening", SESSION, AS_OF, question()["vector"], "opening", 2)
        self.assertEqual(len({row["id"] for row in hits}), 2)
        self.assertEqual(docs, before)


class EvidenceContract(unittest.TestCase):
    def test_exact_quote_and_identity_are_required(self):
        doc = source()
        good = proposal(doc)
        self.assertTrue(evidence.validate_quote(good, doc)["ok"])
        for field, value in (("citation", "fiction"), ("quote", "opening = 99"), ("start", True), ("end", 999)):
            bad = dict(good, **{field: value})
            self.assertFalse(evidence.validate_quote(bad, doc)["ok"])

    def test_true_quote_can_answer_the_wrong_field(self):
        doc = source(text="opening = 8\nclosing = 18")
        wrong = proposal(doc, "closing")
        self.assertTrue(evidence.validate_quote(wrong, doc)["ok"])
        self.assertFalse(evidence.validate_claim(question(), wrong, doc)["ok"])

    def test_truncating_a_condition_fails_support_even_with_true_substring(self):
        doc = source()
        bad = proposal(doc)
        bad.update(quote="opening = 8", answer="8", end=len("opening = 8"))
        self.assertTrue(evidence.validate_quote(bad, doc)["ok"])
        self.assertFalse(evidence.validate_claim(question(), bad, doc)["ok"])

    def test_latest_other_issuer_does_not_erase_conflict(self):
        old = source("old", "opening = 8")
        blog = source("blog", "opening = 10", issuer="blogger", issued="2026-10-01", effective="2026-10-01", supersedes=["old"])
        result = evidence.resolve([citation(old), citation(blog)], [old, blog], AS_OF)
        self.assertEqual(result["status"], "conflict")
        self.assertEqual(result["alternatives"], ["10", "8"])
        self.assertNotIn("answer", result)

    def test_explicit_current_replacement_and_retraction(self):
        old = source("old", "opening = 8")
        new = source("new", "opening = 10", issued="2026-08-01", effective="2026-08-01", supersedes=["old"])
        result = evidence.resolve([citation(old), citation(new)], [old, new], AS_OF)
        self.assertEqual(result["answer"], "10")
        self.assertEqual(result["discarded"][0]["replaced_by"], "new")
        withdrawn = dict(new, text="The old opening statement is withdrawn.")
        result = evidence.resolve([citation(old)], [old, withdrawn], AS_OF)
        self.assertEqual(result["status"], "unknown")

    def test_future_and_implicit_update_do_not_replace(self):
        old = source("old", "opening = 8")
        future = source("new", "opening = 10", issued="2026-08-01", effective="2027-01-01", supersedes=["old"])
        self.assertEqual(evidence.resolve([citation(old)], [old, future], AS_OF)["answer"], "8")
        current = dict(future, effective="2026-08-01", supersedes=[])
        self.assertEqual(evidence.resolve([citation(old), citation(current)], [old, current], AS_OF)["status"], "conflict")

    def test_duplicate_discoveries_are_not_independent_sources(self):
        doc = source()
        result = evidence.resolve([citation(doc), citation(doc)], [doc], AS_OF)
        self.assertEqual(len(result["citations"]), 1)


class ContextContract(unittest.TestCase):
    def rows(self):
        return [{"id": "constraint", "text": "approve", "source": "host"},
                {"id": "goal", "text": "fix", "source": "host"},
                {"id": "old", "text": "old note", "source": "data", "required": True},
                {"id": "new", "text": "done", "source": "data"}]

    def test_mandatory_records_survive_and_optional_records_are_whole(self):
        rows = self.rows()
        self.assertEqual([r["id"] for r in context.compact(rows, ["constraint", "goal"], 14)], ["constraint", "goal", "new"])
        self.assertEqual([r["id"] for r in context.compact(rows, ["constraint", "goal"], 10)], ["constraint", "goal"])
        with self.assertRaises(ContextBudgetError):
            context.compact(rows, ["constraint", "goal"], 9)

    def test_missing_duplicate_or_bool_budget_cannot_succeed(self):
        with self.assertRaises(ValueError):
            context.compact(self.rows(), ["missing"], 100)
        with self.assertRaises(ValueError):
            context.compact(self.rows() + [self.rows()[0]], [], 100)
        with self.assertRaises(ValueError):
            context.compact(self.rows(), [], True)

    def test_copy_and_duplicate_required_ids(self):
        rows = self.rows()
        result = context.compact(rows, ["goal", "goal"], 3)
        result[0]["text"] = "edited"
        self.assertEqual(rows[1]["text"], "fix")


class MemoryContract(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "memory.db"

    def save(self, user="alice", scope="trip", key="language", value="中文", expiry=10, note="chosen"):
        memory.remember(self.path, user, scope, key, value,
                        {"kind": "user_confirmation", "confirmed_by": user, "note": note},
                        expiry, "user_confirmed", 1, lambda source: True)

    def test_users_scopes_and_new_connection_persist_independently(self):
        self.save()
        self.save("bob", value="French")
        self.save(scope="work", value="English")
        self.assertEqual(memory.recall(self.path, "alice", "trip", 2, lambda s: True)[0]["value"], "中文")
        self.assertEqual(memory.recall(self.path, "alice", "work", 2, lambda s: True)[0]["value"], "English")
        self.assertEqual(memory.recall(self.path, "bob", "trip", 2, lambda s: True)[0]["value"], "French")
        with sqlite3.connect(self.path) as db:
            self.assertEqual(db.execute("SELECT COUNT(*) FROM memories").fetchone()[0], 3)

    def test_update_replaces_source_and_expiry_only_for_its_key(self):
        self.save()
        self.save("bob", value="French")
        self.save(value="English", expiry=20, note="corrected")
        row = memory.recall(self.path, "alice", "trip", 11, lambda s: True)[0]
        self.assertEqual((row["value"], row["source"]["note"], row["expires_at"]), ("English", "corrected", 20))
        self.assertEqual(memory.recall(self.path, "bob", "trip", 9, lambda s: True)[0]["value"], "French")

    def test_expiry_boundary_is_not_deletion_and_forget_is_selective(self):
        self.save()
        self.save("bob", value="French")
        self.save(scope="work")
        self.assertEqual(len(memory.recall(self.path, "alice", "trip", 9, lambda s: True)), 1)
        self.assertEqual(memory.recall(self.path, "alice", "trip", 10, lambda s: True), [])
        with sqlite3.connect(self.path) as db:
            self.assertEqual(db.execute("SELECT COUNT(*) FROM memories").fetchone()[0], 3)
        self.assertEqual(memory.forget(self.path, "alice", "trip"), 1)
        with sqlite3.connect(self.path) as db:
            self.assertEqual(set(db.execute("SELECT user,scope FROM memories")), {("alice", "work"), ("bob", "trip")})

    def test_invalid_memory_input_does_not_change_existing_rows(self):
        self.save()
        before = self.path.read_bytes()
        for bad in (True, math.inf, math.nan, -1):
            with self.assertRaises(ValueError):
                memory.remember(self.path, "alice", "trip", "language", "wrong", {}, bad, "user_confirmed", 1, lambda s: True)
        self.assertEqual(self.path.read_bytes(), before)

    def test_provenance_is_rechecked_and_unknown_trust_is_rejected(self):
        src = {"kind": "citations", "citations": [{"answer": "8"}], "corpus_sha256": "old"}
        memory.remember(self.path, "alice", "trip", "opening", "8", src, 10, "verified_quote", 1, lambda s: True)
        self.assertEqual(memory.recall(self.path, "alice", "trip", 2, lambda s: False), [])
        with self.assertRaises(ValueError):
            memory.remember(self.path, "alice", "trip", "opening", "8", src, 10, "webpage_says_trusted", 1, lambda s: True)
        with self.assertRaises(ValueError):
            memory.remember(self.path, "alice", "trip", "language", "x",
                            {"kind": "user_confirmation", "confirmed_by": "bob", "note": "x"}, 10,
                            "user_confirmed", 1, lambda s: True)


class EngineContract(unittest.TestCase):
    def test_real_host_tracks_actual_calls_and_structured_conflict(self):
        docs = [source("a", "opening = 8"), source("b", "opening = 9", issuer="other")]
        tools = InMemoryTools(docs)
        report = engine.research([question()], tools, strategy.plan, tools.propose, AS_OF, LIMITS, ["read only"])
        self.assertEqual(report["questions"][0]["status"], "conflict")
        self.assertEqual(report["counts"], tools.calls)
        scored = evaluation.grade(report, [{"id": "open", "status": "conflict", "alternatives": ["8", "9"]}],
                                  lambda c: c["sha256"] in {d["sha256"] for d in docs}, tools.calls)
        self.assertTrue(scored["all_passed"])

    def test_unknown_is_not_a_first_document_fallback(self):
        tools = InMemoryTools([source(text="closing = 18")])
        report = engine.research([question()], tools, strategy.plan, tools.propose, AS_OF, LIMITS, [])
        row = report["questions"][0]
        self.assertEqual(row["status"], "unknown")
        self.assertNotIn("answer", row)
        self.assertGreaterEqual(len(row["history"]), 2)

    def test_two_conflicting_lines_in_one_document_are_preserved(self):
        tools = InMemoryTools([source(text="opening = 8\nopening = 9")])
        report = engine.research([question()], tools, once, tools.propose, AS_OF, LIMITS, [])
        self.assertEqual(report["questions"][0]["alternatives"], ["8", "9"])

    def test_callback_cannot_modify_host_evidence(self):
        doc = source(text="opening = 8")
        tools = InMemoryTools([doc])
        def evil(q, d):
            d["text"] = "opening = 99"
            return [proposal(d)]
        result = engine.research([question()], tools, once, evil, AS_OF, LIMITS, ["read only"])
        self.assertEqual(result["questions"][0]["status"], "unknown")
        self.assertEqual(tools.docs[0], doc)

    def test_repeated_queries_stop_and_are_not_reported_as_complete(self):
        tools = InMemoryTools([source()])
        report = engine.research([question()], tools, lambda q, h, p: {"query": "same", "reason": "repeat"},
                                 tools.propose, AS_OF, LIMITS, [])
        self.assertEqual(report["counts"]["searches"], 1)
        self.assertEqual(report["questions"][0]["stop_reason"], "repeated_query")
        self.assertNotIn("answer", report["questions"][0])

    def test_each_citation_keeps_its_own_read_version(self):
        old = source(text="opening = 8\nclosing = 18")
        new = source(text="opening = 9\nclosing = 19", version="2")
        class Changing(InMemoryTools):
            def read(self, identity):
                self.calls["reads"] += 1
                return deepcopy(old if self.calls["reads"] == 1 else new)
        tools = Changing([old])
        report = engine.research([question(), question("close", "closing")], tools, once, tools.propose, AS_OF, LIMITS, [])
        first, second = report["questions"]
        self.assertEqual(first["status"], "needs_refresh")
        self.assertNotIn("answer", first)
        self.assertEqual(first["citations"][0]["sha256"], old["sha256"])
        self.assertEqual(second["answer"], "19")

    def test_publish_reads_use_budget_and_failed_calls_count(self):
        tools = InMemoryTools([source()])
        limited = dict(LIMITS, reads=1)
        result = engine.research([question()], tools, once, tools.propose, AS_OF, limited, [])
        self.assertEqual(result["questions"][0]["status"], "needs_refresh")
        self.assertNotIn("answer", result["questions"][0])
        class Broken(InMemoryTools):
            def search(self, query, q):
                self.calls["searches"] += 1
                raise OSError("read error")
        tools = Broken([])
        result = engine.research([question()], tools, once, tools.propose, AS_OF, LIMITS, [])
        self.assertEqual(result["counts"]["searches"], 1)
        self.assertEqual(result["questions"][0]["stop_reason"], "search_OSError")

    def test_context_cannot_silently_drop_a_required_goal_or_constraint(self):
        tools = InMemoryTools([source()])
        with self.assertRaises(ContextBudgetError):
            engine.research([question()], tools, once, tools.propose, AS_OF, dict(LIMITS, context_chars=5), ["read only"])

    def test_recheck_does_not_promote_a_previously_stale_report(self):
        tools = InMemoryTools([source()])
        result = engine.research([question()], tools, once, tools.propose, AS_OF, dict(LIMITS, reads=1), [])
        checked = engine.recheck(result, tools, 10)
        self.assertEqual(checked["questions"][0]["status"], "needs_refresh")
        self.assertNotIn("answer", checked["questions"][0])

    def test_recheck_updates_pinned_context_too(self):
        tools = InMemoryTools([source()])
        report = engine.research([question()], tools, once, tools.propose, AS_OF, LIMITS, ["keep constraints"])
        tools.docs = [source(text="opening = 99", version="2")]
        checked = engine.recheck(report, tools, 10)
        pinned = json.loads(next(r["text"] for r in checked["context"] if r["id"] == "result:open"))
        self.assertEqual(pinned["status"], "needs_refresh")
        self.assertNotIn("answer", pinned)
        self.assertEqual(report["questions"][0]["status"], "cited")

    def test_failed_update_search_with_real_files_cannot_publish_prior_answer(self):
        corpus = DATA / "harbor"
        docs = load_documents(corpus)
        questions = read_json(DATA / "harbor-questions.json")[:1]
        class FailingUpdate(CorpusTools):
            searches = 0
            def search(self, query, q):
                self.searches += 1
                if self.searches == 2:
                    (corpus / "missing-update-file.txt").read_text()
                return super().search(query, q)
        tools = FailingUpdate(corpus, retrieval.build_index(docs), SESSION, AS_OF)
        result = engine.research(questions, tools, strategy.plan, strategy.propose, AS_OF, LIMITS, ["read only"])
        row = result["questions"][0]
        self.assertEqual(row["status"], "needs_refresh")
        self.assertEqual(row["stop_reason"], "search_FileNotFoundError")
        self.assertTrue(row["citations"])
        self.assertNotIn("answer", row)
        self.assertEqual(result["counts"]["searches"], 2)
        pinned = json.loads(next(r["text"] for r in result["context"] if r["id"] == "result:opening"))
        self.assertEqual(pinned["status"], "needs_refresh")
        self.assertNotIn("answer", pinned)

    def test_failed_discovery_read_cannot_hide_newer_source(self):
        corpus = DATA / "harbor"
        docs = load_documents(corpus)
        questions = read_json(DATA / "harbor-questions.json")[:1]
        class MissingCurrent(CorpusTools):
            def read(self, identity):
                if identity == "h-current":
                    (corpus / "missing-current-file.txt").read_text()
                return super().read(identity)
        tools = MissingCurrent(corpus, retrieval.build_index(docs), SESSION, AS_OF)
        result = engine.research(questions, tools, strategy.plan, strategy.propose, AS_OF, LIMITS, ["read only"])
        row = result["questions"][0]
        self.assertEqual(row["status"], "needs_refresh")
        self.assertNotIn("answer", row)
        self.assertTrue(any(r["id"] == "h-current" and r["reason"] == "FileNotFoundError" for r in row["stale_sources"]))
        self.assertTrue(any(r["id"] == "h-old" for r in row["citations"]))


class EvaluationContract(unittest.TestCase):
    def test_metric_deduplicates_before_cutoff(self):
        actual = evaluation.retrieval_score(["wrong", "right", "right", "also"], ["right", "also"], 3)
        self.assertEqual(actual, {"hits": 2, "precision": 2 / 3, "recall": 1})
        self.assertEqual(evaluation.retrieval_score([], ["right"], 3)["precision"], 0)
        with self.assertRaises(ValueError):
            evaluation.retrieval_score([], [], 3)

    def test_candidate_self_praise_does_not_change_external_grade(self):
        report = {"questions": [{"question_id": "x", "status": "cited", "answer": "wrong", "citations": [], "correct": True}],
                  "counts": {"searches": 0, "reads": 0, "drafts": 0}, "correct": True}
        external = {"searches": 1, "reads": 1, "drafts": 1}
        result = evaluation.grade(report, [{"id": "x", "status": "cited", "answer": "right"}], lambda c: True, external)
        self.assertFalse(result["all_passed"])
        self.assertFalse(result["ledger_ok"])
        self.assertEqual(result["observed_calls"], external)

    def test_conflict_needs_real_distinct_cited_values(self):
        counts = {"searches": 0, "reads": 0, "drafts": 0}
        report = {"questions": [{"question_id": "x", "status": "conflict", "alternatives": ["a", "b"], "citations": []}], "counts": counts}
        result = evaluation.grade(report, [{"id": "x", "status": "conflict", "alternatives": ["a", "b"]}], lambda c: True, counts)
        self.assertFalse(result["all_passed"])

    def test_extra_answer_cannot_hide_outside_expected_set(self):
        counts = {"searches": 0, "reads": 0, "drafts": 0}
        report = {"questions": [{"question_id": "x", "status": "unknown", "citations": []},
                                {"question_id": "extra", "status": "cited", "answer": "invented", "citations": []}], "counts": counts}
        result = evaluation.grade(report, [{"id": "x", "status": "unknown"}], lambda c: True, counts)
        self.assertFalse(result["all_passed"])


class BoundaryContract(unittest.TestCase):
    def test_raw_bytes_and_metadata_belong_to_the_digest(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "document.json"
            item = source()
            for key in ("sha256", "file"):
                item.pop(key)
            write_new_json(path, item)
            old = load_documents(temp)[0]
            item["access"] = ["staff"]
            path.write_bytes(json_bytes(item))
            new = load_documents(temp)[0]
            self.assertNotEqual(old["sha256"], new["sha256"])
            self.assertEqual(new["sha256"], hashlib.sha256(path.read_bytes()).hexdigest())

    def test_reject_symlink_unknown_fields_and_duplicate_json_keys(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            path = root / "one.json"
            path.write_text('{"id":"a","id":"b"}', encoding="utf-8")
            with self.assertRaises(ValueError):
                load_documents(root)
            path.unlink()
            path.symlink_to(DATA / "alice.json")
            with self.assertRaises(ValueError):
                load_documents(root)


class CLIContract(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="research 学习 ")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.corpus = self.root / "资料 harbor"
        shutil.copytree(DATA / "harbor", self.corpus)
        self.env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1",
                        PYTHONPATH=str(Path(research_lab.__file__).resolve().parents[1]))

    def cli(self, *args, ok=True):
        process = subprocess.run([sys.executable, "-m", "research_lab.cli", *map(str, args)],
                                 cwd=self.root, env=self.env, capture_output=True, text=True, timeout=15)
        self.assertEqual(process.returncode, 0 if ok else 2, process.stdout + process.stderr)
        return process

    def build_run(self):
        index, report = self.root / "index.json", self.root / "report.json"
        self.cli("index", "--corpus", self.corpus, "--output", index)
        self.cli("run", "--corpus", self.corpus, "--index", index,
                 "--questions", DATA / "harbor-questions.json", "--session", DATA / "alice.json",
                 "--as-of", AS_OF, "--output", report)
        return index, report

    def test_new_process_report_memory_expiry_other_user_and_physical_delete(self):
        _, report = self.build_run()
        value = read_json(report)
        self.assertEqual([q["status"] for q in value["questions"]], ["cited", "conflict", "unknown"])
        db = self.root / "state.db"
        self.cli("remember", "--corpus", self.corpus, "--session", DATA / "alice.json", "--as-of", AS_OF,
                 "--report", report, "--memory", db, "--scope", "harbor", "--now", 100, "--ttl", 10,
                 "--output", self.root / "saved.json")
        for who, now, expected in (("alice", 109, 1), ("bob", 109, 0), ("alice", 110, 0)):
            output = self.root / f"{who}-{now}.json"
            self.cli("recall", "--corpus", self.corpus, "--session", DATA / (who + ".json"), "--as-of", AS_OF,
                     "--memory", db, "--scope", "harbor", "--now", now, "--output", output)
            self.assertEqual(len(read_json(output)["records"]), expected)
        with sqlite3.connect(db) as connection:
            self.assertEqual(connection.execute("SELECT COUNT(*) FROM memories").fetchone()[0], 1)
        self.cli("forget", "--memory", db, "--session", DATA / "alice.json", "--scope", "harbor", "--output", self.root / "forgot.json")
        with sqlite3.connect(db) as connection:
            self.assertEqual(connection.execute("SELECT COUNT(*) FROM memories").fetchone()[0], 0)

    def test_real_source_change_needs_rebuild_and_full_research(self):
        index, report = self.build_run()
        path = next(self.corpus.glob("*h-current.json"))
        changed = read_json(path)
        changed["text"] = changed["text"].replace("09:00", "10:30")
        changed["version"] = "2"
        path.write_bytes(json_bytes(changed))
        output = self.root / "stale.json"
        self.cli("recheck", "--corpus", self.corpus, "--report", report, "--session", DATA / "alice.json",
                 "--as-of", AS_OF, "--output", output)
        self.assertTrue(all(q["status"] == "needs_refresh" and "answer" not in q for q in read_json(output)["questions"]))
        old_output = self.root / "old-index-run.json"
        self.cli("run", "--corpus", self.corpus, "--index", index, "--questions", DATA / "harbor-questions.json",
                 "--session", DATA / "alice.json", "--as-of", AS_OF, "--output", old_output)
        self.assertEqual(read_json(old_output)["questions"][0]["status"], "needs_refresh")
        new_index, new_report = self.root / "index2.json", self.root / "report2.json"
        self.cli("index", "--corpus", self.corpus, "--output", new_index)
        self.cli("run", "--corpus", self.corpus, "--index", new_index, "--questions", DATA / "harbor-questions.json",
                 "--session", DATA / "alice.json", "--as-of", AS_OF, "--output", new_report)
        self.assertEqual(read_json(new_report)["questions"][0]["answer"], "10:30 ; weekdays only")

    def test_new_membership_invalidates_old_report_even_when_quoted_file_is_unchanged(self):
        _, report = self.build_run()
        extra = source("extra", "dock_open = 10", issuer="another", vector={"space": "handmade-three-axes-v1", "values": [1, 0, 0]})
        for key in ("file", "sha256"):
            extra.pop(key)
        write_new_json(self.corpus / "extra.json", extra)
        output = self.root / "membership.json"
        self.cli("recheck", "--corpus", self.corpus, "--report", report, "--session", DATA / "alice.json", "--as-of", AS_OF, "--output", output)
        self.assertEqual(read_json(output)["questions"][0]["status"], "needs_refresh")

    def test_output_is_never_replaced(self):
        index, report = self.build_run()
        before = report.read_bytes()
        self.cli("index", "--corpus", self.corpus, "--output", report, ok=False)
        self.assertEqual(report.read_bytes(), before)

    def test_changed_source_invalidates_memory_before_ttl(self):
        _, report = self.build_run()
        db = self.root / "memory.db"
        self.cli("remember", "--corpus", self.corpus, "--report", report, "--session", DATA / "alice.json", "--as-of", AS_OF,
                 "--memory", db, "--scope", "harbor", "--now", 100, "--ttl", 1000, "--output", self.root / "remembered.json")
        path = next(self.corpus.glob("*h-current.json"))
        doc = read_json(path)
        doc["access"] = ["staff"]
        path.write_bytes(json_bytes(doc))
        output = self.root / "after-revocation.json"
        self.cli("recall", "--corpus", self.corpus, "--session", DATA / "alice.json", "--as-of", AS_OF,
                 "--memory", db, "--scope", "harbor", "--now", 101, "--output", output)
        self.assertEqual(read_json(output)["records"], [])
        with sqlite3.connect(db) as connection:
            self.assertEqual(connection.execute("SELECT COUNT(*) FROM memories").fetchone()[0], 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
