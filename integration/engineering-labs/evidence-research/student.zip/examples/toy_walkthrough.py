"""Worked micro-examples on different questions; not an implementation of the lab API."""
import argparse
import hashlib
import math
from pathlib import Path
import sqlite3
import tempfile


def files():
    text = "watering = before noon\nweather = dry only"
    print("Original hash:", hashlib.sha256(text.encode("utf-8")).hexdigest())
    print("Extra newline:", hashlib.sha256((text + "\n").encode("utf-8")).hexdigest())
    start = text.index("weather")
    print("Complete located line:", start, len(text), text[start:])


def ranking():
    print("Question [0,1]; A [0,2]; B [6,8]")
    print("Dot products:", 0 * 0 + 1 * 2, 0 * 6 + 1 * 8)
    print("Direction comparison:", 2 / (1 * 2), 8 / (1 * math.sqrt(6 * 6 + 8 * 8)))
    print("RRF k=1, oak/pine and birch/oak:", {"oak": 1 / 2 + 1 / 3, "pine": 1 / 3, "birch": 1 / 2})


def quotes():
    text = "rental_end = 17:00"
    quote = text[:]
    question_field = "rental_start"
    print("Exact source quote:", quote == text)
    print("Same requested field:", quote.split(" = ", 1)[0] == question_field)
    print("These two answers must be different.")


def sqlite_example():
    with tempfile.TemporaryDirectory(prefix="orchard-example-") as temp:
        path = Path(temp) / "plants.db"
        db = sqlite3.connect(path)
        try:
            with db:
                db.execute("CREATE TABLE plants(owner TEXT,label TEXT,note TEXT,PRIMARY KEY(owner,label))")
                db.execute("INSERT INTO plants VALUES(?,?,?)", ("A", "mint", "shade"))
                db.execute("INSERT INTO plants VALUES(?,?,?)", ("B", "mint", "sun"))
        finally:
            db.close()
        another = sqlite3.connect(path)
        try:
            print("New connection, owner A:", another.execute("SELECT note FROM plants WHERE owner=? AND label=?", ("A", "mint")).fetchone())
        finally:
            another.close()
    print("The temporary example database was removed; create your own lab memory separately.")


def budget():
    mandatory = ["paint", "dry only"]
    used = sum(len(text) for text in mandatory)
    print("Mandatory characters:", used, "budget:", 12, "fits:", used <= 12)
    print("Do not delete 'dry only' to turn this result into success.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("part", nargs="?", choices=["all", "files", "ranking", "quotes", "sqlite", "budget"], default="all")
    choice = parser.parse_args().part
    actions = {"files": files, "ranking": ranking, "quotes": quotes, "sqlite": sqlite_example, "budget": budget}
    for name, action in actions.items():
        if choice in ("all", name):
            print("\n" + name)
            action()
