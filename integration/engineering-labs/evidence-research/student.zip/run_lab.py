"""From this learner directory: python run_lab.py --help."""
from research_lab.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
