"""学生未解接口。完成正文小实验后独立实现；没有作者回退。"""

def plan(question, history, preview):
    """输入当前问题/已查询记录/证据preview的深副本；提出有缺口理由的新query或None停止。"""
    raise NotImplementedError("先读 lessons/05-research-loop.md，实现 strategy.plan")

def propose(question, document):
    """从文档为本问题给0..32项提案；每项完整原句、span、field、answer；不提供期望标签。"""
    raise NotImplementedError("先读 lessons/05-research-loop.md，实现 strategy.propose")
