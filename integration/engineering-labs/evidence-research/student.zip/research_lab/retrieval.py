"""学生未解接口。完成正文小实验后独立实现；没有作者回退。"""

def tokens(text):
    """返回 casefold→空格切词→两端有限标点清理后的非空词列表；不假称通用中文分词。"""
    raise NotImplementedError("先读 lessons/02-index-and-access.md / 03-ranking.md，实现 retrieval.tokens")

def keyword_score(query, text):
    """不同查询词各计一次；返回与文本词的重合数。"""
    raise NotImplementedError("先读 lessons/02-index-and-access.md / 03-ranking.md，实现 retrieval.keyword_score")

def cosine(a, b):
    """同维非空有限数列表，无bool；方向相似度[-1,1]，零向量0；非法输入ValueError。"""
    raise NotImplementedError("先读 lessons/02-index-and-access.md / 03-ranking.md，实现 retrieval.cosine")

def rrf(rankings, k=60):
    """每表先保序去重；从1计名次；贡献1/(k+rank)；分数降序、id升序。"""
    raise NotImplementedError("先读 lessons/02-index-and-access.md / 03-ranking.md，实现 retrieval.rrf")

def rerank(question, candidates, scorer, limit=3):
    """逐条以深副本调用scorer一次；有限数评分；不允许修改宿主原文；异常显露。"""
    raise NotImplementedError("先读 lessons/02-index-and-access.md / 03-ranking.md，实现 retrieval.rerank")

def build_index(documents):
    """由boundary.load_documents的合法记录生成schema/snapshot/chunks；原段序号和字符位置不变。"""
    raise NotImplementedError("先读 lessons/02-index-and-access.md / 03-ranking.md，实现 retrieval.build_index")

def search(index, documents, query, session, as_of, vector, field, limit=3, mode='hybrid'):
    """校验当前索引→宿主ACL与日期过滤→评分→融合/重排→唯一文档top-k；见CONTRACT。"""
    raise NotImplementedError("先读 lessons/02-index-and-access.md / 03-ranking.md，实现 retrieval.search")
