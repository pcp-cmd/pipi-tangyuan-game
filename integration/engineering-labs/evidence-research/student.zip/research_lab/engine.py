"""学生未解接口。完成正文小实验后独立实现；没有作者回退。"""

def research(questions, tools, planner, proposer, as_of, limits, constraints, memory_records=()):
    """真正组织有界search/read/propose/独立校验/替代冲突/发布前逐版本重读/必需上下文。"""
    raise NotImplementedError("先读 lessons/05-research-loop.md，实现 engine.research")

def recheck(report, tools, read_limit):
    """只重读并撤下过期答案；从不把needs_refresh自行升级，需要重新research。"""
    raise NotImplementedError("先读 lessons/05-research-loop.md，实现 engine.recheck")
