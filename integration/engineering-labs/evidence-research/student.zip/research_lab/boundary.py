"""Provided boundary adapter. No expected answers, ranking, or candidate solutions."""
from __future__ import annotations

import hashlib
import json
import math
import os
import re
from datetime import date
from pathlib import Path


class StaleIndexError(ValueError):
    """Current bytes or file membership no longer match the persisted index."""


class ContextBudgetError(ValueError):
    """The host's mandatory records do not fit; do not silently discard them."""


def nonempty(value, label):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{label}: expected non-empty string")
    return value


def positive_int(value, label):
    if type(value) is not int or value < 1:
        raise ValueError(f"{label}: expected positive integer, not bool")
    return value


def finite_time(value, label):
    if type(value) not in (int, float) or not math.isfinite(value) or value < 0:
        raise ValueError(f"{label}: expected finite non-negative number")
    return value


def iso_date(value, label):
    if not isinstance(value, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
        raise ValueError(f"{label}: expected YYYY-MM-DD")
    date.fromisoformat(value)
    return value


def _unique_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def parse_json(raw):
    return json.loads(raw, object_pairs_hook=_unique_pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2,
                       allow_nan=False) + "\n").encode("utf-8")


def read_json(path):
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        raise ValueError(f"expected regular non-symlink file: {path}")
    return parse_json(path.read_bytes().decode("utf-8"))


def write_new_json(path, value):
    """Create without replacement; failed serialization leaves no output file."""
    payload = json_bytes(value)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())
    return hashlib.sha256(payload).hexdigest()


def session_from(value):
    if not isinstance(value, dict):
        raise ValueError("session: expected object")
    user = nonempty(value.get("user"), "session.user")
    access = value.get("allowed_access")
    if not isinstance(access, list) or any(not isinstance(x, str) or not x for x in access):
        raise ValueError("session.allowed_access: expected string list")
    return {"user": user, "allowed_access": sorted(set(access))}


def load_documents(root):
    """Load a bounded, flat synthetic corpus. A local session is not authentication."""
    root = Path(root)
    if root.is_symlink() or not root.is_dir():
        raise ValueError("corpus: expected directory, not symlink")
    paths = sorted(root.iterdir())
    if not paths or len(paths) > 64:
        raise ValueError("corpus: expected 1..64 JSON files")
    documents, ids = [], set()
    for path in paths:
        if path.suffix != ".json" or path.is_symlink() or not path.is_file():
            raise ValueError("corpus: only flat regular .json files are accepted")
        raw = path.read_bytes()
        if len(raw) > 131072:
            raise ValueError("corpus: document exceeds 128 KiB")
        item = parse_json(raw.decode("utf-8"))
        if not isinstance(item, dict):
            raise ValueError("document: expected object")
        required = {"id", "version", "issuer", "issued", "effective", "access",
                    "supersedes", "text", "vector"}
        if set(item) != required:
            raise ValueError("document: fields must match CONTRACT.md")
        for key in ("id", "version", "issuer", "text"):
            nonempty(item[key], key)
        if item["id"] in ids:
            raise ValueError("document: duplicate id")
        ids.add(item["id"])
        for key in ("issued", "effective"):
            iso_date(item[key], key)
        if item["effective"] < item["issued"]:
            raise ValueError("effective date cannot precede issue date")
        for key in ("access", "supersedes"):
            values = item[key]
            if (not isinstance(values, list) or any(not isinstance(x, str) or not x for x in values)
                    or len(values) != len(set(values))):
                raise ValueError(f"{key}: expected unique string list")
        if not item["access"] or item["id"] in item["supersedes"]:
            raise ValueError("invalid access or self-supersession")
        vector = item["vector"]
        if (not isinstance(vector, dict) or set(vector) != {"space", "values"}
                or not isinstance(vector["space"], str) or not vector["space"]
                or not isinstance(vector["values"], list) or not vector["values"]
                or any(type(x) not in (int, float) or not math.isfinite(x)
                       for x in vector["values"])):
            raise ValueError("vector: named space and finite numeric list required")
        item["sha256"] = hashlib.sha256(raw).hexdigest()
        item["file"] = path.name
        documents.append(item)
    return documents


def questions_from(value):
    if not isinstance(value, list) or not value or len(value) > 12:
        raise ValueError("questions: expected 1..12 questions")
    seen = set()
    for question in value:
        if not isinstance(question, dict) or set(question) != {"id", "field", "query", "vector"}:
            raise ValueError("question: expected id/field/query/vector")
        for name in ("id", "field", "query"):
            nonempty(question[name], "question." + name)
        if not re.fullmatch(r"[a-z][a-z0-9_]*", question["field"]):
            raise ValueError("question.field: lower-case machine field required")
        if question["id"] in seen:
            raise ValueError("duplicate question id")
        seen.add(question["id"])
        vector = question["vector"]
        if not isinstance(vector, dict) or set(vector) != {"space", "values"}:
            raise ValueError("question.vector: expected space/values")
        nonempty(vector["space"], "question.vector.space")
        if (not isinstance(vector["values"], list) or not vector["values"]
                or any(type(x) not in (int, float) or not math.isfinite(x)
                       for x in vector["values"])):
            raise ValueError("question.vector: invalid values")
    return value
