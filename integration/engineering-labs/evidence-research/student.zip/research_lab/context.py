"""学生未解接口。完成正文小实验后独立实现；没有作者回退。"""

def compact(records, required_ids, budget):
    """先钉住宿主required_ids；再从新到旧选完整可选项；还原原顺序；超预算不丢必需项。"""
    raise NotImplementedError("先读 lessons/07-context-and-evaluation.md，实现 context.compact")
