"""Provided I/O wiring. Calls the learner's retrieval, not an author fallback."""
from copy import deepcopy

from .boundary import load_documents, session_from, iso_date
from . import retrieval


class CorpusTools:
    def __init__(self, root, index, session, as_of, limit=8, mode="hybrid"):
        self.root = root
        self.index = deepcopy(index)
        self.session = session_from(session)
        self.as_of = iso_date(as_of, "as_of")
        self.limit = limit
        self.mode = mode

    def search(self, query, question):
        return retrieval.search(self.index, load_documents(self.root), query, self.session,
                                self.as_of, question["vector"], question["field"],
                                self.limit, self.mode)

    def read(self, identity):
        matches = [doc for doc in load_documents(self.root) if doc["id"] == identity]
        if not matches:
            raise FileNotFoundError(identity)
        doc = matches[0]
        if not set(doc["access"]).intersection(self.session["allowed_access"]):
            raise PermissionError("source access was not granted")
        if doc["issued"] > self.as_of or doc["effective"] > self.as_of:
            raise PermissionError("source is not yet effective")
        return doc
