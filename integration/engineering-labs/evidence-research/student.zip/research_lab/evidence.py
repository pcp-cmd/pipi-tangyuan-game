"""学生未解接口。完成正文小实验后独立实现；没有作者回退。"""

def validate_quote(proposal, document):
    """分别拒绝字段、id、span或原句不匹配；成功仅表示精确原句身份，不是语义真理。"""
    raise NotImplementedError("先读 lessons/04-citations.md，实现 evidence.validate_quote")

def validate_claim(question, proposal, document):
    """在原句检查后，要求完整field = value行与question.field/answer完全对应；生成宿主citation。"""
    raise NotImplementedError("先读 lessons/04-citations.md，实现 evidence.validate_claim")

def resolve(citations, documents, as_of):
    """同发布者、更晚发布、已经生效、明确列旧id才替代；保留conflict/unknown，不选最新猜答案。"""
    raise NotImplementedError("先读 lessons/04-citations.md，实现 evidence.resolve")
