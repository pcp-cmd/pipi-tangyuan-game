"""学生未解接口。完成正文小实验后独立实现；没有作者回退。"""

def retrieval_score(ranked_ids, relevant_ids, k):
    """先保序去重再截k；precision按实际返回数，recall按外部相关集合；空相关集拒绝。"""
    raise NotImplementedError("先读 lessons/07-context-and-evaluation.md，实现 evaluation.retrieval_score")

def grade(report, expectations, source_check, observed_calls):
    """期望、source_check、observed_calls由独立观察方给；忽略候选自报correct/effects。"""
    raise NotImplementedError("先读 lessons/07-context-and-evaluation.md，实现 evaluation.grade")
