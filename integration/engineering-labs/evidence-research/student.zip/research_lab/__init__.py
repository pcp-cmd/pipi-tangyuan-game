"""Offline, deliberately bounded research engineering exercise."""
