"""学生未解接口。完成正文小实验后独立实现；没有作者回退。"""

def remember(path, user, scope, key, value, source, expires_at, trust, now, source_check):
    """先验证身份/有效期/来源/信任再事务写SQLite；同(user,scope,key)更新值及新来源。"""
    raise NotImplementedError("先读 lessons/06-memory.md，实现 memory.remember")

def recall(path, user, scope, now, source_check):
    """绑定user与scope，从真实数据库读取；now>=expires_at不返回；重查来源，不能串用户。"""
    raise NotImplementedError("先读 lessons/06-memory.md，实现 memory.recall")

def forget(path, user, scope, key=None):
    """只删除指定user/scope[/key]的数据库行，返回实际删行数；其他范围保持。"""
    raise NotImplementedError("先读 lessons/06-memory.md，实现 memory.forget")
