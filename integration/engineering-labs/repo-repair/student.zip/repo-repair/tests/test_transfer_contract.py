"""Different business task; actual functions and CLI, not source-text matching."""
import copy
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

BASE = Path(__file__).resolve().parents[1]
PATH = Path(os.environ.get("PIPI_REPAIR_TRANSFER", str(BASE / "transfer/reminders.py"))).resolve()
spec = importlib.util.spec_from_file_location("own_transfer", PATH)
candidate = importlib.util.module_from_spec(spec); spec.loader.exec_module(candidate)


def loan(book="waves", person="皮皮", due=8, returned=None):
    return {"book_id": book, "borrower": person, "due_day": due, "returned_day": returned}


class Transfer(unittest.TestCase):
    def test_boundary_returned_and_two_loans_for_same_book(self):
        rows = [loan(due=9), loan(due=10), loan(person="汤圆", due=4), loan("star", due=2, returned=3)]
        self.assertEqual(candidate.reminders(rows, 10), [
            {"book_id": "waves", "borrower": "皮皮", "days_overdue": 1},
            {"book_id": "waves", "borrower": "汤圆", "days_overdue": 6}])

    def test_input_and_returned_records_do_not_share_mutable_rows(self):
        rows = [loan()]; before = copy.deepcopy(rows)
        result = candidate.reminders(rows, 12)
        self.assertEqual(rows, before)
        result[0]["borrower"] = "changed output"
        self.assertEqual(rows, before)

    def test_grace_boundary_and_empty_input(self):
        self.assertEqual(candidate.reminders([loan(due=10)], 12, 2), [])
        self.assertEqual(candidate.reminders([loan(due=10)], 13, 2)[0]["days_overdue"], 1)
        self.assertEqual(candidate.reminders([], 0), [])

    def test_invalid_rows_and_boolean_dates_raise_before_any_result(self):
        bad_rows = [[loan(due=True)], [loan(returned=False)], [loan(due=-1)], [loan(person="")],
                    [loan(), {"book_id": "missing"}], [loan(), {**loan(), "extra": 1}], "not a list"]
        for rows in bad_rows:
            with self.subTest(rows=rows), self.assertRaises(ValueError): candidate.reminders(rows, 12)
        for today, grace in [(True, 0), (0, False), (-1, 0), (0, -1)]:
            with self.subTest(today=today, grace=grace), self.assertRaises(ValueError): candidate.reminders([], today, grace)

    def invoke(self, inputs, today="12", extra=(), initial=b"previous report\r\n", same=False, hardlink=False):
        with tempfile.TemporaryDirectory(prefix="pipi-transfer-") as temporary:
            root = Path(temporary); source = root / "借阅 清单.json"; target = root / "report.json"
            source.write_text(json.dumps(inputs, ensure_ascii=False), encoding="utf-8"); target.write_bytes(initial)
            source_before = source.read_bytes()
            if same: target = source
            if hardlink:
                target.unlink()
                os.link(source, target)
                self.assertTrue(source.samefile(target))
            wrapper = "import importlib.util,sys; s=importlib.util.spec_from_file_location('own',sys.argv[1]); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); raise SystemExit(m.main(sys.argv[2:]))"
            result = subprocess.run([sys.executable, "-I", "-B", "-c", wrapper, str(PATH), "--input", str(source),
                                     "--output", str(target), "--today", today, *extra], cwd=root,
                                    text=True, capture_output=True, timeout=8)
            return result, target.read_bytes(), source_before, source.read_bytes()

    def test_actual_cli_writes_unicode_json_from_another_directory(self):
        proc, data, before, after = self.invoke([loan(due=10)], extra=("--grace", "1"))
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(json.loads(data), [{"book_id": "waves", "borrower": "皮皮", "days_overdue": 1}])
        self.assertIn("皮皮", data.decode()); self.assertEqual(after, before)

    def test_actual_cli_bad_last_row_preserves_old_report_byte_for_byte(self):
        proc, data, before, after = self.invoke([loan(), {"bad": "last row"}])
        self.assertEqual(proc.returncode, 2, proc.stderr); self.assertEqual(data, b"previous report\r\n")
        self.assertEqual(after, before); self.assertTrue(proc.stderr.strip())

    def test_actual_cli_rejects_same_file_and_invalid_parameter(self):
        proc, data, before, after = self.invoke([loan()], same=True)
        self.assertEqual(proc.returncode, 2, proc.stderr); self.assertEqual(data, before); self.assertEqual(after, before)
        proc, data, before, after = self.invoke([loan()], today="not-a-day")
        self.assertEqual(proc.returncode, 2); self.assertEqual(data, b"previous report\r\n")

    def test_actual_cli_rejects_two_hardlink_names_for_one_file(self):
        proc, data, before, after = self.invoke([loan()], hardlink=True)
        self.assertEqual(proc.returncode, 2, proc.stderr)
        self.assertEqual(data, before)
        self.assertEqual(after, before)


if __name__ == "__main__": unittest.main()
