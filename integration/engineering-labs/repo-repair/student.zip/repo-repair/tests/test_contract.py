"""Public behavior checks. They inspect real files, Git and child processes.

Running these imports your own candidate Python. Review it first. This checker
does not safely execute hostile submissions and does not grant game progress.
"""
import hashlib
import http.server
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import unittest

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE))
import fixture


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


candidate = load(Path(os.environ.get("PIPI_REPAIR_CANDIDATE", str(BASE / "repair.py"))), "repair_candidate")
host = load(Path(os.environ.get("PIPI_REPAIR_HOST", str(BASE / "host.py"))), "repair_host")


def grant(action, args, token="grant-1", actor="learner", expires=30):
    raw = json.dumps(args, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    return {"id": token, "actor": actor, "action": action,
            "arguments_sha256": hashlib.sha256(raw).hexdigest(), "expires_at": expires}


class Contract(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="pipi-repo-contract-")
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name) / "owned fixture"
        self.request = fixture.create_fixture(self.root)
        self.target = self.request["writable"][0]
        self.runner = fixture.trusted_runner("warehouse")
        self.used = set()

    def proposal(self, old="price + quantity", new="price * quantity", name=None):
        name = name or self.target
        snap = candidate.read_snapshot(self.root, name)
        return candidate.propose_patch(self.root, name, snap["sha256"], old, new, self.request["writable"])

    def apply(self, proposal=None, ticket=None):
        proposal = proposal or self.proposal()
        args = {k: proposal[k] for k in ("path", "before_hash", "old", "new")}
        return candidate.apply_patch(self.root, proposal, ticket if ticket is not None else grant("patch", args),
                                     "learner", 10, self.used, self.request["writable"])

    def baseline(self):
        return candidate.fingerprints(self.root, self.request["protected"])

    def test_read_hashes_raw_bytes_and_preserves_newlines(self):
        raw = "码头\r\n第二行\r\n".encode()
        p = self.root / "中文 空格.txt"; p.write_bytes(raw)
        snap = candidate.read_snapshot(self.root, p.name)
        self.assertEqual(snap, {"path": p.name, "sha256": hashlib.sha256(raw).hexdigest(),
                                "text": raw.decode(), "bytes": len(raw)})

    def test_paths_and_linked_components_do_not_escape(self):
        for name in ("../outside.txt", "/tmp/outside.txt", "src\\stock_cost.py", "src/../check_fixture.py", ".git/config", "src//stock_cost.py"):
            with self.subTest(name=name), self.assertRaises(PermissionError):
                candidate.read_snapshot(self.root, name)
        outside = Path(self.tmp.name) / "outside.txt"; outside.write_text("keep")
        (self.root / "shortcut").symlink_to(Path(self.tmp.name), target_is_directory=True)
        with self.assertRaises(PermissionError): candidate.read_snapshot(self.root, "shortcut/outside.txt")
        self.assertEqual(outside.read_text(), "keep")
        self.assertFalse(any(x.startswith("shortcut/") or x.startswith(".git/") for x in candidate.list_repo(self.root)))

    def test_portable_path_policy_rejects_case_and_trailing_dot_aliases(self):
        (self.root / ".GIT").mkdir(exist_ok=True)
        (self.root / ".GIT/config").write_text("owned fixture only")
        (self.root / "notes.").mkdir(); (self.root / "notes./x.txt").write_text("owned fixture only")
        for name in [".GIT/config", "notes./x.txt", "src/stock_cost.py "]:
            with self.subTest(name=name), self.assertRaises(PermissionError): candidate.read_snapshot(self.root, name)
        self.assertNotIn(".GIT/config", candidate.list_repo(self.root))
        self.assertNotIn("notes./x.txt", candidate.list_repo(self.root))

    def test_search_has_real_line_numbers_and_skips_only_ineligible_text(self):
        (self.root / "note.txt").write_bytes("首行\n茶 茶\n第三行\n茶\n".encode())
        (self.root / "binary.bin").write_bytes(b"\xff\xfe")
        (self.root / "huge.txt").write_bytes(b"x" * 65_537)
        self.assertEqual(candidate.search_repo(self.root, "茶"), [
            {"path": "note.txt", "line": 2, "text": "茶 茶"}, {"path": "note.txt", "line": 4, "text": "茶"}])
        with self.assertRaises(ValueError): candidate.read_snapshot(self.root, "huge.txt")
        with self.assertRaises(UnicodeError): candidate.read_snapshot(self.root, "binary.bin")
        with self.assertRaises(FileNotFoundError): candidate.read_snapshot(self.root, "missing.txt")

    def test_proposal_is_not_write_and_actual_diff_matches_bytes(self):
        old = (self.root / self.target).read_bytes(); p = self.proposal()
        self.assertEqual((self.root / self.target).read_bytes(), old)
        self.assertIn("-    return price + quantity", p["diff"])
        result = self.apply(p)
        actual = (self.root / self.target).read_bytes()
        self.assertEqual(actual, fixture.SCENARIOS["warehouse"]["correct"].encode())
        self.assertEqual(result["after_hash"], hashlib.sha256(actual).hexdigest())
        self.assertEqual(result["before_text"].encode(), old)

    def test_stale_snapshot_unique_anchor_and_protected_write_rejected(self):
        p = self.proposal(); file = self.root / self.target
        file.write_bytes(file.read_bytes() + b"# human change\n")
        changed = file.read_bytes()
        with self.assertRaises(ValueError):
            candidate.propose_patch(self.root, self.target, p["before_hash"], p["old"], p["new"], self.request["writable"])
        with self.assertRaises(ValueError): self.apply(p)
        self.assertEqual(file.read_bytes(), changed)
        file.write_bytes(b"mark\nmark\n")
        snap = candidate.read_snapshot(self.root, self.target)
        with self.assertRaises(ValueError): candidate.propose_patch(self.root, self.target, snap["sha256"], "mark", "new", self.request["writable"])
        before = (self.root / "tests/test_contract.py").read_bytes()
        snap = candidate.read_snapshot(self.root, "tests/test_contract.py")
        with self.assertRaises(PermissionError): candidate.propose_patch(self.root, snap["path"], snap["sha256"], "assertEqual", "assertNotEqual", self.request["writable"])
        self.assertEqual((self.root / snap["path"]).read_bytes(), before)

    def test_patch_keeps_crlf_and_existing_pending_file(self):
        target = self.root / self.target
        target.write_bytes(target.read_bytes().replace(b"\n", b"\r\n"))
        pending = self.root / "src/stock_cost.py.pending"; pending.write_text("unrelated")
        p = self.proposal(); self.apply(p)
        self.assertEqual(target.read_bytes().count(b"\r\n"), 2)
        self.assertEqual(pending.read_text(), "unrelated")
        self.assertFalse(list(target.parent.glob(".repair-*")))

    def test_each_approval_failure_is_independently_exercised(self):
        p = self.proposal(); args = {k: p[k] for k in ("path", "before_hash", "old", "new")}
        wrong = [None, grant("restore", args), grant("patch", args, actor="another"),
                 grant("patch", {**args, "new": "return 0"}), grant("patch", args, expires=10),
                 grant("patch", args, expires=True)]
        before = (self.root / self.target).read_bytes()
        for i, ticket in enumerate(wrong):
            with self.subTest(case=i), self.assertRaises(PermissionError):
                candidate.apply_patch(self.root, p, ticket, "learner", 10, set(), self.request["writable"])
            self.assertEqual((self.root / self.target).read_bytes(), before)
        ticket = grant("patch", args)
        candidate.authorize(ticket, "learner", "patch", args, 10, set())
        with self.assertRaises(PermissionError): candidate.authorize(ticket, "learner", "patch", args, 10, {ticket["id"]})

    def test_tampered_after_text_is_not_trusted(self):
        p = self.proposal(); p["after_text"] += "# not approved\n"
        before = (self.root / self.target).read_bytes()
        caught = None
        try:
            self.apply(p)
        except Exception as error:
            caught = error
        self.assertIsInstance(caught, ValueError, "提议必须在写入之前被拒绝")
        self.assertEqual((self.root / self.target).read_bytes(), before)

    def test_restore_exact_file_preserves_index_untracked_and_unrelated_changes(self):
        note = self.root / "notes/码头 手册.txt"
        note.write_bytes(note.read_bytes() + b"staged note\n")
        fixture.git(self.root, "add", "--", "notes/码头 手册.txt")
        staged = fixture.git(self.root, "diff", "--cached", "--binary").stdout
        note.write_bytes(note.read_bytes() + b"unstaged note\n")
        note_bytes = note.read_bytes()
        loose = self.root / "keep-untracked.txt"; loose.write_bytes(b"do not remove")
        saved = self.apply()
        args = {"path": saved["path"], "current_hash": saved["after_hash"], "restore_hash": saved["before_hash"]}
        restored = candidate.restore_patch(self.root, saved, grant("restore", args, token="restore-1"),
                                            "learner", 10, self.used, self.request["writable"])
        self.assertEqual(restored["sha256"], saved["before_hash"])
        self.assertEqual(note.read_bytes(), note_bytes)
        self.assertEqual(fixture.git(self.root, "diff", "--cached", "--binary").stdout, staged)
        self.assertEqual(loose.read_bytes(), b"do not remove")
        self.assertNotEqual(self.runner(self.root)["exit_code"], 0)

    def test_restore_will_not_overwrite_a_later_human_edit(self):
        saved = self.apply(); file = self.root / self.target
        file.write_bytes(file.read_bytes() + b"# newer decision\n"); changed = file.read_bytes()
        # The grant itself is current. It must not mask the separate rule that
        # a saved patch cannot overwrite later human work.
        args = {"path": saved["path"], "current_hash": hashlib.sha256(changed).hexdigest(), "restore_hash": saved["before_hash"]}
        with self.assertRaises(ValueError): candidate.restore_patch(self.root, saved, grant("restore", args), "learner", 10, set(), self.request["writable"])
        self.assertEqual(file.read_bytes(), changed)

    def test_true_child_runner_fails_then_passes_current_bytes(self):
        baseline = self.baseline()
        wrong = candidate.verify(self.root, baseline, self.request["observed"], self.runner)
        self.assertEqual(wrong["status"], "tests_failed")
        self.assertGreater(wrong["report"]["failures"], 0)
        self.apply()
        correct = candidate.verify(self.root, baseline, self.request["observed"], self.runner)
        self.assertEqual(correct["status"], "tests_passed")
        self.assertTrue(candidate.green_is_current(self.root, correct, self.request["observed"]))
        (self.root / "new-human-note.txt").write_text("new work")
        self.assertFalse(candidate.green_is_current(self.root, correct, self.request["observed"]))

    def test_green_expires_after_changed_byte_and_after_restore(self):
        baseline = self.baseline(); saved = self.apply()
        checked = candidate.verify(self.root, baseline, self.request["observed"], self.runner)
        file = self.root / self.target; file.write_bytes(file.read_bytes() + b"# changed\n")
        self.assertFalse(candidate.green_is_current(self.root, checked, self.request["observed"]))
        file.write_bytes(fixture.SCENARIOS["warehouse"]["correct"].encode())
        args = {"path": saved["path"], "current_hash": saved["after_hash"], "restore_hash": saved["before_hash"]}
        candidate.restore_patch(self.root, saved, grant("restore", args, token="restore-2"), "learner", 10, self.used, self.request["writable"])
        self.assertFalse(candidate.green_is_current(self.root, checked, self.request["observed"]))

    def test_protected_files_checked_before_and_after_runner(self):
        baseline = self.baseline(); calls = []
        path = self.root / "tests/test_contract.py"; original = path.read_bytes()
        path.write_bytes(original + b"# changed\n")
        report = candidate.verify(self.root, baseline, self.request["observed"], lambda root: calls.append(root))
        self.assertEqual(report["status"], "protected_changed"); self.assertEqual(calls, [])
        path.write_bytes(original)
        def changing(root):
            calls.append(root); path.write_bytes(original + b"# changed in run\n")
            return {"tests_run": 1, "failures": 0, "errors": 0, "exit_code": 0}
        report = candidate.verify(self.root, baseline, self.request["observed"], changing)
        self.assertEqual(report["status"], "protected_changed"); self.assertEqual(len(calls), 1)

    def test_exit_status_test_count_and_runner_exception_are_independent(self):
        baseline = self.baseline()
        for expected, row in [
            ("tests_failed", {"tests_run": 3, "failures": 0, "errors": 0, "exit_code": 1, "output": "PASSED"}),
            ("no_tests", {"tests_run": 0, "failures": 0, "errors": 0, "exit_code": 0}),
            ("tests_failed", {"tests_run": 3, "failures": 1, "errors": 0, "exit_code": 0}),
            ("invalid_report", {"tests_run": True, "failures": 0, "errors": 0, "exit_code": 0}),
        ]:
            calls = []
            def runner(root): calls.append(root); return row
            result = candidate.verify(self.root, baseline, self.request["observed"], runner)
            self.assertEqual(result["status"], expected); self.assertEqual(len(calls), 1)
        sentinel = RuntimeError("fixed runner unavailable")
        def raising(root): raise sentinel
        with self.assertRaises(RuntimeError) as caught: candidate.verify(self.root, baseline, self.request["observed"], raising)
        self.assertIs(caught.exception, sentinel)
        with self.assertRaises(ValueError): candidate.verify(self.root, {}, self.request["observed"], self.runner)

    def test_three_actual_fixtures_accept_different_valid_implementations(self):
        for scenario in fixture.SCENARIOS:
            for mode in ("correct", "alternative"):
                with self.subTest(scenario=scenario, mode=mode):
                    target = Path(self.tmp.name) / (scenario + "-" + mode)
                    request = fixture.create_fixture(target, scenario); spec = fixture.SCENARIOS[scenario]
                    baseline = candidate.fingerprints(target, request["protected"])
                    snap = candidate.read_snapshot(target, spec["target"])
                    p = candidate.propose_patch(target, spec["target"], snap["sha256"], spec["broken"], spec[mode], request["writable"])
                    args = {k: p[k] for k in ("path", "before_hash", "old", "new")}
                    candidate.apply_patch(target, p, grant("patch", args), "learner", 10, set(), request["writable"])
                    result = candidate.verify(target, baseline, request["observed"], fixture.trusted_runner(scenario))
                    self.assertEqual(result["status"], "tests_passed")

    def test_actual_child_process_cwd_is_not_a_boundary(self):
        outside = Path(self.tmp.name) / "owned-probe-outside.txt"; outside.write_bytes(b"original")
        probe = "import pathlib,sys,json; pathlib.Path(sys.argv[1]).write_bytes(b'changed'); print(json.dumps({'sandboxed':True,'nonce':'probe-1','completed':True}))"
        proc = subprocess.run([sys.executable, "-I", "-B", "-c", probe, str(outside)], cwd=self.root, capture_output=True, text=True, check=True)
        report = json.loads(proc.stdout)
        result = candidate.assess_probe(b"original", outside.read_bytes(), 0, b"", report, "probe-1")
        self.assertEqual(result, {"status": "unsafe", "violations": ["file"]})
        self.assertEqual(candidate.assess_probe(b"x", b"x", 0, b"", None, "new")["status"], "inconclusive")
        self.assertEqual(candidate.assess_probe(b"x", b"x", 0, b"", {"nonce": "old", "completed": True}, "new")["status"], "inconclusive")

    def test_real_loopback_and_fake_credential_observed_by_host(self):
        hits = []
        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                hits.append(self.path)
                self.send_response(200); self.end_headers(); self.wfile.write(b"owned local probe")
            def log_message(self, *args):
                pass
        server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
        leak = Path(self.tmp.name) / "owned-fake-leak.txt"
        fake = "lesson-only-not-a-real-secret"
        environment = {key: value for key, value in os.environ.items() if key in {"PATH", "SystemRoot", "WINDIR", "LANG"}}
        environment["PIPI_FAKE_CREDENTIAL"] = fake
        script = "import os,pathlib,sys,urllib.request,json; urllib.request.urlopen(sys.argv[1],timeout=3).read(); pathlib.Path(sys.argv[2]).write_text(os.environ['PIPI_FAKE_CREDENTIAL']); print(json.dumps({'sandboxed':True,'nonce':'fresh','completed':True}))"
        try:
            proc = subprocess.run([sys.executable, "-I", "-B", "-c", script,
                                   f"http://127.0.0.1:{server.server_port}/owned-probe", str(leak)],
                                  cwd=self.root, env=environment, text=True, capture_output=True, check=True, timeout=8)
        finally:
            server.shutdown(); server.server_close(); thread.join(timeout=3)
        self.assertEqual(hits, ["/owned-probe"])
        self.assertEqual(leak.read_text(), fake)
        result = candidate.assess_probe(b"unchanged", b"unchanged", len(hits), leak.read_bytes(), json.loads(proc.stdout), "fresh")
        self.assertEqual(result, {"status": "unsafe", "violations": ["network", "credential"]})

    def test_executor_is_selected_only_after_current_host_validation(self):
        calls = []
        def execute(): calls.append(True)
        row = {"configuration": "readonly-v1", "probe_status": "probe_passed", "expires_at": 20}
        for bad in [{}, {"x": {**row, "configuration": "another"}}, {"x": {**row, "probe_status": "inconclusive"}}, {"x": {**row, "expires_at": 10}}, {"x": {**row, "expires_at": True}}]:
            with self.assertRaises(PermissionError): candidate.executor_for("x", "readonly-v1", bad, {"x": execute}, 10)
        self.assertEqual(calls, [])
        self.assertIs(candidate.executor_for("x", "readonly-v1", {"x": row}, {"x": execute}, 10), execute)
        self.assertEqual(calls, [])

    def test_fixture_refuses_unregistered_python_and_keeps_plain_notes(self):
        (self.root / self.target).write_text(fixture.SCENARIOS["warehouse"]["correct"], encoding="utf-8")
        marker = Path(self.tmp.name) / "known-probe-marker.txt"
        extra = self.root / "tests/test_extra.py"
        extra.write_text("from pathlib import Path\nPath(" + repr(str(marker)) + ").write_text('known probe')\n", encoding="utf-8")
        with self.assertRaises(PermissionError):
            self.runner(self.root)
        self.assertFalse(marker.exists())
        extra.unlink()
        note = self.root / "notes/new-human-note.txt"
        note.write_bytes(b"preserve this ordinary note\r\n")
        result = self.runner(self.root)
        self.assertEqual(result["exit_code"], 0)
        self.assertEqual(result["tests_run"], 1)
        self.assertEqual(note.read_bytes(), b"preserve this ordinary note\r\n")

    def test_fixture_refuses_linked_executable_even_when_bytes_match(self):
        checker = self.root / "check_fixture.py"
        separate = Path(self.tmp.name) / "same-reviewed-checker.py"
        separate.write_bytes(checker.read_bytes())
        checker.unlink()
        checker.symlink_to(separate)
        with self.assertRaises(PermissionError):
            self.runner(self.root)


class HostContract(Contract):
    # Limit this subclass to host behavior rather than silently count inherited
    # cases twice; the custom loader below selects its four own cases.
    def test_host_final_without_verify_remains_unverified(self):
        result = host.run(self.root, self.request, lambda p: {"action": "final", "args": {}}, lambda *a: None, self.runner, candidate)
        self.assertEqual(result["status"], "unverified")

    def test_host_missing_approval_never_changes_bytes(self):
        p = self.proposal(); args = {k: p[k] for k in ("path", "before_hash", "old", "new")}
        decisions = iter([{"action": "patch", "args": args}, {"action": "final", "args": {}}])
        before = (self.root / self.target).read_bytes()
        result = host.run(self.root, self.request, lambda prompt: next(decisions), lambda *a: None, self.runner, candidate)
        self.assertEqual(result["status"], "unverified")
        self.assertEqual((self.root / self.target).read_bytes(), before)

    def test_host_real_patch_verify_checkpoint_and_changed_resume(self):
        p = self.proposal(); args = {k: p[k] for k in ("path", "before_hash", "old", "new")}
        decisions = iter([{"action": "search", "args": {"needle": "return"}}, {"action": "read", "args": {"path": self.target}},
                          {"action": "patch", "args": args}, {"action": "verify", "args": {}}, {"action": "final", "args": {}}])
        prompts = []
        def decide(prompt): prompts.append(prompt); return next(decisions)
        result = host.run(self.root, self.request, decide, lambda action, arguments: grant(action, arguments), self.runner, candidate)
        self.assertEqual(result["status"], "completed")
        self.assertEqual(result["verification"]["report"]["exit_code"], 0)
        self.assertTrue(all([x["id"] for x in prompt["context"][:2]] == ["task", "constraints"] for prompt in prompts))
        self.assertTrue(all(x["trust"] == "untrusted" for x in result["observations"]))
        copied = json.loads(json.dumps(result["checkpoint"]))
        self.assertEqual(host.inspect_checkpoint(self.root, copied, self.request, candidate)["status"], "ready_to_reverify")
        file = self.root / self.target; file.write_bytes(file.read_bytes() + b"# after restart\n")
        checked = host.inspect_checkpoint(self.root, copied, self.request, candidate)
        self.assertEqual(checked, {"status": "needs_refresh", "can_reuse_verification": False})

    def test_host_checks_final_again_after_real_green(self):
        p = self.proposal(); args = {k: p[k] for k in ("path", "before_hash", "old", "new")}
        decisions = iter([{"action": "patch", "args": args}, {"action": "verify", "args": {}}, {"action": "final", "args": {}}])
        def decide(prompt):
            row = next(decisions)
            if row["action"] == "final":
                file = self.root / self.target; file.write_bytes(file.read_bytes() + b"# after green\n")
            return row
        result = host.run(self.root, self.request, decide, lambda action, arguments: grant(action, arguments), self.runner, candidate)
        self.assertEqual(result["status"], "unverified")

    def test_host_model_cannot_supply_shell_or_approval(self):
        before = (self.root / self.target).read_bytes()
        for decision in [{"action": "shell", "args": {"command": "any command"}},
                         {"action": "patch", "args": {"grant": {"approved": True}}}]:
            result = host.run(self.root, self.request, lambda p: decision, lambda *a: None, self.runner, candidate)
            self.assertEqual(result["status"], "denied")
            self.assertEqual((self.root / self.target).read_bytes(), before)

    def test_host_final_with_extra_fields_is_denied_even_after_real_pass(self):
        p = self.proposal(); args = {k: p[k] for k in ("path", "before_hash", "old", "new")}
        decisions = iter([{"action": "patch", "args": args}, {"action": "verify", "args": {}},
                          {"action": "final", "args": {"unapproved_extra": "not allowed"}}])
        result = host.run(self.root, self.request, lambda prompt: next(decisions),
                          lambda action, arguments: grant(action, arguments), self.runner, candidate)
        self.assertEqual(result["verification"]["status"], "tests_passed")
        self.assertEqual(result["status"], "denied")

    def test_host_checkpoint_is_rechecked_in_a_new_python_process(self):
        checkpoint = {"schema": "pipi-repair-checkpoint/v1", "task": self.request["task"],
                      "constraints": self.request["constraints"], "current_hashes": candidate.fingerprints(self.root, self.request["observed"]),
                      "status": "completed"}
        state_path = Path(self.tmp.name) / "checkpoint.json"
        state_path.write_text(json.dumps({"request": self.request, "checkpoint": checkpoint}), encoding="utf-8")
        script = '''import importlib.util,json,pathlib,sys
def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
tools=load(sys.argv[1],"tools");host=load(sys.argv[2],"host")
record=json.loads(pathlib.Path(sys.argv[3]).read_text(encoding="utf-8"))
print(json.dumps(host.inspect_checkpoint(sys.argv[4],record["checkpoint"],record["request"],tools)))
'''
        command = [sys.executable, "-I", "-B", "-c", script, str(Path(candidate.__file__).resolve()),
                   str(Path(host.__file__).resolve()), str(state_path), str(self.root)]
        first = subprocess.run(command, text=True, capture_output=True, check=True)
        self.assertEqual(json.loads(first.stdout), {"status": "ready_to_reverify", "can_reuse_verification": False})
        added = self.root / "new-human-file.txt"; added.write_text("new work after checkpoint")
        extra = subprocess.run(command, text=True, capture_output=True, check=True)
        self.assertEqual(json.loads(extra.stdout), {"status": "needs_refresh", "can_reuse_verification": False})
        added.unlink()
        file = self.root / self.target; file.write_bytes(file.read_bytes() + b"# human edit across restart\n")
        second = subprocess.run(command, text=True, capture_output=True, check=True)
        self.assertEqual(json.loads(second.stdout), {"status": "needs_refresh", "can_reuse_verification": False})


def load_tests(loader, tests, pattern):
    suite = unittest.TestSuite(loader.loadTestsFromTestCase(Contract))
    suite.addTests(HostContract(name) for name in sorted(HostContract.__dict__) if name.startswith("test_host_"))
    return suite
