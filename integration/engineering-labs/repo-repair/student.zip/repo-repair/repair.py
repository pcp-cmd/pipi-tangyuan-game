"""Your implementation. Read LEARN.md, then implement one contract at a time.

All paths refer to the temporary teaching repository supplied by the caller.
Do not run unknown submissions or treat cwd as operating-system isolation.
"""


def list_repo(root):
    """Sorted POSIX relative names; omit links, .git, environments and caches."""
    raise NotImplementedError("先完成文件清单，观察真实仓库中有哪些文件")


def read_snapshot(root, name):
    """Return path, sha256(raw bytes), strict UTF-8 text, and raw byte count."""
    raise NotImplementedError("实现有边界的读取，保留原换行")


def search_repo(root, needle):
    """Return ordered {path,line,text} hits; line numbers begin at one."""
    raise NotImplementedError("先搜索线索，再读取完整文件")


def propose_patch(root, name, before_hash, old, new, writable):
    """Return proposal fields from CONTRACT.md. Do not write anything."""
    raise NotImplementedError("检查修改权限、当前摘要和唯一旧片段")


def authorize(grant, actor, action, arguments, now, used):
    """Validate a HOST-issued grant; return its id without consuming it."""
    raise NotImplementedError("批准要绑定这次实际参数，不能相信模型自报")


def apply_patch(root, proposal, grant, actor, now, used, writable):
    """Validate, consume grant at write, replace one file, read it back."""
    raise NotImplementedError("只写获准文件，返回真实前后字节摘要")


def restore_patch(root, saved, grant, actor, now, used, writable):
    """Restore only if current bytes equal saved after_hash; preserve others."""
    raise NotImplementedError("有界恢复不能清掉其他人的工作")


def fingerprints(root, names):
    """Map a nonempty explicit relative-name list to raw-byte SHA256 values."""
    raise NotImplementedError("验收基线要在修改前形成")


def verify(root, protected_hashes, observed_names, runner):
    """Check protected files before/after one trusted run; bind current tree."""
    raise NotImplementedError("分别判断测试数、退出状态、文件变化")


def green_is_current(root, verification, observed_names):
    """A success belongs to the exact verified file set and bytes."""
    raise NotImplementedError("最终交付前再次检查当前源码")


def assess_probe(original, outside_after, network_hits, credential_leak, report, nonce):
    """Use host observations; unsafe overrides incomplete or self-reported proof."""
    raise NotImplementedError("先看实际效果；缺证据只能是不确定")


def executor_for(executor_id, configuration, validations, executors, now):
    """Select but do not call a current validated, explicitly registered executor."""
    raise NotImplementedError("没有有效登记时保持执行关闭")
