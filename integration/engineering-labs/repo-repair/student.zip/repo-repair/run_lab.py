"""Run your own reviewed host on the authored local fixture.

No uploaded programs, API keys, network services or arbitrary shell actions.
This script imports repair.py and host.py, so review your own edits first.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import fixture


def encode(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description="在独立教学仓库运行自己的修补主机")
    actions = parser.add_mutually_exclusive_group(required=True)
    actions.add_argument("--setup", choices=sorted(fixture.SCENARIOS))
    actions.add_argument("--run", action="store_true")
    actions.add_argument("--resume", action="store_true")
    parser.add_argument("--output", required=True)
    choice = parser.add_mutually_exclusive_group()
    choice.add_argument("--decisions")
    choice.add_argument("--planner", help="你自己审阅过的Python文件，定义decide(prompt)")
    args = parser.parse_args()
    output = Path(args.output).resolve()
    if args.setup:
        if output.exists():
            parser.error("输出目录已经存在，请用一个新目录；不会覆盖旧成果")
        output.mkdir(parents=True)
        request = fixture.create_fixture(output / "repo", args.setup)
        write(output / "request.json", request)
        baseline = fixture.trusted_runner(args.setup)(output / "repo")
        write(output / "baseline.json", baseline)
        print(json.dumps({"status": "fixture_ready", "repository": str(output / "repo"),
                          "task": request["task"], "baseline_exit": baseline["exit_code"],
                          "next": "实现自己的模块，准备决策，再用--run；修改前失败是预期现象。"}, ensure_ascii=False))
        return 0
    import repair
    import host
    request = json.loads((output / "request.json").read_text(encoding="utf-8"))
    scenario = request["scenario"]
    if scenario not in fixture.SCENARIOS:
        parser.error("这不是支持的教学fixture；陌生项目请使用自己的受控工程")
    repo = output / "repo"
    if args.resume:
        checkpoint = json.loads((output / "CHECKPOINT.json").read_text(encoding="utf-8"))
        result = host.inspect_checkpoint(repo, checkpoint, request, repair)
        print(json.dumps(result, ensure_ascii=False))
        return 0
    if not args.decisions and not args.planner:
        parser.error("--run需要你自己的--decisions或--planner，默认不会自动解题")
    if args.decisions:
        decisions = json.loads(Path(args.decisions).read_text(encoding="utf-8"))
        if not isinstance(decisions, list) or len(decisions) > 40:
            parser.error("决策文件应是最多40项的JSON数组")
        queue = iter(decisions)
        def decide(prompt):
            return next(queue, {"action": "final", "args": {}})
    else:
        spec = importlib.util.spec_from_file_location("own_reviewed_planner", Path(args.planner).resolve())
        planner = importlib.util.module_from_spec(spec); spec.loader.exec_module(planner)
        decide = planner.decide
    issued = 0
    def approve(action, arguments):
        nonlocal issued
        proposal = repair.propose_patch(repo, arguments["path"], arguments["before_hash"],
                                        arguments["old"], arguments["new"], request["writable"])
        digest = hashlib.sha256(encode(arguments).encode("utf-8")).hexdigest()
        print("\n拟执行的实际修改：\n" + proposal["diff"], flush=True)
        print("批准参数SHA256：" + digest, flush=True)
        response = input("确认此项后输入完整摘要；直接回车拒绝：").strip()
        if response != digest:
            return None
        issued += 1
        return {"id": "terminal-grant-" + str(issued), "actor": request["actor"], "action": action,
                "arguments_sha256": digest, "expires_at": 40}
    result = host.run(repo, request, decide, approve, fixture.trusted_runner(scenario), repair)
    runs = output / "runs"; runs.mkdir(exist_ok=True)
    number = 1
    while (runs / str(number)).exists():
        number += 1
    run_dir = runs / str(number); run_dir.mkdir()
    write(run_dir / "RESULT.json", result)
    write(output / "CHECKPOINT.json", result["checkpoint"])
    (run_dir / "DIFF.patch").write_text(fixture.git(repo, "diff", "--binary").stdout, encoding="utf-8")
    (run_dir / "GIT-STATUS.txt").write_text(fixture.git(repo, "status", "--short").stdout, encoding="utf-8")
    print(json.dumps({"status": result["status"], "record": str(run_dir), "independentMastery": "not-assessed"}, ensure_ascii=False))
    return 0 if result["status"] == "completed" else 2


if __name__ == "__main__":
    raise SystemExit(main())
