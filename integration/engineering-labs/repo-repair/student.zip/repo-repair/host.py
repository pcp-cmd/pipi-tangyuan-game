"""Your bounded coding host, using your repair module and trusted callbacks."""


def run(root, request, decide, approve, runner, tools, now=10, budget=12):
    """Implement the read/propose/approve/patch/verify/final loop in CONTRACT.md."""
    raise NotImplementedError("先让最终提交保持未验证，再逐步接真实工具")


def inspect_checkpoint(root, checkpoint, request, tools):
    """Return needs_review, needs_refresh or ready_to_reverify; never reuse green."""
    raise NotImplementedError("重启后重新核对文件与约束，不复活批准")
