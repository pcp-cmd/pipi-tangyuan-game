"""Independent task: read TRANSFER.md before implementing this module."""


def reminders(loans, today, grace=0):
    """Validate every record and return new reminder rows in input order."""
    raise NotImplementedError("独立设计到期边界、已归还和坏输入处理")


def main(argv=None):
    """--input PATH --output PATH --today N [--grace N]; return 0 or 2."""
    raise NotImplementedError("先完整验证，再替换输出；错误时保留旧报告")
