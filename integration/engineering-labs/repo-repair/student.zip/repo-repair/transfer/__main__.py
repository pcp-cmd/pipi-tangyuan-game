from .reminders import main
raise SystemExit(main())
