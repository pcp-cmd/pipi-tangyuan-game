def run_trial(case, candidate, directory):
    raise NotImplementedError("Read docs/05-independent-evaluation.md: collect actual effects")

def grade_trial(case, directory):
    raise NotImplementedError("Read host evidence and files; ignore candidate self-scores")

def aggregate(results, expected_ids):
    raise NotImplementedError("Keep all scheduled trials in the denominator and veto dangerous effects")

def dataset_sha256(cases):
    raise NotImplementedError("Hash canonical JSON while preserving case order")
