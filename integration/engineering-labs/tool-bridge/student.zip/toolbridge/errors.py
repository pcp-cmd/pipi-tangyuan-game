class DomainError(ValueError):
    def __init__(self, code):
        super().__init__(code)
        self.code = code


class TransportError(RuntimeError):
    pass


class HttpStatusError(RuntimeError):
    def __init__(self, status):
        super().__init__(str(status))
        self.status = status


class ResponseFormatError(ValueError):
    pass


class BusinessContractError(ValueError):
    pass


class ProtocolError(RuntimeError):
    pass


class RpcError(RuntimeError):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code
