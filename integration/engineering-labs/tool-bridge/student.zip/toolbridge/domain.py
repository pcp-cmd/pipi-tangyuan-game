from .errors import BusinessContractError, DomainError

def decode_json(raw):
    raise NotImplementedError("Read docs/01-json-cli.md: reject non-finite JSON numbers")

def load_catalog(path):
    raise NotImplementedError("Load UTF-8 JSON and validate the complete catalog")

def validate_catalog(catalog):
    raise NotImplementedError("Read docs/CONTRACT.md: validate every catalog entry")

def quote(catalog, request):
    raise NotImplementedError("Build a read-only quote from the documented contract")

def validate_quote(value):
    raise NotImplementedError("Validate an untrusted quote response without truthy coercion")

def slot_availability(schedule, request):
    raise NotImplementedError("Read docs/06-transfer.md: half-open time windows")
