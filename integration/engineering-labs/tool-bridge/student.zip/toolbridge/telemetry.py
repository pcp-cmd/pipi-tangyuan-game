import time

def write_event(path, row):
    raise NotImplementedError("Read docs/04-traces.md: allowlisted UTF-8 append, one writer per file")

def read_events(path):
    raise NotImplementedError("Preserve an incomplete final line and report its uncertainty")

def summarize(rows):
    raise NotImplementedError("Pair by run and span, retain parents and incomplete status")

async def observe(path, *, run_id, span_id, parent, operation_id, kind, operation, attempt=1, clock=time.perf_counter):
    raise NotImplementedError("Actually await the operation and propagate failure or cancellation")
