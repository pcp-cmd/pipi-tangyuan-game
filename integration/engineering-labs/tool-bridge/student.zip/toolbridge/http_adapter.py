from .errors import BusinessContractError, HttpStatusError, ResponseFormatError, TransportError

def make_server(catalog, port=0):
    raise NotImplementedError("Read docs/02-http.md: explicit loopback-only server")

def serve(catalog_path, port=0):
    raise NotImplementedError("Load catalog, announce the selected port, serve and close")

def fetch_quote(url, request, timeout=2):
    raise NotImplementedError("Distinguish transport, HTTP, JSON and business failures")
