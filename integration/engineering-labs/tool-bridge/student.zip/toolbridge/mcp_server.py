PROTOCOL_VERSION = "2025-11-25"

class Server:
    def __init__(self, catalog):
        raise NotImplementedError("Model new, initialized and ready states")

    def handle(self, message):
        raise NotImplementedError("Read docs/03-mcp.md and the fixed tools subset contract")

def serve(catalog_path):
    raise NotImplementedError("Read bounded UTF-8 JSON lines, write only protocol lines and flush")
