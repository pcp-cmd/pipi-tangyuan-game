class Client:
    def __init__(self, command, *, timeout=2, env=None, cwd=None):
        raise NotImplementedError("Read docs/03-mcp.md: command is an argument list")

    async def __aenter__(self):
        raise NotImplementedError("Start actual process, initialize and notify readiness")

    async def __aexit__(self, *exc):
        raise NotImplementedError("Close input, wait, terminate if needed and reap")

    async def notify(self, method, params=None):
        raise NotImplementedError("A notification has no id and receives no response")

    async def request(self, method, params=None, *, initializing=False):
        raise NotImplementedError("Correlate exact id under a total deadline; one pending request")

    async def call_quote(self, sku, quantity):
        raise NotImplementedError("Distinguish protocol and tool execution errors")

    async def close(self):
        raise NotImplementedError("Invalidate the connection and wait for process exit")
