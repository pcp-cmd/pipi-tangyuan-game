def main(argv=None):
    raise NotImplementedError("Read docs/01-json-cli.md: arguments, streams and exit status")
