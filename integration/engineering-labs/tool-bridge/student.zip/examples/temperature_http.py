import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from temperature_cli import convert


def run_demo(value):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def do_POST(self):
            try:
                length = int(self.headers.get("Content-Length", "-1"))
                if not 0 <= length <= 1024:
                    raise ValueError("invalid body length")
                result = convert(json.loads(self.rfile.read(length).decode("utf-8")))
                body = json.dumps(result, allow_nan=False).encode("utf-8")
                status = 200
            except (ValueError, UnicodeError):
                body, status = b'{"error":"invalid_temperature"}', 400
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=lambda: server.serve_forever(poll_interval=0.01))
    thread.start()
    try:
        request = Request(f"http://127.0.0.1:{server.server_port}/temperature", data=json.dumps(value).encode("utf-8"), headers={"Content-Type": "application/json"})
        try:
            with urlopen(request, timeout=2) as response:
                observed = {"status": response.status, "body": json.loads(response.read())}
        except HTTPError as error:
            with error:
                observed = {"status": error.code, "body": json.loads(error.read())}
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)
    assert not thread.is_alive() and server.socket.fileno() == -1
    return {**observed, "server_thread_closed": True, "socket_closed": True}


if __name__ == "__main__":
    valid = run_demo({"celsius": 20})
    invalid = run_demo({"celsius": "warm"})
    assert valid["status"] == 200 and valid["body"] == {"fahrenheit": 68.0}
    assert invalid["status"] == 400 and invalid["body"] == {"error": "invalid_temperature"}
    print(json.dumps({"valid": valid, "invalid": invalid}))
