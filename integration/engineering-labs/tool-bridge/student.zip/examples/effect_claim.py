import tempfile
from pathlib import Path


with tempfile.TemporaryDirectory() as directory:
    actual = Path(directory) / "draft.txt"
    candidate_reply = {"saved": True, "score": 1}
    assert candidate_reply["saved"] and not actual.exists()
    print({"candidate_said_saved": True, "file_observed": actual.exists()})
    actual.write_text("A real draft", encoding="utf-8")
    print({"file_observed": actual.exists(), "readback": actual.read_text(encoding="utf-8")})
