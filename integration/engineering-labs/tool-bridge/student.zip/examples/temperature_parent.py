import json
import subprocess
import sys
from pathlib import Path


child = Path(__file__).with_name("temperature_cli.py")
result = subprocess.run([sys.executable, str(child)], input=json.dumps({"celsius": 20}), capture_output=True, text=True, encoding="utf-8", timeout=3)
assert result.returncode == 0
assert json.loads(result.stdout)["result"]["fahrenheit"] == 68
print(json.dumps({"child_exit": result.returncode, "parsed_result": json.loads(result.stdout)}))
