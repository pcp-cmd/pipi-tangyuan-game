import argparse
import json
import sys


def convert(value):
    if not isinstance(value, dict) or set(value) != {"celsius"} or type(value["celsius"]) not in (int, float):
        raise ValueError("expected a celsius number")
    return {"fahrenheit": value["celsius"] * 9 / 5 + 32}


def main():
    argparse.ArgumentParser(allow_abbrev=False).parse_args()
    try:
        result = convert(json.loads(sys.stdin.read()))
    except (ValueError, TypeError):
        print(json.dumps({"ok": False, "error": "invalid_temperature"}))
        print("temperature input rejected", file=sys.stderr)
        return 2
    print(json.dumps({"ok": True, "result": result}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
