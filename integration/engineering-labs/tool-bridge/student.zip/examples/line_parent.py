import asyncio
import json
import sys
from pathlib import Path


async def main():
    process = await asyncio.create_subprocess_exec(sys.executable, str(Path(__file__).with_name("line_peer.py")), stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE)
    try:
        process.stdin.write((json.dumps({"id": "word-1", "word": "shell"}) + "\n").encode("utf-8"))
        await process.stdin.drain()
        async with asyncio.timeout(2):
            line = await process.stdout.readline()
        result = json.loads(line)
        assert result["id"] == "word-1" and result["length"] == 5
        print(result)
    finally:
        process.stdin.close()
        try:
            await asyncio.wait_for(process.wait(), 0.3)
        except TimeoutError:
            process.kill()
            await process.wait()


if __name__ == "__main__":
    asyncio.run(main())
