import json
import sys


for line in sys.stdin:
    request = json.loads(line)
    print(json.dumps({"id": request["id"], "length": len(request["word"])}), flush=True)
