starts = [("left", 1), ("right", 2)]
ends = [("right", 4), ("left", 9)]
wrong = [(begin[0], end[1] - begin[1]) for begin, end in zip(starts, ends)]
start_by_id = dict(starts)
paired = [(name, stop - start_by_id[name]) for name, stop in ends]
print({"position_pairing": wrong, "identity_pairing": paired})
assert dict(paired) == {"right": 2, "left": 8}
