import json
import sys
import time


mode = sys.argv[1]
for line in sys.stdin:
    message = json.loads(line)
    if "id" not in message:
        continue
    identifier = message["id"]
    if message["method"] == "initialize":
        value = {"protocolVersion": "2025-11-25", "capabilities": {"tools": {}}, "serverInfo": {"name": "test-peer", "version": "1"}}
        print(json.dumps({"jsonrpc": "2.0", "id": True if mode == "bool-initialize" else identifier, "result": value}), flush=True)
        continue
    if mode == "eof":
        break
    if mode == "banner":
        print("welcome banner", flush=True)
        continue
    if mode in {"timeout", "notification-timeout"}:
        while True:
            if mode == "notification-timeout":
                print(json.dumps({"jsonrpc": "2.0", "method": "notifications/message", "params": {"level": "info", "data": "waiting"}}), flush=True)
            time.sleep(0.01)
    if mode == "delay":
        time.sleep(0.1)
    if mode == "stderr":
        sys.stderr.write("diagnostic\n" * 20000)
        sys.stderr.flush()
    print(json.dumps({"jsonrpc": "2.0", "method": "notifications/message", "params": {"level": "info", "data": "request observed"}}), flush=True)
    response_id = identifier + 1 if mode == "wrong-id" else True if mode == "bool-id" else identifier
    print(json.dumps({"jsonrpc": "2.0", "id": response_id, "result": {"tools": []}}), flush=True)
