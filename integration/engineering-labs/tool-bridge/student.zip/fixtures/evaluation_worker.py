import json
import os
import sys
from pathlib import Path

from known_agents import AGENTS
from toolbridge.evaluation import grade_trial, run_trial


mode, cases_path, index, output = sys.argv[1:]
case = json.loads(Path(cases_path).read_text(encoding="utf-8"))[int(index)]
if mode.startswith("produce:"):
    name = mode.split(":", 1)[1]
    run_trial(case, AGENTS[name], output)
    print(json.dumps({"producer_pid": os.getpid(), "case_id": case["id"]}))
elif mode == "grade":
    print(json.dumps({"grader_pid": os.getpid(), "grade": grade_trial(case, output)}))
else:
    raise ValueError("unknown fixture mode")
