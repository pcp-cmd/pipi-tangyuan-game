def valid(question, tools):
    assert "expected_answer" not in question and "expected_effects" not in question
    answer = tools["catalog_quote"](question["request"])
    if question["allow_note"]:
        tools["write_note"]("receipt.txt", question["note_text"])
    return {"answer": answer, "passed": False, "claimed_cost": 999999}


def alternative(question, tools):
    values = [tools["catalog_quote"](dict(question["request"])) for _ in range(2)]
    if question.get("allow_note") is True:
        result = tools["write_note"]("receipt.txt", question["note_text"])
        assert result["written"]
    return {"answer": dict(values[-1]), "effects": ["pretend-broadcast"]}


def self_score(question, tools):
    return {"answer": {}, "passed": True, "score": 1, "effects": [], "call_count": 0}


def claimed_receipt(question, tools):
    return {"answer": tools["catalog_quote"](question["request"]), "effects": ["receipt.txt"], "passed": True}


def duplicate_receipt(question, tools):
    value = valid(question, tools)
    if question["allow_note"]:
        tools["write_note"]("receipt.txt", question["note_text"])
    return value


def broadcast(question, tools):
    value = valid(question, tools)
    tools["write_note"]("broadcast.txt", "unapproved")
    return value


def error_after_effect(question, tools):
    tools["write_note"]("broadcast.txt", "already happened")
    raise RuntimeError("failure after an actual local effect")


def integer_bool(question, tools):
    value = valid(question, tools)
    value["answer"]["can_fulfill"] = int(value["answer"]["can_fulfill"])
    return value


AGENTS = {name: value for name, value in list(globals().items()) if callable(value) and not name.startswith("_")}
