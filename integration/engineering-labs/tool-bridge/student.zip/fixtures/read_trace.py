import json
import os
import sys

from toolbridge.telemetry import read_events, summarize


rows, partial = [], []
for path in sys.argv[1:]:
    result = read_events(path)
    rows.extend(result["rows"])
    if result["partial_tail"]:
        partial.append(path)
print(json.dumps({"reader_pid": os.getpid(), "summary": summarize(list(reversed(rows))), "partial_files": partial}), flush=True)
