import json
import os
import signal
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass
    def do_POST(self):
        self.rfile.read(int(self.headers.get("Content-Length", 0)))
        body = b'{"ok":true,"result":{"sku":"x","quantity":1,"available":2,"total_cents":9,"can_fulfill":true}}'
        self.send_response(200)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
signal.signal(signal.SIGTERM, signal.SIG_IGN)
Path(sys.argv[2]).write_text(json.dumps({"pid": os.getpid(), "port": server.server_port}), encoding="utf-8")
print("not JSON" if sys.argv[1] == "invalid" else json.dumps({"ready": True, "host": "127.0.0.1", "port": server.server_port}), flush=True)
server.serve_forever()
