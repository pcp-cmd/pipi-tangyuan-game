import asyncio
import json
import os
import sys
import time
from pathlib import Path

from toolbridge.telemetry import observe


async def wait_for(path):
    deadline = time.monotonic() + 5
    while not path.exists():
        if time.monotonic() >= deadline:
            raise TimeoutError("fixture barrier timed out")
        await asyncio.sleep(0.005)


async def main():
    name, folder = sys.argv[1], Path(sys.argv[2])
    path = folder / f"{name}.jsonl"
    async def observed(span, operation, attempt=1):
        return await observe(path, run_id="cross-process", span_id=span, parent="root", operation_id="read-notice" if name == "left" else "read-new", kind="tool", operation=operation, attempt=attempt)
    if name == "left":
        async def left_read():
            (folder / "left.ready").write_text("ready", encoding="utf-8")
            await wait_for(folder / "release")
            return (folder / "notice.txt").read_text(encoding="utf-8")
        result = await observed("left.read", left_read)
    else:
        await wait_for(folder / "left.ready")
        async def right_read():
            return (folder / "new.txt").read_text(encoding="utf-8")
        try:
            await observed("right.try-1", right_read)
        except FileNotFoundError:
            (folder / "new.txt").write_text("new observation", encoding="utf-8")
        else:
            raise AssertionError("fixture must exercise a real missing file")
        result = await observed("right.try-2", right_read, attempt=2)
        (folder / "release").write_text("ready", encoding="utf-8")
    print(json.dumps({"pid": os.getpid(), "worker": name, "result": result}), flush=True)


if __name__ == "__main__":
    asyncio.run(main())
