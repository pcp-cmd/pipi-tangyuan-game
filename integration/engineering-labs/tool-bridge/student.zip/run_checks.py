import argparse
import os
import subprocess
import sys
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--group", choices=["domain", "transports", "mcp", "telemetry", "evaluation", "transfer", "resources", "all"], default="all")
    args = parser.parse_args()
    if sys.version_info < (3, 11):
        raise SystemExit("Python 3.11 or later is required for asyncio.timeout")
    root = Path(__file__).resolve().parent
    environment = dict(os.environ)
    environment["PYTHONPATH"] = os.pathsep.join([str(root), str(root / "tests")])
    environment["PYTHONUTF8"] = "1"
    pattern = "test_*.py" if args.group == "all" else f"test_{args.group}.py"
    return subprocess.call([sys.executable, "-m", "unittest", "discover", "-s", "tests", "-p", pattern, "-v"], cwd=root, env=environment)


if __name__ == "__main__":
    raise SystemExit(main())
