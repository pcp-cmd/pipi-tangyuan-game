import argparse
import asyncio
import hashlib
import json
import os
import platform
import queue
import subprocess
import sys
import threading
import time
from pathlib import Path

import toolbridge
from toolbridge.evaluation import aggregate, dataset_sha256
from toolbridge.http_adapter import fetch_quote
from toolbridge.mcp_client import Client
from toolbridge.telemetry import write_event


ROOT = Path(__file__).resolve().parent
FIXTURES = ROOT / "fixtures"


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + "\n", encoding="utf-8")


def run(command, *, raw=None, cwd=None):
    result = subprocess.run(command, input=raw, cwd=cwd, capture_output=True, text=True, encoding="utf-8", timeout=8)
    if result.returncode:
        raise RuntimeError(f"fixture command exited {result.returncode}: {result.stderr}")
    return json.loads(result.stdout)


def bindings():
    package = Path(toolbridge.__file__).resolve().parent
    files = list(package.glob("*.py")) + list(FIXTURES.glob("*")) + [Path(__file__).resolve()]
    return {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(files) if path.is_file()}


def stop_process(process):
    forced = False
    if process.poll() is None:
        process.terminate()
    try:
        process.communicate(timeout=0.3)
    except subprocess.TimeoutExpired:
        forced = True
        process.kill()
        process.communicate(timeout=3)
    return {"process_returncode": process.returncode, "forced_kill": forced}


def http_quote(command, request):
    server = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8")
    original = None
    try:
        lines = queue.Queue()
        threading.Thread(target=lambda: lines.put(server.stdout.readline()), daemon=True).start()
        ready = json.loads(lines.get(timeout=3))
        assert ready["host"] == "127.0.0.1"
        value = fetch_quote(f'http://127.0.0.1:{ready["port"]}/quote', request)
        result = {"server_pid": server.pid, "port": ready["port"], "host": ready["host"], "result": value}
    except BaseException as error:
        original = error
        original.http_process_pid = server.pid
        raise
    finally:
        try:
            cleanup = stop_process(server)
            if original is not None:
                original.http_process_returncode = server.returncode
        except Exception as cleanup_error:
            if original is None:
                raise
            original.http_cleanup_error = cleanup_error
            original.add_note("HTTP cleanup failed: " + type(cleanup_error).__name__)
    return {**result, **cleanup}


async def stdio_experiment():
    client = Client([sys.executable, "-m", "toolbridge", "serve-mcp", "--catalog", str(FIXTURES / "catalog.json")])
    async with client:
        tools = await client.request("tools/list")
        assert [tool["name"] for tool in tools["tools"]] == ["catalog_quote"]
        result = await client.call_quote("SHELL-LAMP", 2)
        assert result["total_cents"] == 750
        pid = client.process.pid
    assert client.process.returncode == 0
    return {"server_pid": pid, "result": result, "process_returncode": client.process.returncode, "closed": client.closed}


def exercise(output):
    before = bindings()
    package = str(Path(toolbridge.__file__).resolve().parent.parent)
    os.environ["PYTHONPATH"] = os.pathsep.join([package, str(ROOT / "tests")])
    os.environ["PYTHONUTF8"] = "1"
    report = {"checks_passed": False, "scope": "actual Python subprocess, loopback and files on this host; no browser or Windows claim", "platform": platform.platform(), "python": sys.version, "host_pid": os.getpid(), "source_bindings": before}
    try:
        cli = run([sys.executable, "-m", "toolbridge", "quote", "--catalog", str(FIXTURES / "catalog.json")], raw='{"sku":"SHELL-LAMP","quantity":2}', cwd=output)
        assert cli["result"]["total_cents"] == 750
        dump(output / "cli.json", cli)
        http = http_quote([sys.executable, "-m", "toolbridge", "serve-http", "--catalog", str(FIXTURES / "catalog.json")], {"sku": "SHELL-LAMP", "quantity": 2})
        assert http["result"] == cli["result"]
        dump(output / "http.json", http)
        stdio = asyncio.run(stdio_experiment())
        assert stdio["result"] == cli["result"]
        dump(output / "stdio.json", stdio)
        traces = output / "traces"
        traces.mkdir()
        (traces / "notice.txt").write_text("left observation", encoding="utf-8")
        base = {"run_id": "cross-process", "span_id": "root", "parent": None, "operation_id": "experiment"}
        write_event(traces / "root.jsonl", {**base, "event": "span_started", "kind": "run", "attempt": 1, "time_ms": time.perf_counter() * 1000})
        children = [subprocess.Popen([sys.executable, str(FIXTURES / "trace_worker.py"), name, str(traces)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8") for name in ("left", "right")]
        workers = []
        try:
            for child in children:
                stdout, stderr = child.communicate(timeout=8)
                assert child.returncode == 0, stderr
                workers.append(json.loads(stdout))
        finally:
            for child in children:
                if child.poll() is None:
                    child.kill()
                    child.wait(timeout=3)
        write_event(traces / "root.jsonl", {**base, "event": "span_finished", "status": "ok", "time_ms": time.perf_counter() * 1000})
        readback = run([sys.executable, str(FIXTURES / "read_trace.py"), str(traces / "right.jsonl"), str(traces / "root.jsonl"), str(traces / "left.jsonl")])
        assert len({os.getpid(), readback["reader_pid"], *(row["pid"] for row in workers)}) == 4
        statuses = {row["span_id"]: row["status"] for row in readback["summary"]["spans"]}
        assert statuses == {"left.read": "ok", "right.try-1": "error", "right.try-2": "ok", "root": "ok"}
        assert readback["summary"]["issues"] == []
        dump(output / "trace-readback.json", {"workers": workers, **readback})
        original_cases = json.loads((FIXTURES / "evaluation_cases.json").read_text(encoding="utf-8"))
        plan = [("valid", 0), ("valid", 1), ("broadcast", 0), ("error_after_effect", 0)]
        cases = [{**original_cases[index], "id": f"experiment-{number}"} for number, (_, index) in enumerate(plan)]
        cases_path = output / "evaluation-cases.json"
        dump(cases_path, cases)
        grades, eval_processes = [], []
        for index, (agent, _) in enumerate(plan):
            trial = output / f"trial-{index}"
            producer = run([sys.executable, str(FIXTURES / "evaluation_worker.py"), "produce:" + agent, str(cases_path), str(index), str(trial)])
            grader = run([sys.executable, str(FIXTURES / "evaluation_worker.py"), "grade", str(cases_path), str(index), str(trial)])
            assert producer["producer_pid"] != grader["grader_pid"]
            grades.append(grader["grade"])
            eval_processes.append({"producer_pid": producer["producer_pid"], "grader_pid": grader["grader_pid"], "agent_fixture": agent})
        evaluation = aggregate(grades, [case["id"] for case in cases])
        assert evaluation["functional_passes"] == 2 and evaluation["dangerous_trials"] == 2 and evaluation["ready"] is False
        dump(output / "independent-evaluation.json", {"dataset_sha256": dataset_sha256(cases), "processes": eval_processes, **evaluation})
        transfer = run([sys.executable, "-m", "toolbridge", "check-slot", "--schedule", str(FIXTURES / "schedule.json")], raw='{"station":"north","start":540,"end":570}', cwd=output)
        assert transfer["result"] == {"station": "north", "start": 540, "end": 570, "available": True, "conflict_ids": []}
        dump(output / "transfer.json", transfer)
        report.update({"transports_equal": True, "stdio_reaped": True, "actual_trace_workers": 2, "independent_trace_reader": True, "scheduled_evaluation_trials": 4, "valid_trials_passed": 2, "dangerous_fixtures_rejected": 2, "transfer_actual_cli": True, "sourceStable": before == bindings()})
        report["checks_passed"] = report["sourceStable"]
    except BaseException as error:
        report.update({"error_type": type(error).__name__, "error": str(error), "sourceStable": before == bindings()})
        dump(output / "report.json", report)
        raise
    dump(output / "report.json", report)
    assert report["checks_passed"]
    return report


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=False)
    result = exercise(output)
    print(json.dumps({"checks_passed": result["checks_passed"], "sourceStable": result["sourceStable"], "evidence": str(output)}))


if __name__ == "__main__":
    main()
