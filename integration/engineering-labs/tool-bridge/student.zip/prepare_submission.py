import argparse
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def digest(data):
    return hashlib.sha256(data).hexdigest()


def prepare(evidence, output):
    evidence = Path(evidence).resolve()
    output = Path(output).resolve()
    if output.exists():
        raise ValueError("choose a new output directory")
    report = json.loads((evidence / "report.json").read_text(encoding="utf-8"))
    if report.get("sourceStable") is not True or not isinstance(report.get("source_bindings"), dict):
        raise ValueError("the selected run has no stable source bindings")
    bound = report["source_bindings"]
    expected_sources = list((ROOT / "toolbridge").glob("*.py")) + [path for path in (ROOT / "fixtures").glob("*") if path.is_file()] + [ROOT / "run_experiment.py"]
    for source in expected_sources:
        suffix = "/" + source.relative_to(ROOT).as_posix()
        matches = [value for path, value in bound.items() if path.replace("\\", "/").endswith(suffix)]
        if matches != [digest(source.read_bytes())]:
            raise ValueError("source changed since the selected run: " + source.relative_to(ROOT).as_posix())
    inputs = list((ROOT / "toolbridge").glob("*.py")) + list((ROOT / "tests").glob("test_*.py")) + list((ROOT / "fixtures").glob("*")) + [ROOT / "run_checks.py", ROOT / "run_experiment.py", ROOT / "SUBMISSION.md"]
    payloads = {}
    for path in sorted(inputs):
        if path.is_symlink() or not path.is_file() or path.suffix not in {".py", ".json", ".md"}:
            continue
        data = path.read_bytes()
        data.decode("utf-8")
        payloads[path.relative_to(ROOT).as_posix()] = data
    names = ["report.json", "cli.json", "http.json", "stdio.json", "trace-readback.json", "evaluation-cases.json", "independent-evaluation.json", "transfer.json", "traces/root.jsonl", "traces/left.jsonl", "traces/right.jsonl"]
    for index in range(4):
        names.extend([f"trial-{index}/host.json", f"trial-{index}/final.json"])
        for name in ("receipt.txt", "broadcast.txt"):
            path = evidence / f"trial-{index}/effects/{name}"
            if path.exists():
                names.append(f"trial-{index}/effects/{name}")
    records = []
    for name in names:
        path = evidence / name
        if any(part.is_symlink() for part in (path, *path.parents) if part == evidence or evidence in part.parents):
            raise ValueError("evidence links are not accepted")
        data = path.read_bytes()
        records.append({"path": name, "bytes": len(data), "sha256": digest(data), "text": data.decode("utf-8")})
    packed = {"format": "tool-bridge-selected-run/v1", "status": "self-produced-unverified", "current_source_matches_selected_run": True, "files": records}
    payloads["evidence/selected-run.json"] = (json.dumps(packed, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    if len(payloads) > 48 or sum(map(len, payloads.values())) > 512 * 1024 or any(len(data) > 64 * 1024 for data in payloads.values()):
        raise ValueError("submission exceeds the game text limits; keep a focused set of tests and one evidence run")
    output.mkdir(parents=True, exist_ok=False)
    for name, data in payloads.items():
        target = output / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    return {"status": "prepared-not-reviewed", "files": len(payloads), "bytes": sum(map(len, payloads.values())), "evidence_files_preserved": len(records), "output": str(output)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--evidence", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    print(json.dumps(prepare(args.evidence, args.output), ensure_ascii=False))


if __name__ == "__main__":
    main()
