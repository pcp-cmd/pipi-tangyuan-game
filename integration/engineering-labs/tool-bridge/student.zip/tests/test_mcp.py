import asyncio
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from toolbridge.errors import ProtocolError, RpcError
from toolbridge.mcp_client import Client
from test_transports import FIXTURES, line_with_deadline


class ServerContract(unittest.TestCase):
    def test_raw_incremental_handshake_notifications_and_error_layers(self):
        process = subprocess.Popen([sys.executable, "-m", "toolbridge", "serve-mcp", "--catalog", str(FIXTURES / "catalog.json")], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8")
        def send(message):
            process.stdin.write(json.dumps(message) + "\n")
            process.stdin.flush()
        def request(identifier, method, params=None):
            send({"jsonrpc": "2.0", "id": identifier, "method": method, "params": {} if params is None else params})
            return json.loads(line_with_deadline(process.stdout))
        try:
            send({"jsonrpc": "2.0", "method": "notifications/initialized"})
            premature = request(1, "tools/list")
            self.assertEqual(premature["id"], 1)
            self.assertIn("error", premature)
            self.assertEqual(premature["error"]["code"], -32000)
            init = request(2, "initialize", {"protocolVersion": "2025-11-25", "capabilities": {}, "clientInfo": {"name": "test", "version": "1"}})
            self.assertEqual(init["result"]["protocolVersion"], "2025-11-25")
            self.assertEqual(request(3, "tools/list")["error"]["code"], -32000)
            send({"jsonrpc": "2.0", "method": "notifications/initialized"})
            listed = request(4, "tools/list")
            self.assertEqual(listed["id"], 4)
            self.assertEqual(listed["result"]["tools"][0]["name"], "catalog_quote")
            malformed = request(5, "tools/call", {"name": "catalog_quote", "arguments": []})
            self.assertEqual(malformed["error"]["code"], -32602)
            invalid = request(6, "tools/call", {"name": "catalog_quote", "arguments": {"sku": "ROPE", "quantity": True}})
            self.assertIn("result", invalid)
            self.assertTrue(invalid["result"]["isError"])
            missing = request(7, "tools/call", {"name": "unknown", "arguments": {}})
            self.assertEqual(missing["error"]["code"], -32602)
            valid = request(8, "tools/call", {"name": "catalog_quote", "arguments": {"sku": "SHELL-LAMP", "quantity": 2}})
            self.assertEqual(json.loads(valid["result"]["content"][0]["text"])["total_cents"], 750)
            self.assertFalse(valid["result"]["isError"])
            self.assertEqual(request(9, "not/a/method")["error"]["code"], -32601)
            process.stdin.write("{\n")
            process.stdin.flush()
            self.assertEqual(json.loads(line_with_deadline(process.stdout))["error"]["code"], -32700)
            process.stdin.close()
            self.assertEqual(process.wait(timeout=3), 0)
            self.assertEqual(process.stdout.read(), "")
        finally:
            if process.poll() is None:
                process.kill()
                process.wait(timeout=3)
            process.stdout.close()
            process.stderr.close()


class ClientContract(unittest.IsolatedAsyncioTestCase):
    def peer(self, mode, timeout=1):
        return Client([sys.executable, str(FIXTURES / "protocol_peer.py"), mode], timeout=timeout)

    async def test_real_two_process_client_and_server(self):
        client = Client([sys.executable, "-m", "toolbridge", "serve-mcp", "--catalog", str(FIXTURES / "catalog.json")])
        async with client:
            self.assertEqual((await client.call_quote("SHELL-LAMP", 2))["total_cents"], 750)
            with self.assertRaises(RpcError):
                await client.call_quote("missing", 1)
            self.assertEqual((await client.call_quote("贝壳 灯", 1))["total_cents"], 0)
        self.assertIsNotNone(client.process.returncode)
        self.assertTrue(client.closed)

    async def test_interleaved_notification_and_stderr_are_not_responses(self):
        async with self.peer("stderr") as client:
            self.assertEqual(await client.request("tools/list"), {"tools": []})
            self.assertEqual(client.notifications, ["notifications/message"])
        self.assertGreater(client.stderr_bytes, 65536)

    async def test_wrong_ids_banner_and_eof_invalidate_and_reap(self):
        for mode in ("wrong-id", "bool-id", "banner", "eof"):
            with self.subTest(mode=mode):
                client = self.peer(mode)
                async with client:
                    with self.assertRaises(ProtocolError):
                        await client.request("tools/list")
                    self.assertTrue(client.closed)
                    self.assertIsNotNone(client.process.returncode)
                    with self.assertRaises(ProtocolError):
                        await client.request("tools/list")

    async def test_timeout_has_total_deadline_despite_notifications(self):
        client = self.peer("notification-timeout", timeout=0.08)
        async with client:
            with self.assertRaises(TimeoutError):
                await client.request("tools/list")
            self.assertTrue(client.closed)
            self.assertIsNotNone(client.process.returncode)

    async def test_boolean_one_is_not_the_first_request_id(self):
        client = self.peer("bool-initialize")
        with self.assertRaises(ProtocolError):
            await client.__aenter__()
        self.assertTrue(client.closed)
        self.assertIsNotNone(client.process.returncode)

    async def test_outstanding_request_rejected_and_cancellation_reaps(self):
        async with self.peer("delay") as client:
            pending = asyncio.create_task(client.request("tools/list"))
            while not client.pending:
                await asyncio.sleep(0)
            with self.assertRaises(ProtocolError):
                await client.request("tools/list")
            self.assertEqual(await pending, {"tools": []})
        client = self.peer("timeout")
        async with client:
            pending = asyncio.create_task(client.request("tools/list"))
            while not client.pending:
                await asyncio.sleep(0)
            pending.cancel()
            with self.assertRaises(asyncio.CancelledError):
                await pending
            self.assertTrue(client.closed)
            self.assertIsNotNone(client.process.returncode)

    async def test_client_instance_cannot_replace_a_live_or_closed_process(self):
        client = self.peer("delay")
        async with client:
            original = client.process
            with self.assertRaises(ProtocolError):
                await client.__aenter__()
            self.assertIs(client.process, original)
            self.assertIsNone(original.returncode)
        with self.assertRaises(ProtocolError):
            await client.__aenter__()
        self.assertIs(client.process, original)
        self.assertIsNotNone(original.returncode)


if __name__ == "__main__":
    unittest.main()
