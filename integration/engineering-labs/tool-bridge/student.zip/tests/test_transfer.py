import copy
import hashlib
import json
import subprocess
import sys
from pathlib import Path
import unittest

from toolbridge.domain import slot_availability
from toolbridge.errors import DomainError


class TransferContract(unittest.TestCase):
    def test_transfer_half_open_interval_and_station(self):
        rows = [{"id": "a", "station": "north", "start": 10, "end": 20}, {"id": "b", "station": "south", "start": 15, "end": 30}, {"id": "c", "station": "north", "start": 25, "end": 40}]
        original = copy.deepcopy(rows)
        self.assertTrue(slot_availability(rows, {"station": "north", "start": 20, "end": 25})["available"])
        self.assertEqual(slot_availability(rows, {"station": "north", "start": 19, "end": 26})["conflict_ids"], ["a", "c"])
        self.assertEqual(rows, original)
        for start, end in ((True, 30), (30, 30), (30, 20), (-1, 20), (0, 1441)):
            with self.subTest(start=start, end=end), self.assertRaises(DomainError):
                slot_availability(rows, {"station": "north", "start": start, "end": end})


    def test_transfer_invalid_unmatched_row_is_still_invalid(self):
        rows = [{"id": "a", "station": "south", "start": 50, "end": 40}]
        with self.assertRaises(DomainError):
            slot_availability(rows, {"station": "north", "start": 10, "end": 20})



    def test_transfer_real_cli(self):
        path = Path(__file__).resolve().parents[1] / "fixtures" / "schedule.json"
        before = hashlib.sha256(path.read_bytes()).hexdigest()
        result = subprocess.run([sys.executable, "-m", "toolbridge", "check-slot", "--schedule", str(path)], input='{"station":"north","start":540,"end":570}', text=True, encoding="utf-8", capture_output=True, timeout=5)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)["result"]["conflict_ids"], [])
        self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), before)


if __name__ == "__main__":
    unittest.main()
