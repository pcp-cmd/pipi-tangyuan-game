import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from toolbridge.evaluation import aggregate, dataset_sha256, grade_trial
from test_transports import FIXTURES


CASES = json.loads((FIXTURES / "evaluation_cases.json").read_text(encoding="utf-8"))


class EvaluationContract(unittest.TestCase):
    def produce_and_grade(self, name, index, folder):
        args = [sys.executable, str(FIXTURES / "evaluation_worker.py")]
        production = subprocess.run([*args, "produce:" + name, str(FIXTURES / "evaluation_cases.json"), str(index), str(folder)], capture_output=True, text=True, timeout=5)
        self.assertEqual(production.returncode, 0, production.stderr)
        graded = subprocess.run([*args, "grade", str(FIXTURES / "evaluation_cases.json"), str(index), str(folder)], capture_output=True, text=True, timeout=5)
        self.assertEqual(graded.returncode, 0, graded.stderr)
        worker, result = json.loads(production.stdout), json.loads(graded.stdout)
        self.assertEqual(len({worker["producer_pid"], result["grader_pid"], os.getpid()}), 3)
        return result["grade"]

    def test_actual_effects_and_separate_grader_accept_valid_alternatives(self):
        with tempfile.TemporaryDirectory() as directory:
            for name in ("valid", "alternative"):
                for index in range(2):
                    with self.subTest(name=name, index=index):
                        result = self.produce_and_grade(name, index, Path(directory) / f"{name}-{index}")
                        self.assertTrue(result["functional_pass"])
                        self.assertFalse(result["dangerous"])
                        self.assertEqual(result["call_count"], (1 if name == "valid" else 2) + index)
                        self.assertGreaterEqual(result["elapsed_ms"], 0)

    def test_self_scores_claimed_receipts_and_numeric_booleans_fail(self):
        with tempfile.TemporaryDirectory() as directory:
            for name, index in (("self_score", 0), ("claimed_receipt", 1), ("integer_bool", 0)):
                with self.subTest(name=name):
                    result = self.produce_and_grade(name, index, Path(directory) / name)
                    self.assertFalse(result["functional_pass"])

    def test_extra_duplicate_and_exception_after_effect_are_not_erased(self):
        with tempfile.TemporaryDirectory() as directory:
            for name, index in (("broadcast", 0), ("duplicate_receipt", 1), ("error_after_effect", 0)):
                with self.subTest(name=name):
                    folder = Path(directory) / name
                    result = self.produce_and_grade(name, index, folder)
                    self.assertFalse(result["functional_pass"])
                    self.assertTrue(result["dangerous"])
                    self.assertTrue(list((folder / "effects").iterdir()))
            folder = Path(directory) / "broadcast"
            (folder / "host.json").unlink()
            result = grade_trial(CASES[0], folder)
            self.assertTrue(result["unknown"])
            self.assertTrue(result["dangerous"])

    def test_all_scheduled_trials_and_danger_veto(self):
        good = {"case_id": "a", "functional_pass": True, "dangerous": False, "environment_error": False, "unknown": False}
        danger = {**good, "case_id": "b", "dangerous": True}
        result = aggregate([good, danger], ["a", "b", "missing"])
        self.assertEqual(result["scheduled"], 3)
        self.assertEqual(result["functional_passes"], 1)
        self.assertAlmostEqual(result["pass_rate"], 1 / 3)
        self.assertEqual(result["dangerous_trials"], 1)
        self.assertEqual(result["environment_errors"], 1)
        self.assertFalse(result["ready"])
        for rows, ids in (([], []), ([good, good], ["a"]), ([good], ["a", "a"]), ([good], ["b"])):
            with self.subTest(rows=rows, ids=ids), self.assertRaises(ValueError):
                aggregate(rows, ids)

    def test_dataset_identity_is_order_independent_for_object_keys_only(self):
        self.assertEqual(dataset_sha256([{"a": 1, "b": 2}]), dataset_sha256([{"b": 2, "a": 1}]))
        self.assertNotEqual(dataset_sha256([{"a": 1}, {"a": 2}]), dataset_sha256([{"a": 2}, {"a": 1}]))

    def test_known_danger_is_retained_with_other_unreadable_evidence(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory) / "run"
            self.produce_and_grade("broadcast", 0, folder)
            (folder / "effects" / "invalid-entry").mkdir()
            result = grade_trial(CASES[0], folder)
            self.assertTrue(result["dangerous"])
            self.assertTrue(result["unknown"])
            self.assertTrue(result["environment_error"])
            self.assertFalse(result["functional_pass"])
            self.assertTrue((folder / "effects" / "broadcast.txt").is_file())


if __name__ == "__main__":
    unittest.main()
