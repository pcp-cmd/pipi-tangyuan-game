import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

from run_experiment import http_quote
from test_transports import FIXTURES


@unittest.skipUnless(os.name == "posix", "SIGTERM-ignore fixture is a POSIX experiment, not Windows proof")
class HttpCleanupContract(unittest.TestCase):
    def test_actual_http_server_ignoring_terminate_is_killed_and_reaped(self):
        with tempfile.TemporaryDirectory() as directory:
            pid = Path(directory) / "server.json"
            value = http_quote([sys.executable, str(FIXTURES / "cleanup_server.py"), "valid", str(pid)], {"sku": "x", "quantity": 1})
            self.assertEqual(value["result"]["total_cents"], 9)
            self.assertTrue(value["forced_kill"])
            self.assertEqual(value["process_returncode"], -9)
            with self.assertRaises(ProcessLookupError):
                os.kill(value["server_pid"], 0)

    def test_actual_bad_ready_error_survives_stubborn_server_cleanup(self):
        with tempfile.TemporaryDirectory() as directory:
            pid = Path(directory) / "server.json"
            with self.assertRaises(json.JSONDecodeError) as caught:
                http_quote([sys.executable, str(FIXTURES / "cleanup_server.py"), "invalid", str(pid)], {"sku": "x", "quantity": 1})
            server = json.loads(pid.read_text(encoding="utf-8"))
            self.assertEqual(caught.exception.http_process_pid, server["pid"])
            self.assertEqual(caught.exception.http_process_returncode, -9)
            with self.assertRaises(ProcessLookupError):
                os.kill(server["pid"], 0)


if __name__ == "__main__":
    unittest.main()
