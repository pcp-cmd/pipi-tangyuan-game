import copy
import unittest

from toolbridge.domain import quote, validate_quote
from toolbridge.errors import BusinessContractError, DomainError


class DomainContract(unittest.TestCase):
    def setUp(self):
        self.catalog = {"lamp": {"available": 3, "price_cents": 125}, "free": {"available": 0, "price_cents": 0}}

    def test_quote_and_no_mutation(self):
        original = copy.deepcopy(self.catalog)
        request = {"sku": "lamp", "quantity": 2}
        self.assertEqual(quote(self.catalog, request), {"sku": "lamp", "quantity": 2, "available": 3, "total_cents": 250, "can_fulfill": True})
        self.assertEqual(quote(self.catalog, {"sku": "free", "quantity": 1})["can_fulfill"], False)
        self.assertEqual(self.catalog, original)
        self.assertEqual(request, {"sku": "lamp", "quantity": 2})

    def test_boolean_numbers_and_extra_fields_are_invalid(self):
        for quantity in (True, False, "2", 2.0, 0, -1, 1000):
            with self.subTest(quantity=quantity), self.assertRaises(DomainError):
                quote(self.catalog, {"sku": "lamp", "quantity": quantity})
        for request in ({"sku": "lamp"}, {"sku": "lamp", "quantity": 1, "approved": True}, [], None):
            with self.subTest(request=request), self.assertRaises(DomainError):
                quote(self.catalog, request)
        with self.assertRaises(DomainError):
            quote({"lamp": {"available": True, "price_cents": 1}}, {"sku": "lamp", "quantity": 1})

    def test_unknown_sku_is_explicit(self):
        with self.assertRaises(DomainError) as caught:
            quote(self.catalog, {"sku": "missing", "quantity": 1})
        self.assertEqual(caught.exception.code, "unknown_sku")

    def test_response_validator_does_not_accept_truthy_integer(self):
        good = quote(self.catalog, {"sku": "lamp", "quantity": 1})
        self.assertEqual(validate_quote(good), good)
        for key, bad in (("can_fulfill", 1), ("quantity", True), ("total_cents", "125"), ("available", -1)):
            with self.subTest(key=key), self.assertRaises(BusinessContractError):
                validate_quote({**good, key: bad})




if __name__ == "__main__":
    unittest.main()
