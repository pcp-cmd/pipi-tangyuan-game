import hashlib
import json
import os
import queue
import subprocess
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from toolbridge.errors import BusinessContractError, HttpStatusError, ResponseFormatError, TransportError
from toolbridge.http_adapter import fetch_quote


FIXTURES = Path(__file__).resolve().parents[1] / "fixtures"


def line_with_deadline(stream, seconds=3):
    result = queue.Queue()
    threading.Thread(target=lambda: result.put(stream.readline()), daemon=True).start()
    return result.get(timeout=seconds)


class TransportContract(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="island bridge 空间 ")
        self.folder = Path(self.temp.name)
        self.catalog = self.folder / "目录 with spaces.json"
        self.catalog.write_bytes((FIXTURES / "catalog.json").read_bytes())
        self.before = hashlib.sha256(self.catalog.read_bytes()).hexdigest()

    def tearDown(self):
        self.assertEqual(hashlib.sha256(self.catalog.read_bytes()).hexdigest(), self.before)
        self.temp.cleanup()

    def command(self, *args, raw='{"sku":"SHELL-LAMP","quantity":2}'):
        return subprocess.run([sys.executable, "-m", "toolbridge", *args], input=raw, text=True, encoding="utf-8", capture_output=True, cwd=self.folder, timeout=5)

    def test_cli_real_process_unicode_path_and_one_line(self):
        result = self.command("quote", "--catalog", str(self.catalog))
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(len(result.stdout.splitlines()), 1)
        self.assertEqual(json.loads(result.stdout)["result"]["total_cents"], 750)
        self.assertEqual(result.stderr, "")
        alternate = self.command("quote", "--catalog", str(self.catalog), raw='{"sku":"贝壳 灯","quantity":2}')
        self.assertEqual(json.loads(alternate.stdout)["result"]["total_cents"], 0)

    def test_cli_errors_help_import_and_argument_boundaries(self):
        for raw, code, error in (("{", 2, "invalid_json"), ('{"sku":"missing","quantity":1}', 4, "unknown_sku"), ('{"sku":"SHELL-LAMP","quantity":true}', 2, "invalid_request")):
            with self.subTest(raw=raw):
                result = self.command("quote", "--catalog", str(self.catalog), raw=raw)
                self.assertEqual(result.returncode, code)
                self.assertEqual(json.loads(result.stdout), {"ok": False, "error": {"code": error}})
                self.assertTrue(result.stderr.strip())
        missing = self.command("quote", "--catalog", str(self.folder / "missing"))
        self.assertEqual(missing.returncode, 5)
        self.assertEqual(self.command("quote", "--cat", str(self.catalog)).returncode, 2)
        self.assertEqual(self.command("--help").returncode, 0)
        imported = subprocess.run([sys.executable, "-c", "import toolbridge.cli, toolbridge.http_adapter, toolbridge.mcp_server"], capture_output=True, text=True, cwd=self.folder, timeout=3)
        self.assertEqual((imported.returncode, imported.stdout, imported.stderr), (0, "", ""))


    def test_actual_http_server_and_business_errors(self):
        process = subprocess.Popen([sys.executable, "-m", "toolbridge", "serve-http", "--catalog", str(self.catalog)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8", cwd=self.folder)
        try:
            ready = json.loads(line_with_deadline(process.stdout))
            self.assertEqual(ready["host"], "127.0.0.1")
            url = f'http://127.0.0.1:{ready["port"]}/quote'
            result = fetch_quote(url, {"sku": "SHELL-LAMP", "quantity": 2})
            self.assertEqual(result["total_cents"], 750)
            with self.assertRaises(HttpStatusError) as caught:
                fetch_quote(url, {"sku": "SHELL-LAMP", "quantity": True})
            self.assertEqual(caught.exception.status, 422)
            with self.assertRaises(HTTPError) as malformed:
                urlopen(Request(url, data=b"{", headers={"Content-Type": "application/json"}), timeout=2)
            self.assertEqual(malformed.exception.code, 400)
            malformed.exception.close()
            with self.assertRaises(HttpStatusError) as unknown:
                fetch_quote(url, {"sku": "missing", "quantity": 1})
            self.assertEqual(unknown.exception.status, 404)
        finally:
            process.terminate()
            process.communicate(timeout=3)
        self.assertIsNotNone(process.returncode)

    def test_client_distinguishes_status_json_and_business(self):
        class Fixture(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass
            def do_POST(self):
                self.rfile.read(int(self.headers.get("Content-Length", 0)))
                status, body = {
                    "/busy": (503, b'{"error":"busy"}'),
                    "/broken": (200, b'{'),
                    "/wrong": (200, b'{"ok":true,"result":{"sku":"x","quantity":1,"available":1,"total_cents":"3","can_fulfill":true}}'),
                    "/redirect": (302, b'{}'),
                    "/created": (201, b'{"ok":true,"result":{"sku":"x","quantity":1,"available":1,"total_cents":3,"can_fulfill":true}}'),
                }[self.path]
                self.send_response(status)
                if self.path == "/redirect":
                    self.send_header("Location", "http://example.invalid/never-follow")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
        server = ThreadingHTTPServer(("127.0.0.1", 0), Fixture)
        thread = threading.Thread(target=server.serve_forever)
        thread.start()
        try:
            for path, error in (("busy", HttpStatusError), ("broken", ResponseFormatError), ("wrong", BusinessContractError), ("redirect", HttpStatusError), ("created", HttpStatusError)):
                with self.subTest(path=path), self.assertRaises(error):
                    fetch_quote(f"http://127.0.0.1:{server.server_port}/{path}", {"sku": "x", "quantity": 1})
        finally:
            server.shutdown()
            server.server_close()
            thread.join()
        with self.assertRaises(TransportError):
            fetch_quote(f"http://127.0.0.1:{server.server_port}/quote", {"sku": "x", "quantity": 1}, timeout=0.2)
        with self.assertRaises(TransportError):
            fetch_quote("https://example.invalid/quote", {"sku": "x", "quantity": 1})


if __name__ == "__main__":
    unittest.main()
