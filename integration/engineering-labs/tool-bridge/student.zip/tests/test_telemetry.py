import asyncio
import copy
import json
import os
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path

from toolbridge.telemetry import observe, read_events, summarize, write_event
from test_transports import FIXTURES


def event(span, *, event="span_started", parent=None, run="one", at=10, pid=1, status="ok", attempt=1):
    row = {"event": event, "run_id": run, "span_id": span, "parent": parent, "operation_id": "read", "time_ms": at, "pid": pid}
    row.update({"kind": "tool", "attempt": attempt} if event == "span_started" else {"status": status})
    return row


class TraceContract(unittest.TestCase):
    def test_append_whitelist_and_cross_process_readback(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "trace.jsonl"
            row = {**event("one"), "secret": "do-not-log", "body": "private\ntext", "error_message": "secret-detail"}
            original = copy.deepcopy(row)
            write_event(path, row)
            prefix = path.read_bytes()
            write_event(path, event("two", at=20))
            self.assertTrue(path.read_bytes().startswith(prefix))
            self.assertEqual(row, original)
            self.assertNotIn("secret", path.read_text())
            self.assertNotIn("private", path.read_text())
            result = subprocess.run([sys.executable, str(FIXTURES / "read_trace.py"), str(path)], capture_output=True, text=True, timeout=3)
            self.assertEqual(result.returncode, 0, result.stderr)
            readback = json.loads(result.stdout)
            self.assertNotEqual(readback["reader_pid"], os.getpid())
            self.assertEqual([span["status"] for span in readback["summary"]["spans"]], ["incomplete", "incomplete"])

    def test_identity_not_fifo_or_span_name_alone(self):
        rows = [event("left", at=1), event("right", at=2), event("right", event="span_finished", at=4), event("left", event="span_finished", at=9), event("left", run="two", at=3)]
        values = summarize(list(reversed(rows)))["spans"]
        by_id = {(span["run_id"], span["span_id"]): span for span in values}
        self.assertEqual(by_id[("one", "left")]["elapsed_ms"], 8)
        self.assertEqual(by_id[("one", "right")]["elapsed_ms"], 2)
        self.assertEqual(by_id[("two", "left")]["status"], "incomplete")
        self.assertIsNone(by_id[("two", "left")]["elapsed_ms"])

    def test_missing_parent_cycles_duplicates_and_bad_identity(self):
        self.assertEqual(summarize([event("child", parent="lost")])["issues"][0]["code"], "missing_parent")
        cases = [
            [event("a"), event("a")],
            [event("a", event="span_finished")],
            [event("a", parent="b"), event("b", parent="a")],
            [event("a", at=4), event("a", event="span_finished", at=3)],
            [event("a", pid=1), event("a", event="span_finished", pid=2)],
            [event("a"), event("a", event="span_finished", parent="changed")],
            [{**event("a"), "time_ms": True}],
        ]
        for rows in cases:
            with self.subTest(rows=rows), self.assertRaises(ValueError):
                summarize(rows)
        bad_parent = event("a")
        del bad_parent["parent"]
        with self.assertRaises(ValueError):
            summarize([bad_parent])

    def test_incomplete_tail_preserved_and_complete_corruption_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "trace.jsonl"
            write_event(path, event("a"))
            with path.open("ab") as stream:
                stream.write(b'{"unfinished":')
            before = path.read_bytes()
            result = read_events(path)
            self.assertTrue(result["partial_tail"])
            self.assertEqual(len(result["rows"]), 1)
            self.assertEqual(path.read_bytes(), before)
            with self.assertRaises(ValueError):
                write_event(path, event("later", at=30))
            self.assertEqual(path.read_bytes(), before)
            with path.open("ab") as stream:
                stream.write(b"\n")
            with self.assertRaises(ValueError):
                read_events(path)

    def test_actual_overlapping_processes_retry_and_independent_reader(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            (folder / "notice.txt").write_text("left observation", encoding="utf-8")
            root = folder / "root.jsonl"
            write_event(root, {**event("root", run="cross-process", at=time.perf_counter() * 1000), "kind": "run"})
            children = [subprocess.Popen([sys.executable, str(FIXTURES / "trace_worker.py"), name, directory], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True) for name in ("left", "right")]
            results = []
            try:
                for child in children:
                    stdout, stderr = child.communicate(timeout=8)
                    self.assertEqual(child.returncode, 0, stderr)
                    results.append(json.loads(stdout))
            finally:
                for child in children:
                    if child.poll() is None:
                        child.kill()
                        child.wait(timeout=3)
            self.assertEqual(len({row["pid"] for row in results}), 2)
            self.assertTrue(all(row["pid"] != os.getpid() for row in results))
            write_event(root, event("root", run="cross-process", event="span_finished", at=time.perf_counter() * 1000))
            reader = subprocess.run([sys.executable, str(FIXTURES / "read_trace.py"), str(folder / "right.jsonl"), str(root), str(folder / "left.jsonl")], text=True, capture_output=True, timeout=3)
            self.assertEqual(reader.returncode, 0, reader.stderr)
            summary = json.loads(reader.stdout)["summary"]
            by_id = {row["span_id"]: row for row in summary["spans"]}
            self.assertEqual(by_id["right.try-1"]["status"], "error")
            self.assertEqual(by_id["right.try-2"]["status"], "ok")
            self.assertEqual(by_id["right.try-2"]["attempt"], 2)
            self.assertEqual(by_id["left.read"]["parent"], "root")
            self.assertEqual(summary["issues"], [])


class ObserveContract(unittest.IsolatedAsyncioTestCase):
    async def test_real_success_exception_and_cancel_propagate(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "trace.jsonl"
            async def success():
                return 7
            result = await observe(path, run_id="r", span_id="success", parent=None, operation_id="read", kind="tool", operation=success)
            self.assertEqual(result, 7)
            original = FileNotFoundError("private error detail")
            async def failed():
                raise original
            with self.assertRaises(FileNotFoundError) as caught:
                await observe(path, run_id="r", span_id="failure", parent=None, operation_id="read", kind="tool", operation=failed)
            self.assertIs(caught.exception, original)
            entered = asyncio.Event()
            async def waiting():
                entered.set()
                await asyncio.Event().wait()
            task = asyncio.create_task(observe(path, run_id="r", span_id="cancel", parent=None, operation_id="read", kind="tool", operation=waiting))
            await entered.wait()
            task.cancel()
            with self.assertRaises(asyncio.CancelledError):
                await task
            summary = summarize(read_events(path)["rows"])
            self.assertEqual({row["span_id"]: row["status"] for row in summary["spans"]}, {"success": "ok", "failure": "error", "cancel": "cancelled"})
            self.assertNotIn("private", path.read_text())

    async def test_start_log_failure_prevents_action_end_failure_does_not_undo(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            calls = []
            async def action():
                calls.append("called")
            with self.assertRaises(OSError):
                await observe(folder, run_id="r", span_id="a", parent=None, operation_id="write", kind="tool", operation=action)
            self.assertEqual(calls, [])
            path = folder / "trace.jsonl"
            async def side_effect():
                (folder / "actual-effect.txt").write_text("done", encoding="utf-8")
                path.unlink()
                path.mkdir()
            with self.assertRaises(OSError):
                await observe(path, run_id="r", span_id="b", parent=None, operation_id="write", kind="tool", operation=side_effect)
            self.assertEqual((folder / "actual-effect.txt").read_text(), "done")

    async def test_clock_math_only_does_not_claim_real_timing(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "trace.jsonl"
            ticks = iter([1.0, 1.25])
            async def operation():
                return "ok"
            await observe(path, run_id="r", span_id="timing", parent=None, operation_id="read", kind="tool", operation=operation, clock=lambda: next(ticks))
            self.assertEqual(summarize(read_events(path)["rows"])["spans"][0]["elapsed_ms"], 250)

    async def test_original_error_and_cancellation_survive_end_log_failure(self):
        for original in (OSError("original operation"), asyncio.CancelledError("original cancellation")):
            with self.subTest(kind=type(original).__name__), tempfile.TemporaryDirectory() as directory:
                path = Path(directory) / "trace.jsonl"
                async def operation():
                    path.unlink()
                    path.mkdir()
                    raise original
                try:
                    await observe(path, run_id="r", span_id="double-failure", parent=None, operation_id="read", kind="tool", operation=operation)
                except BaseException as caught:
                    self.assertIs(caught, original)
                    self.assertIsInstance(caught.trace_log_error, OSError)
                    self.assertTrue(any(note.startswith("trace finish failed:") for note in caught.__notes__))
                else:
                    self.fail("the original failure must propagate")


if __name__ == "__main__":
    unittest.main()
