def allocate(capacities, events):
    """Validate all input, then allocate and cancel reservations in event order."""
    raise NotImplementedError("独立完成新业务，不复用整批扣库存规则")


def write_report(capacity_path, event_path, report_path):
    """Read two JSON files and replace the report only after complete validation."""
    raise NotImplementedError("实现真实文件交付与失败保留旧报告")
