def read_note(root, relative, grant):
    """Check exact read approval and a contained relative path before reading."""
    raise NotImplementedError("实现明确授权与路径边界；本函数不是操作系统沙箱")
