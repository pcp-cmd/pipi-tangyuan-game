import hashlib
import json
from pathlib import Path
from . import architecture
from .port import ToolPort

MODES = {"fixed": architecture.run_fixed, "loop": architecture.run_loop, "roles": architecture.run_roles}
BOUND_SOURCES = ("fieldwork/architecture.py", "fieldwork/port.py", "fieldwork/experiment.py", "fixtures/scenarios.json")


def compare(root):
    root = Path(root)
    scenarios = json.loads((root / "fixtures/scenarios.json").read_text(encoding="utf-8"))
    rows = []
    for scenario in scenarios:
        for mode, solve in MODES.items():
            port = ToolPort(scenario, scenario["budget"])
            result = None
            error = None
            try:
                result = solve({"parcel": scenario["parcel"]}, port)
            except Exception as exc:
                error = type(exc).__name__
            rows.append({"scenario": scenario["id"], "mode": mode, "result": result, "error": error,
                         "tool_calls": sum(event["kind"] == "query" for event in port.events),
                         "decisions": sum(event["kind"] == "decision" for event in port.events),
                         "handoffs": sum(event["kind"] == "handoff" for event in port.events),
                         "events": port.events})
    return {"schema": "pipi-control-architecture-comparison/v1", "model": "deterministic-python-no-llm",
            "source_sha256": {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in BOUND_SOURCES},
            "rows": rows}


def write_comparison(root, target):
    report = compare(root)
    Path(target).write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return report
