def run_fixed(request, port):
    """Use a fixed primary-then-backup workflow."""
    raise NotImplementedError("先实现固定工作流")


def next_action(request, observations):
    """Return a query action or a final answer from actual observations."""
    raise NotImplementedError("根据已收到的观察决定下一步")


def run_loop(request, port):
    """Run next_action in a bounded decision loop."""
    raise NotImplementedError("实现有界决策循环")


def collect_for_role(request, port):
    """The lookup role returns observations, not a final answer."""
    raise NotImplementedError("查询角色只交付实际观察")


def decide_for_role(request, observations):
    """The answer role derives an answer without invoking tools."""
    raise NotImplementedError("回答角色不再调用查询工具")


def run_roles(request, port):
    """Coordinate separate lookup and answer roles with explicit handoffs."""
    raise NotImplementedError("协调两个确定性 Python 角色")
