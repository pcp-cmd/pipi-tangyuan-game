import copy


class BudgetExceeded(RuntimeError):
    pass


class ToolPort:
    def __init__(self, scenario, budget):
        if type(budget) is not int or budget < 0 or budget > 8:
            raise ValueError("budget must be an integer from 0 to 8")
        self._scenario = copy.deepcopy(scenario)
        self.remaining = budget
        self.events = []

    def note(self, kind):
        if kind not in {"decision", "handoff"}:
            raise ValueError("unknown coordination event")
        self.events.append({"kind": kind})

    def query(self, source, parcel):
        if source not in {"primary", "backup"} or not isinstance(parcel, str) or not parcel:
            raise ValueError("invalid tool request")
        if self.remaining == 0:
            raise BudgetExceeded("No tool calls remain")
        self.remaining -= 1
        result = self._scenario[source]
        event = {"kind": "query", "source": source, "parcel": parcel, "outcome": result}
        self.events.append(event)
        if result == "timeout":
            raise TimeoutError("The synthetic provider did not respond")
        if result == "denied":
            raise PermissionError("The synthetic provider refused access")
        return {"parcel": parcel, "status": result}
