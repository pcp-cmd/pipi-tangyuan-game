def inspect_launch(marker):
    """Read marker from the actual working directory and describe this process."""
    raise NotImplementedError("实现 F00 的路径与解释器观察")


def python_sources(folder):
    """Return sorted immediate regular .py filenames, excluding .py.txt files."""
    raise NotImplementedError("核对文件的真实扩展名")
