import json
from pathlib import Path
import unittest
from unittest.mock import patch
from fieldwork import architecture
from fieldwork.experiment import MODES, compare
from fieldwork.port import ToolPort

ROOT = Path(__file__).resolve().parents[1]


class ArchitectureTests(unittest.TestCase):
    def test_same_task_and_failure_contract_for_each_architecture(self):
        cases = [
            ("ready", "transit", 2, {"parcel":"parcel-9","status":"ready","source":"primary"}, 1),
            ("unknown", "transit", 2, {"parcel":"parcel-9","status":"transit","source":"backup"}, 2),
            ("unknown", "unknown", 2, {"parcel":"parcel-9","status":"unknown","source":None}, 2),
            ("timeout", "ready", 2, {"parcel":"parcel-9","status":"ready","source":"backup"}, 2),
            ("unknown", "ready", 1, {"parcel":"parcel-9","status":"unknown","source":None}, 1),
            ("ready", "ready", 0, {"parcel":"parcel-9","status":"unknown","source":None}, 0),
        ]
        for mode, solve in MODES.items():
            for primary, backup, budget, expected, calls in cases:
                with self.subTest(mode=mode, primary=primary, backup=backup, budget=budget):
                    port = ToolPort({"primary":primary,"backup":backup}, budget)
                    self.assertEqual(solve({"parcel":"parcel-9"}, port), expected)
                    queries = [event for event in port.events if event["kind"] == "query"]
                    self.assertEqual(len(queries), calls)
                    self.assertEqual(len({event["source"] for event in queries}), calls)
                    if mode == "loop":
                        self.assertGreaterEqual(sum(event["kind"] == "decision" for event in port.events), 1)
                    if mode == "roles":
                        self.assertEqual(sum(event["kind"] == "handoff" for event in port.events), 2)

    def test_denied_access_does_not_trigger_a_backup_attempt(self):
        for mode, solve in MODES.items():
            with self.subTest(mode=mode):
                port = ToolPort({"primary":"denied","backup":"ready"}, 2)
                with self.assertRaises(PermissionError):
                    solve({"parcel":"private"}, port)
                self.assertEqual([event["source"] for event in port.events if event["kind"] == "query"], ["primary"])

    def test_invalid_requests_have_no_tool_effect(self):
        for mode, solve in MODES.items():
            for request in [{}, {"parcel":""}, {"parcel":True}]:
                with self.subTest(mode=mode, request=request):
                    port = ToolPort({"primary":"ready","backup":"ready"}, 2)
                    with self.assertRaises(ValueError):
                        solve(request, port)
                    self.assertFalse(any(event["kind"] == "query" for event in port.events))

    def test_decision_loop_and_roles_exchange_observations(self):
        request = {"parcel":"next"}
        first = architecture.next_action(request, [])
        self.assertEqual(first, {"kind":"query","source":"primary","parcel":"next"})
        observations = [{"source":"primary","result":{"parcel":"next","status":"unknown"},"error":None}]
        self.assertEqual(architecture.next_action(request, observations), {"kind":"query","source":"backup","parcel":"next"})
        observations.append({"source":"backup","result":{"parcel":"next","status":"ready"},"error":None})
        expected = {"parcel":"next","status":"ready","source":"backup"}
        self.assertEqual(architecture.next_action(request, observations), {"kind":"answer","value":expected})
        self.assertEqual(architecture.decide_for_role(request, observations), expected)
        port = ToolPort({"primary":"unknown","backup":"ready"}, 2)
        self.assertEqual(architecture.collect_for_role(request, port), observations)

    def test_loop_uses_returned_actions_and_actual_observations(self):
        request = {"parcel":"controlled-loop"}
        port = ToolPort({"primary":"ready","backup":"transit"}, 2)
        received = []
        chosen = {"parcel":"controlled-loop","status":"unknown","source":None}

        def decision(actual_request, observations):
            self.assertEqual(actual_request, request)
            received.append(list(observations))
            if len(received) == 1:
                self.assertEqual(observations, [])
                return {"kind":"query","source":"backup","parcel":request["parcel"]}
            self.assertEqual(observations, [{"source":"backup","result":{"parcel":"controlled-loop","status":"transit"},"error":None}])
            return {"kind":"answer","value":chosen}

        with patch.object(architecture, "next_action", side_effect=decision):
            result = architecture.run_loop(request, port)
        self.assertEqual(result, chosen)
        self.assertEqual(len(received), 2)
        self.assertEqual([event["source"] for event in port.events if event["kind"] == "query"], ["backup"])
        self.assertEqual(sum(event["kind"] == "decision" for event in port.events), 2)

    def test_roles_use_collected_observations_and_returned_answer(self):
        request = {"parcel":"controlled-roles"}
        port = ToolPort({"primary":"ready","backup":"transit"}, 2)
        calls = []
        observed = []
        chosen = {"parcel":"controlled-roles","status":"unknown","source":None}

        def collect(actual_request, actual_port):
            self.assertEqual(actual_request, request)
            self.assertEqual(sum(event["kind"] == "handoff" for event in port.events), 1)
            calls.append("collect")
            observed.append({"source":"backup","result":actual_port.query("backup", request["parcel"]),"error":None})
            return observed

        def decide(actual_request, observations):
            self.assertEqual(actual_request, request)
            self.assertEqual(observations, observed)
            self.assertEqual(sum(event["kind"] == "handoff" for event in port.events), 2)
            calls.append("decide")
            return chosen

        with patch.object(architecture, "collect_for_role", side_effect=collect), patch.object(architecture, "decide_for_role", side_effect=decide):
            result = architecture.run_roles(request, port)
        self.assertEqual(result, chosen)
        self.assertEqual(calls, ["collect", "decide"])
        self.assertEqual([event["source"] for event in port.events if event["kind"] == "query"], ["backup"])

    def test_saved_comparison_uses_current_code_and_real_results(self):
        report_path = ROOT / "ARCHITECTURES.json"
        self.assertTrue(report_path.exists(), "先运行 python run.py compare，保留实际比较结果")
        saved = json.loads(report_path.read_text(encoding="utf-8"))
        self.assertEqual(saved, compare(ROOT), "源码、固定情景或真实结果变化后必须重新运行 compare")
