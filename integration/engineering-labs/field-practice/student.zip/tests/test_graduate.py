import copy
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import unittest
from fieldwork.graduate import allocate, write_report

ROOT = Path(__file__).resolve().parents[1]
WRITE_FAULT_PROCESS = r'''
import errno
import json
import os
from pathlib import Path
import signal
import sys
from fieldwork.graduate import write_report

root, mode = Path(sys.argv[1]), sys.argv[2]
capacities, events, target = root / "capacity.json", root / "events.json", root / "report.json"
capacities.write_text('{"morning":3}', encoding="utf-8")
events.write_text('[{"action":"reserve","id":"one","slot":"morning","qty":2}]', encoding="utf-8")
target.write_bytes(b"old report remains complete\n")
before = {path.name:path.read_bytes() for path in root.iterdir()}
attempts = []
if mode == "write":
    import resource
    signal.signal(signal.SIGXFSZ, signal.SIG_IGN)
    resource.setrlimit(resource.RLIMIT_FSIZE, (64, 64))
else:
    def deny_commit(event, args):
        if event == "os.rename" and Path(os.fsdecode(args[1])).name == target.name:
            attempts.append(event)
            raise PermissionError(errno.EACCES, "Controlled atomic replacement failure")
    sys.addaudithook(deny_commit)
failure = None
try:
    write_report(capacities, events, target)
except Exception as error:
    failure = error
assert failure is not None, "An I/O failure must remain visible to the caller"
if mode == "write":
    cause, visited = failure, set()
    while cause is not None and id(cause) not in visited:
        if isinstance(cause, OSError) and cause.errno == errno.EFBIG:
            break
        visited.add(id(cause))
        cause = cause.__cause__ or cause.__context__
    assert isinstance(cause, OSError) and cause.errno == errno.EFBIG, "The failure did not come from the actual process file-size limit"
else:
    assert attempts, "The report was never committed through an atomic rename/replace"
assert target.read_bytes() == before[target.name], "A failed write replaced or truncated the previous report"
after = {path.name:path.read_bytes() if path.is_file() else None for path in root.iterdir()}
assert after == before, "A failed operation changed an input or left temporary files"
print(json.dumps({"fault":mode,"error":type(failure).__name__,"previous_report_preserved":True,"temporary_files_remaining":0}))
'''


class GraduateTests(unittest.TestCase):
    def test_partial_acceptance_cancel_and_later_reuse(self):
        capacities = {"A":3,"B":0}
        events = [{"action":"reserve","id":"one","slot":"A","qty":2},
                  {"action":"reserve","id":"large","slot":"A","qty":2},
                  {"action":"reserve","id":"small","slot":"A","qty":1},
                  {"action":"cancel","id":"one"},
                  {"action":"reserve","id":"later","slot":"A","qty":2},
                  {"action":"cancel","id":"large"}]
        original = copy.deepcopy((capacities, events))
        self.assertEqual(allocate(capacities, events), {
            "decisions":[{"id":"one","action":"reserve","result":"accepted"},
                         {"id":"large","action":"reserve","result":"shortage"},
                         {"id":"small","action":"reserve","result":"accepted"},
                         {"id":"one","action":"cancel","result":"cancelled"},
                         {"id":"later","action":"reserve","result":"accepted"},
                         {"id":"large","action":"cancel","result":"inactive"}],
            "active":[{"id":"small","slot":"A","qty":1},{"id":"later","slot":"A","qty":2}],
            "remaining":{"A":0,"B":0}})
        self.assertEqual((capacities, events), original)

    def test_empty_events_keep_zero_capacity(self):
        self.assertEqual(allocate({"安静时段":0}, []), {"decisions":[],"active":[],"remaining":{"安静时段":0}})

    def test_invalid_data_and_duplicate_reserve_ids(self):
        valid = {"action":"reserve","id":"once","slot":"A","qty":1}
        bad_events = [[dict(valid, qty=True)], [dict(valid, qty=0)], [dict(valid, slot="unknown")],
                      [dict(valid, extra=1)], [valid, {"action":"cancel","id":"once"}, valid],
                      [{"action":"cancel","id":""}], [{"action":"reserve","id":"broken"}]]
        for events in bad_events:
            with self.subTest(events=events), self.assertRaises(ValueError):
                allocate({"A":2}, events)
        for capacities in [{"A":True}, {"":1}, {"A":-1}, []]:
            with self.subTest(capacities=capacities), self.assertRaises(ValueError):
                allocate(capacities, [])

    def test_real_utf8_files_and_invalid_last_event_preserve_old_report(self):
        with tempfile.TemporaryDirectory(prefix="图书馆 实践 ") as folder:
            root = Path(folder)
            capacities = root / "容量.json"
            events = root / "预约.json"
            target = root / "结果.json"
            capacities.write_text('{"早班":2}', encoding="utf-8")
            events.write_text('[{"action":"reserve","id":"汤圆","slot":"早班","qty":1}]', encoding="utf-8")
            result = write_report(capacities, events, target)
            self.assertEqual(json.loads(target.read_text(encoding="utf-8")), result)
            self.assertEqual(result["remaining"], {"早班":1})
            previous = target.read_bytes()
            events.write_text('[{"action":"reserve","id":"皮皮","slot":"早班","qty":1},{"action":"reserve","id":"坏项","slot":"早班","qty":true}]', encoding="utf-8")
            with self.assertRaises(ValueError):
                write_report(capacities, events, target)
            self.assertEqual(target.read_bytes(), previous)
            source_before = capacities.read_bytes()
            with self.assertRaises(ValueError):
                write_report(capacities, events, capacities)
            self.assertEqual(capacities.read_bytes(), source_before)

    @unittest.skipUnless(os.name == "posix" and hasattr(signal, "SIGXFSZ"), "This OS does not expose the process file-size limit fault; report partial coverage")
    def test_report_write_failure_preserves_old_bytes_and_cleans_temporary_files(self):
        self.check_write_fault("write")

    def test_report_replace_failure_preserves_old_bytes_and_cleans_temporary_files(self):
        self.check_write_fault("replace")

    def check_write_fault(self, mode):
        with tempfile.TemporaryDirectory(prefix="fieldwork-write-fault-") as folder:
            process = subprocess.run([sys.executable, "-B", "-c", WRITE_FAULT_PROCESS, folder, mode], cwd=ROOT,
                                     capture_output=True, text=True, encoding="utf-8", timeout=10)
            self.assertEqual(process.returncode, 0, process.stdout + process.stderr)
            result = json.loads(process.stdout)
            self.assertTrue(result["previous_report_preserved"])
            self.assertEqual(result["temporary_files_remaining"], 0)
