from pathlib import Path
import tempfile
import unittest
from fieldwork.boundary import read_note


class BoundaryTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name) / "allowed"
        self.root.mkdir()
        (self.root / "note.txt").write_text("允许的笔记", encoding="utf-8")
        self.outside = self.root.parent / "canary.txt"
        self.outside.write_text("测试哨兵", encoding="utf-8")

    def grant(self, relative):
        return {"action": "read", "path": relative, "approved": True}

    def test_exact_approval_and_path_binding(self):
        self.assertEqual(read_note(self.root, "note.txt", self.grant("note.txt")), "允许的笔记")
        for grant in [{}, {"action":"read","path":"note.txt","approved":1},
                      {"action":"write","path":"note.txt","approved":True},
                      {"action":"read","path":"other.txt","approved":True}]:
            with self.subTest(grant=grant), self.assertRaises(PermissionError):
                read_note(self.root, "note.txt", grant)

    def test_path_permission_is_not_os_isolation(self):
        for relative in ["../canary.txt", str(self.outside), "nested/../../canary.txt"]:
            with self.subTest(relative=relative), self.assertRaises(PermissionError):
                read_note(self.root, relative, self.grant(relative))
        self.assertEqual(self.outside.read_text(encoding="utf-8"), "测试哨兵")
        self.assertEqual((self.root / "note.txt").read_text(encoding="utf-8"), "允许的笔记")

    def test_symlink_escape_when_the_platform_supports_links(self):
        link = self.root / "borrowed.txt"
        try:
            link.symlink_to(self.outside)
        except (OSError, NotImplementedError):
            self.skipTest("This platform did not permit the symlink probe")
        with self.assertRaises(PermissionError):
            read_note(self.root, "borrowed.txt", self.grant("borrowed.txt"))

    def test_authorized_missing_file_keeps_the_real_error(self):
        with self.assertRaises(FileNotFoundError):
            read_note(self.root, "missing.txt", self.grant("missing.txt"))
