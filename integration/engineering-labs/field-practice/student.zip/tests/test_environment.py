import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from fieldwork.environment import python_sources

ROOT = Path(__file__).resolve().parents[1]


class EnvironmentTests(unittest.TestCase):
    def test_real_cwd_wrong_directory_and_absolute_recovery(self):
        with tempfile.TemporaryDirectory(prefix="远航 有空格 ") as folder:
            root = Path(folder)
            project = root / "练习目录"
            elsewhere = root / "另一目录"
            project.mkdir()
            elsewhere.mkdir()
            marker = project / "路标.txt"
            marker.write_text("到达\n", encoding="utf-8")
            command = [sys.executable, "-B", str(ROOT / "run.py"), "environment"]
            correct = subprocess.run(command + [marker.name], cwd=project, capture_output=True, text=True, timeout=5)
            self.assertEqual(correct.returncode, 0, correct.stderr)
            row = json.loads(correct.stdout)
            self.assertEqual(row["cwd"], str(project.resolve()))
            self.assertEqual(row["interpreter"], str(Path(sys.executable).resolve()))
            self.assertEqual(row["marker_path"], str(marker.resolve()))
            self.assertEqual(row["marker_text"], "到达\n")
            wrong = subprocess.run(command + [marker.name], cwd=elsewhere, capture_output=True, text=True, timeout=5)
            self.assertEqual(wrong.returncode, 2)
            self.assertIn("FileNotFoundError", wrong.stderr)
            recovered = subprocess.run(command + [str(marker)], cwd=elsewhere, capture_output=True, text=True, timeout=5)
            self.assertEqual(recovered.returncode, 0, recovered.stderr)
            self.assertEqual(json.loads(recovered.stdout)["cwd"], str(elsewhere.resolve()))

    def test_real_extension_and_file_type(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            for name in ["正确.py", "错误.py.txt", "notes.txt", "main.py"]:
                (root / name).write_text("", encoding="utf-8")
            (root / "目录.py").mkdir()
            self.assertEqual(python_sources(root), ["main.py", "正确.py"])
