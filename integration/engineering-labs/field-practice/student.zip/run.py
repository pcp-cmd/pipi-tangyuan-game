import argparse
import json
from pathlib import Path
import sys
from fieldwork.environment import inspect_launch
from fieldwork.experiment import write_comparison
from fieldwork.graduate import write_report


def main(argv=None):
    parser = argparse.ArgumentParser(description="在自己的目录完成远航实践")
    commands = parser.add_subparsers(dest="command", required=True)
    environment = commands.add_parser("environment")
    environment.add_argument("marker")
    comparison = commands.add_parser("compare")
    comparison.add_argument("--output", default="ARCHITECTURES.json")
    graduation = commands.add_parser("graduate")
    graduation.add_argument("capacities")
    graduation.add_argument("events")
    graduation.add_argument("output")
    args = parser.parse_args(argv)
    try:
        if args.command == "environment":
            result = inspect_launch(args.marker)
        elif args.command == "compare":
            result = write_comparison(Path(__file__).resolve().parent, args.output)
        else:
            result = write_report(args.capacities, args.events, args.output)
    except (OSError, ValueError, NotImplementedError) as exc:
        print(type(exc).__name__ + ": " + str(exc), file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
