"""异题小例：一张馆藏借阅票的版本快照，不实现本题派送流程。"""
from copy import deepcopy

ticket = {"version": 1, "book": "星图", "days": 7}
reviewed = deepcopy(ticket)
ticket["version"] += 1
ticket["days"] = 14

assert reviewed["days"] == 7
assert reviewed != ticket
print("reviewed:", reviewed)
print("current:", ticket)
print("旧审核只能解释旧版本；当前借阅条件需要重新查看。")
