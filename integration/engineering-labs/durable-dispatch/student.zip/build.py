"""Package only this authored/learner source; no dependency downloads."""
from pathlib import Path
import shutil
import tempfile
import zipapp


def main():
    root = Path(__file__).resolve().parent
    destination = root / "durable-dispatch.pyz"
    if destination.exists():
        raise SystemExit("Output already exists; retain it or choose a fresh project copy.")
    with tempfile.TemporaryDirectory(prefix="pipi-durable-build-") as temporary:
        source = Path(temporary)
        target = source / "durable_learning"
        target.mkdir()
        for file in sorted((root / "durable_learning").glob("*.py")):
            shutil.copy2(file, target / file.name)
        (source / "__main__.py").write_text("from durable_learning.cli import main\nraise SystemExit(main())\n", encoding="utf-8")
        zipapp.create_archive(source, destination, interpreter="/usr/bin/env python3")
    print(destination.name)


if __name__ == "__main__":
    main()
