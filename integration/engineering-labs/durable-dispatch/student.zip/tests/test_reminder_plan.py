import hashlib
import json
import sqlite3
import unittest

from durable_learning import personal, reminder_plan
from tests.test_durable import DurableCase
from tests.test_personal import LocalProvider


class SailingTransferTests(DurableCase):
    def source(self, records, name="changes.json"):
        path = self.folder / name
        path.write_text(json.dumps(records, ensure_ascii=False), encoding="utf-8")
        return path

    def rows_input(self):
        return [
            {"trip_id": "morning", "recipient": "皮皮", "previous_departure": 60, "departure": 75, "cancelled": False},
            {"trip_id": "evening", "recipient": "汤圆", "previous_departure": 180, "departure": 180, "cancelled": True},
            {"trip_id": "unchanged", "recipient": "皮皮", "previous_departure": 30, "departure": 30, "cancelled": False},
        ]

    def test_unknown_task_data_builds_only_drafts_then_requires_individual_actual_approval(self):
        path, target = self.db(), self.db("effects.sqlite")
        source = self.source(self.rows_input())
        ids = reminder_plan.prepare_trip_batch(path, source, "batch-1")
        expected = sorted("trip-" + hashlib.sha256(json.dumps(["batch-1", row["trip_id"], row["recipient"]], ensure_ascii=False, separators=(",", ":")).encode()).hexdigest() for row in self.rows_input()[:2])
        self.assertEqual(ids, expected)
        state = personal.inspect(path)
        self.assertEqual(state["approvals"], []); self.assertEqual(state["dispatch_jobs"], [])
        provider = LocalProvider(target, lose_reply=True)
        self.assertEqual(personal.run(path, provider, "worker", clock=lambda: 1)["status"], "idle")
        self.assertEqual(provider.calls, [])
        first = ids[0]
        personal.approve_draft(path, first, 1, "send-" + first, "approve-1", "host", 50, 1)
        personal.queue_approved(path, "approve-1", "host", 1)
        self.assertEqual(personal.run(path, provider, "worker", clock=lambda: 2)["status"], "completed")
        effects = self.rows(target, "SELECT op,payload FROM effects")
        self.assertEqual(len(effects), 1)
        actual = json.loads(effects[0][1]); draft = next(row for row in state["drafts"] if row["draft_id"] == first)
        self.assertEqual(actual, {"to": draft["recipient"], "body": draft["body"]})
        self.assertEqual(reminder_plan.prepare_trip_batch(path, source, "batch-1"), ids)
        self.assertEqual(len(personal.inspect(path)["approvals"]), 1)
        self.assertEqual(len(self.rows(target, "SELECT * FROM effects")), 1)

    def test_same_trip_for_different_people_and_empty_input_are_valid(self):
        records = self.rows_input()[:1]
        records.append({**records[0], "recipient": "汤圆"})
        path = self.db()
        ids = reminder_plan.prepare_trip_batch(path, self.source(records), "batch")
        self.assertEqual(len(set(ids)), 2)
        self.assertEqual(reminder_plan.prepare_trip_batch(path, self.source([], "empty.json"), "empty"), [])
        self.assertEqual(len(personal.inspect(path)["drafts"]), 2)

    def test_invalid_record_later_in_file_never_leaves_a_partial_batch(self):
        variants = [
            {**self.rows_input()[0], "departure": True},
            {**self.rows_input()[0], "cancelled": 1},
            {**self.rows_input()[0], "unexpected": "instruction"},
            {**self.rows_input()[0], "recipient": ""},
            self.rows_input()[0],
        ]
        for index, bad in enumerate(variants):
            path = self.db(str(index) + ".sqlite")
            with self.assertRaises(ValueError):
                reminder_plan.prepare_trip_batch(path, self.source([self.rows_input()[0], bad], str(index)+".json"), "batch")
            self.assertFalse(path.exists())

    def test_changed_source_and_edited_draft_are_not_silently_overwritten(self):
        path = self.db()
        source = self.source(self.rows_input())
        ids = reminder_plan.prepare_trip_batch(path, source, "batch")
        before = personal.inspect(path)
        source.write_text(source.read_text() + "\n", encoding="utf-8")
        with self.assertRaises(ValueError):
            reminder_plan.prepare_trip_batch(path, source, "batch")
        self.assertEqual(personal.inspect(path), before)
        source = self.source(self.rows_input())
        personal.save_draft(path, ids[0], "manually changed box", "manual revision", 1)
        with self.assertRaises(ValueError):
            reminder_plan.prepare_trip_batch(path, source, "batch")
        self.assertEqual(next(row for row in personal.inspect(path)["drafts"] if row["draft_id"] == ids[0])["body"], "manual revision")

    def test_database_failure_halfway_rolls_back_all_new_drafts_and_batch(self):
        path = self.db()
        personal.inspect(path)
        db = sqlite3.connect(path)
        try:
            db.execute("CREATE TRIGGER reject_second BEFORE INSERT ON drafts WHEN (SELECT COUNT(*) FROM drafts)>=1 BEGIN SELECT RAISE(ABORT, 'second draft refused'); END")
        finally:
            db.close()
        with self.assertRaises(sqlite3.IntegrityError):
            reminder_plan.prepare_trip_batch(path, self.source(self.rows_input()), "batch")
        self.assertEqual(personal.inspect(path)["drafts"], [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
