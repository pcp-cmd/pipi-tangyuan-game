"""Behavior checks use only temporary databases and fictional records."""
