import asyncio
import json
from pathlib import Path
import queue
import sqlite3
import subprocess
import sys
import tempfile
import threading
import unittest

from durable_learning import checkpoint, receiver, outbox, fenced_store, approval, retrying

ROOT = Path(__file__).resolve().parents[1]


class DurableCase(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="pipi-durable-author-")
        self.addCleanup(temporary.cleanup)
        self.folder = Path(temporary.name)

    def db(self, name="state.sqlite"):
        return self.folder / name

    def rows(self, path, sql, parameters=()):
        db = sqlite3.connect(path)
        try:
            return db.execute(sql, parameters).fetchall()
        finally:
            db.close()

    def command(self, source, *arguments, check=True):
        result = subprocess.run([sys.executable, "-I", "-B", "-c", "import sys; sys.path.insert(0, sys.argv[1]);\n" + source, str(ROOT), *map(str, arguments)], capture_output=True, text=True, timeout=10)
        if check:
            self.assertEqual(result.returncode, 0, result.stderr)
        return result

    def process(self, source, *arguments):
        process = subprocess.Popen([sys.executable, "-I", "-B", "-c", "import sys; sys.path.insert(0, sys.argv[1]);\n" + source, str(ROOT), *map(str, arguments)], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, bufsize=1)
        def stop():
            if process.poll() is None:
                process.kill()
            process.communicate(timeout=5)
        self.addCleanup(stop)
        return process

    def line(self, process):
        messages = queue.Queue()
        reader = threading.Thread(target=lambda: messages.put(process.stdout.readline()), daemon=True)
        reader.start()
        line = messages.get(timeout=5)
        self.assertTrue(line, "child closed stdout before reporting expected phase")
        return line.rstrip("\n")


class CheckpointTests(DurableCase):
    def test_commit_and_reject_duplicate_without_overwriting(self):
        path = self.db()
        checkpoint.save_checkpoint(path, "第一站", "路线一")
        with self.assertRaises(sqlite3.IntegrityError):
            checkpoint.save_checkpoint(path, "第一站", "错误覆盖")
        self.assertEqual(self.rows(path, "SELECT * FROM progress"), [("第一站", "路线一")])
        self.assertEqual(self.rows(path, "SELECT * FROM notes"), [("第一站", "路线一")])

    def test_failure_between_writes_keeps_previous_pair_only(self):
        path = self.db()
        checkpoint.save_checkpoint(path, "before", "kept")
        with self.assertRaisesRegex(RuntimeError, "interrupted"):
            checkpoint.save_checkpoint(path, "broken", "half", crash=True)
        for table in ["progress", "notes"]:
            self.assertEqual(self.rows(path, f"SELECT * FROM {table} ORDER BY name"), [("before", "kept")])

    def test_real_connections_close_on_success_duplicate_and_failure(self):
        opened = []
        active = [True]
        def observe(event, args):
            if active[0] and event == "sqlite3.connect/handle":
                opened.append(args[0])
        sys.addaudithook(observe)
        path = self.db()
        try:
            checkpoint.save_checkpoint(path, "good", "saved")
            with self.assertRaises(sqlite3.IntegrityError):
                checkpoint.save_checkpoint(path, "good", "again")
            with self.assertRaises(RuntimeError):
                checkpoint.save_checkpoint(path, "new", "broken", crash=True)
        finally:
            active[0] = False
        self.assertGreaterEqual(len(opened), 3)
        for db in opened:
            with self.assertRaises(sqlite3.ProgrammingError):
                db.execute("SELECT 1")



class ReceiverTests(DurableCase):
    def test_replay_conflict_and_new_intent_have_distinct_effects(self):
        path = self.db()
        self.assertIsNone(receiver.lookup(path, "unknown"))
        self.assertEqual(self.rows(path, "SELECT * FROM effects"), [])
        first = receiver.receive(path, "intent-a", "one boat ticket")
        self.assertTrue(isinstance(first, str) and first)
        self.assertEqual(receiver.receive(path, "intent-a", "one boat ticket"), first)
        with self.assertRaises(ValueError):
            receiver.receive(path, "intent-a", "two other tickets")
        second = receiver.receive(path, "intent-b", "one boat ticket")
        self.assertNotEqual(first, second)
        self.assertEqual(self.rows(path, "SELECT op, payload FROM effects ORDER BY id"), [("intent-a", "one boat ticket"), ("intent-b", "one boat ticket")])
        self.assertEqual(len(self.rows(path, "SELECT * FROM receipts")), 2)

    def test_receipt_write_failure_rolls_back_the_effect(self):
        path = self.db()
        receiver.lookup(path, "prepare")
        db = sqlite3.connect(path)
        try:
            db.execute("CREATE TRIGGER reject_receipt BEFORE INSERT ON receipts BEGIN SELECT RAISE(ABORT, 'receipt blocked'); END")
        finally:
            db.close()
        with self.assertRaises(sqlite3.IntegrityError):
            receiver.receive(path, "intent", "payload")
        self.assertEqual(self.rows(path, "SELECT * FROM effects"), [])
        self.assertEqual(self.rows(path, "SELECT * FROM receipts"), [])

    def test_reply_lost_and_restarted_receiver_replay_one_effect(self):
        path = self.db()
        failure = self.command('from durable_learning.receiver import receive\nreceive(sys.argv[2], "op", "notice")\nraise TimeoutError("reply lost after commit")', path, check=False)
        self.assertNotEqual(failure.returncode, 0)
        self.assertIn("reply lost after commit", failure.stderr)
        first = receiver.lookup(path, "op")
        replay = self.command('from durable_learning.receiver import receive\nprint(receive(sys.argv[2], "op", "notice"))', path)
        self.assertEqual(replay.stdout.strip(), first)
        self.assertEqual(len(self.rows(path, "SELECT * FROM effects")), 1)

    def test_expired_replay_memory_does_not_erase_old_effect(self):
        path = self.db()
        receiver.receive(path, "op", "notice")
        db = sqlite3.connect(path)
        try:
            db.execute("DELETE FROM receipts")
            db.commit()
        finally:
            db.close()
        receiver.receive(path, "op", "notice")
        self.assertEqual(len(self.rows(path, "SELECT * FROM effects")), 2)

    def test_invalid_inputs_do_not_create_a_database(self):
        for index, args in enumerate([(None, "x"), ("", "x"), (True, "x"), ("op", ""), ("op", {})]):
            path = self.db(str(index) + ".sqlite")
            with self.assertRaises(ValueError):
                receiver.receive(path, *args)
            self.assertFalse(path.exists())


class OutboxTests(DurableCase):
    def test_state_receipt_pair_inconsistency_is_explicit_and_preserved(self):
        for index, (state, receipt) in enumerate([("sent", None), ("sent", ""), ("pending", "unexpected")]):
            path = self.db(str(index) + ".sqlite")
            outbox.enqueue(path, "op", "notice")
            db = sqlite3.connect(path)
            try:
                db.execute("UPDATE outbox SET state=?,receipt=?", (state, receipt))
                db.commit()
            finally:
                db.close()
            before = self.rows(path, "SELECT * FROM outbox")
            with self.assertRaises(RuntimeError):
                outbox.enqueue(path, "op", "notice")
            self.assertEqual(self.rows(path, "SELECT * FROM outbox"), before)

    def test_enqueue_pair_failure_and_replay_do_not_reset_sent(self):
        path = self.db()
        outbox.enqueue(path, "before", "kept")
        with self.assertRaises(RuntimeError):
            outbox.enqueue(path, "half", "lost", crash=True)
        self.assertEqual(self.rows(path, "SELECT * FROM orders"), [("before", "kept")])
        self.assertEqual(outbox.deliver(path, lambda op, text: "receipt-1"), 1)
        outbox.enqueue(path, "before", "kept")
        with self.assertRaises(ValueError):
            outbox.enqueue(path, "before", "changed")
        self.assertEqual(self.rows(path, "SELECT op, payload, state, receipt FROM outbox"), [("before", "kept", "sent", "receipt-1")])
        self.assertEqual(outbox.deliver(path, lambda op, text: self.fail("confirmed item sent again")), 0)

    def test_failure_keeps_current_and_later_pending_in_sorted_order(self):
        path = self.db()
        for op in ["c", "a", "b"]:
            outbox.enqueue(path, op, "notice-" + op)
        calls = []
        failure = OSError("not available")
        def send(op, payload):
            calls.append((op, payload))
            if op == "b":
                raise failure
            return "receipt-" + op
        with self.assertRaises(OSError) as result:
            outbox.deliver(path, send)
        self.assertIs(result.exception, failure)
        self.assertEqual(calls, [("a", "notice-a"), ("b", "notice-b")])
        self.assertEqual(self.rows(path, "SELECT op, state FROM outbox ORDER BY op"), [("a", "sent"), ("b", "pending"), ("c", "pending")])

    def test_sent_effect_before_local_ack_replays_same_intent(self):
        sender, target = self.db("sender.sqlite"), self.db("receiver.sqlite")
        outbox.enqueue(sender, "op-7", "one notice")
        calls = []
        def send(op, payload):
            calls.append((op, payload))
            return receiver.receive(target, op, payload)
        with self.assertRaises(RuntimeError):
            outbox.deliver(sender, send, crash=True)
        self.assertEqual(self.rows(sender, "SELECT state FROM outbox"), [("pending",)])
        self.assertEqual(len(self.rows(target, "SELECT * FROM effects")), 1)
        self.assertEqual(outbox.deliver(sender, send), 1)
        self.assertEqual(calls, [("op-7", "one notice"), ("op-7", "one notice")])
        self.assertEqual(len(self.rows(target, "SELECT * FROM effects")), 1)
        self.assertEqual(self.rows(sender, "SELECT state FROM outbox"), [("sent",)])

    def test_lost_reply_recovers_across_real_sender_processes(self):
        sender, target = self.db("sender.sqlite"), self.db("receiver.sqlite")
        outbox.enqueue(sender, "op", "notice")
        source = '''
from durable_learning import outbox, receiver
def send(op, payload):
    receiver.receive(sys.argv[3], op, payload)
    raise TimeoutError("receiver committed but reply vanished")
outbox.deliver(sys.argv[2], send)
'''
        failed = self.command(source, sender, target, check=False)
        self.assertNotEqual(failed.returncode, 0)
        self.assertIn("receiver committed but reply vanished", failed.stderr)
        self.assertEqual(self.rows(sender, "SELECT state FROM outbox"), [("pending",)])
        self.assertEqual(len(self.rows(target, "SELECT * FROM effects")), 1)
        resumed = self.command('from durable_learning import outbox, receiver\nprint(outbox.deliver(sys.argv[2], lambda op, payload: receiver.receive(sys.argv[3], op, payload)))', sender, target)
        self.assertEqual(resumed.stdout.strip(), "1")
        self.assertEqual(self.rows(sender, "SELECT state FROM outbox"), [("sent",)])
        self.assertEqual(len(self.rows(target, "SELECT * FROM effects")), 1)

    def test_invalid_receipt_does_not_confirm(self):
        for index, receipt in enumerate([None, False, 0, "", {"passed": True}]):
            path = self.db(str(index) + ".sqlite")
            outbox.enqueue(path, "op", "notice")
            with self.assertRaises(ValueError):
                outbox.deliver(path, lambda op, payload: receipt)
            self.assertEqual(self.rows(path, "SELECT state, receipt FROM outbox"), [("pending", None)])


class FencingTests(DurableCase):
    def test_out_of_range_or_exhausted_generation_never_becomes_overflow_or_wrap(self):
        path = self.db()
        fenced_store.claim(path, "worker", 0, 10)
        before = self.rows(path, "SELECT * FROM jobs")
        for value in [1 << 63, 10 ** 100, True]:
            caught = None
            try:
                fenced_store.publish(path, "worker", value, 1, "bad")
            except BaseException as error:
                caught = error
            self.assertIsInstance(caught, PermissionError)
            self.assertEqual(self.rows(path, "SELECT * FROM jobs"), before)
        db = sqlite3.connect(path)
        try:
            db.execute("UPDATE jobs SET generation=?,until=0", ((1 << 63) - 1,))
            db.commit()
        finally:
            db.close()
        before = self.rows(path, "SELECT * FROM jobs")
        caught = None
        try:
            fenced_store.claim(path, "worker", 11, 10)
        except BaseException as error:
            caught = error
        self.assertIsInstance(caught, RuntimeError)
        self.assertEqual(self.rows(path, "SELECT * FROM jobs"), before)

    def test_same_name_different_generation_cannot_publish_old_result(self):
        path = self.db()
        first = fenced_store.claim(path, "worker", 0, ttl=10)
        self.assertEqual(first, 1)
        self.assertIsNone(fenced_store.claim(path, "other", 9.9))
        second = fenced_store.claim(path, "worker", 10, ttl=20)
        self.assertEqual(second, 2)
        with self.assertRaises(PermissionError):
            fenced_store.publish(path, "worker", first, 11, "stale")
        self.assertEqual(self.rows(path, "SELECT generation, result, state FROM jobs"), [(2, None, "pending")])
        fenced_store.publish(path, "worker", second, 12, "current")
        self.assertIsNone(fenced_store.claim(path, "third", 99))
        with self.assertRaises(PermissionError):
            fenced_store.publish(path, "worker", second, 13, "overwrite")
        self.assertEqual(self.rows(path, "SELECT generation, result, state FROM jobs"), [(2, "current", "done")])

    def test_expired_token_without_takeover_still_cannot_publish(self):
        path = self.db()
        generation = fenced_store.claim(path, "worker", 5, ttl=2)
        with self.assertRaises(PermissionError):
            fenced_store.publish(path, "worker", generation, 7, "expired")
        self.assertEqual(self.rows(path, "SELECT result, state FROM jobs"), [(None, "pending")])

    def test_restarted_process_preserves_generation_and_rejects_old_owner(self):
        path = self.db()
        fenced_store.claim(path, "old", 0, ttl=1)
        new = self.command('from durable_learning.fenced_store import claim\nprint(claim(sys.argv[2], "new", 1, ttl=10))', path)
        self.assertEqual(new.stdout.strip(), "2")
        with self.assertRaises(PermissionError):
            fenced_store.publish(path, "old", 1, 2, "stale")
        fenced_store.publish(path, "new", 2, 2, "new result")
        self.assertEqual(self.rows(path, "SELECT result FROM jobs"), [("new result",)])

    def test_two_real_claiming_processes_have_one_winner(self):
        path = self.db()
        fenced_store.claim(path, "expired", 0, ttl=1)
        source = '''
import json
from durable_learning.fenced_store import claim
print("ready", flush=True)
sys.stdin.readline()
print(json.dumps(claim(sys.argv[2], sys.argv[3], 1, ttl=10)), flush=True)
'''
        first, second = self.process(source, path, "alpha"), self.process(source, path, "beta")
        self.assertEqual(self.line(first), "ready")
        self.assertEqual(self.line(second), "ready")
        first.stdin.write("go\n"); first.stdin.flush()
        second.stdin.write("go\n"); second.stdin.flush()
        values = [json.loads(self.line(first)), json.loads(self.line(second))]
        for child in [first, second]:
            child.wait(timeout=5)
            self.assertEqual(child.returncode, 0, child.stderr.read())
        self.assertEqual(values.count(2), 1)
        self.assertEqual(values.count(None), 1)
        self.assertEqual(self.rows(path, "SELECT generation, state FROM jobs"), [(2, "pending")])

    def test_bad_clock_or_ttl_rejected_before_database(self):
        for index, (now, ttl) in enumerate([(0, 0), (0, -1), (True, 2), (0, False), (float("nan"), 1), (0, float("inf")), (1e308, 1e308)]):
            path = self.db(str(index) + ".sqlite")
            with self.assertRaises(ValueError):
                fenced_store.claim(path, "worker", now, ttl)
            self.assertFalse(path.exists())


class ApprovalTests(unittest.TestCase):
    def grant(self):
        args = {"to": "fictional-camp", "body": "one notice"}
        return {"actor": "local-host", "action": "send-local", "args_json": json.dumps(args, sort_keys=True, allow_nan=False), "expires_at": 10, "used": False}, args

    def test_independent_refusals_leave_approval_and_effects_unchanged(self):
        variants = [
            {"actor": "model"}, {"action": "delete"}, {"args": {"to": "other", "body": "one notice"}},
            {"args": {"to": "fictional-camp", "body": "changed"}}, {"now": 10}, {"now": True},
        ]
        for changed in variants:
            with self.subTest(changed=changed):
                grant, args = self.grant()
                before = dict(grant)
                effects = []
                request = {"actor": "local-host", "action": "send-local", "args": args, "now": 9}
                request.update(changed)
                with self.assertRaises(PermissionError):
                    approval.execute_approved(grant, effect=effects.append, **request)
                self.assertEqual(grant, before)
                self.assertEqual(effects, [])
                approval.execute_approved(grant, "local-host", "send-local", args, 9, effects.append)
                self.assertEqual(effects, [args])

    def test_one_consumption_actual_snapshot_and_no_input_alias(self):
        grant, args = self.grant()
        effects = []
        result = object()
        def effect(actual):
            effects.append(dict(actual))
            actual["body"] = "effect-owned modification"
            return result
        self.assertIs(approval.execute_approved(grant, "local-host", "send-local", args, 9, effect), result)
        self.assertIs(grant["used"], True)
        self.assertEqual(args, {"to": "fictional-camp", "body": "one notice"})
        self.assertEqual(effects, [args])
        with self.assertRaises(PermissionError):
            approval.execute_approved(grant, "local-host", "send-local", args, 9, effect)
        self.assertEqual(len(effects), 1)

    def test_bad_grant_does_not_become_default_permission(self):
        for mutate in [lambda g: g.pop("actor"), lambda g: g.update(used=0), lambda g: g.update(expires_at=True), lambda g: g.update(args_json={"to": "fictional-camp", "body": "one notice"})]:
            grant, args = self.grant()
            mutate(grant)
            before = dict(grant)
            with self.assertRaises(PermissionError):
                approval.execute_approved(grant, "local-host", "send-local", args, 9, lambda _: self.fail("denied effect ran"))
            self.assertEqual(grant, before)

    def test_effect_failure_consumes_attempt_and_preserves_original_exception(self):
        grant, args = self.grant()
        failure = OSError("effect result is unknown")
        def effect(_):
            raise failure
        with self.assertRaises(OSError) as raised:
            approval.execute_approved(grant, "local-host", "send-local", args, 9, effect)
        self.assertIs(raised.exception, failure)
        self.assertTrue(grant["used"])


class RetryTests(unittest.IsolatedAsyncioTestCase):
    async def test_real_attempts_wait_only_between_failures_and_preserve_result(self):
        calls, delays = [], []
        answer = object()
        async def operation():
            calls.append(1)
            if len(calls) < 3:
                raise retrying.TransientError("retryable")
            return answer
        async def pause(delay):
            delays.append(delay)
        self.assertIs(await retrying.retry(operation, 3, 0.25, pause), answer)
        self.assertEqual(len(calls), 3)
        self.assertEqual(delays, [0.25, 0.5])

    async def test_final_failure_is_same_object_without_final_sleep(self):
        calls, delays = [], []
        failure = retrying.TransientError("last failure")
        async def operation():
            calls.append(1)
            raise failure
        async def pause(delay):
            delays.append(delay)
        with self.assertRaises(retrying.TransientError) as raised:
            await retrying.retry(operation, 3, 1, pause)
        self.assertIs(raised.exception, failure)
        self.assertEqual(len(calls), 3)
        self.assertEqual(delays, [1, 2])

    async def test_permanent_error_and_cancellation_are_not_retried(self):
        for failure in [ValueError("permanent"), asyncio.CancelledError("stop")]:
            calls, delays = [], []
            async def operation():
                calls.append(1)
                raise failure
            async def pause(delay):
                delays.append(delay)
            with self.assertRaises(type(failure)) as raised:
                await retrying.retry(operation, 4, 0, pause)
            self.assertIs(raised.exception, failure)
            self.assertEqual(calls, [1])
            self.assertEqual(delays, [])

    async def test_invalid_budget_or_delay_has_no_calls(self):
        calls = []
        async def operation():
            calls.append(1)
        for attempts, delay in [(True, 0), (0, 0), (1.0, 0), (1, -1), (1, float("nan")), (1, False)]:
            with self.assertRaises(ValueError):
                await retrying.retry(operation, attempts, delay)
        self.assertEqual(calls, [])

    async def test_deadline_covers_wait_between_attempts_and_joins_cleanup(self):
        calls, delays = [], []
        waiting = asyncio.Event()
        cleaned = asyncio.Event()
        async def operation():
            calls.append(1)
            raise retrying.TransientError("not ready")
        async def pause(delay):
            delays.append(delay)
            try:
                await waiting.wait()
            finally:
                cleaned.set()
        async def whole_operation():
            return await retrying.retry(operation, 3, 0.1, pause)
        with self.assertRaises(TimeoutError):
            await retrying.with_deadline(whole_operation, 0.02)
        self.assertEqual(calls, [1])
        self.assertEqual(delays, [0.1])
        self.assertTrue(cleaned.is_set())


if __name__ == "__main__":
    unittest.main(verbosity=2)
