"""A composed workflow: real approvals, jobs, receiver effects and process recovery."""
import json
import sqlite3
import unittest

from durable_learning import personal, receiver
from durable_learning.personal_provider import LocalReceiptProvider
from tests.test_durable import DurableCase


class LocalProvider(LocalReceiptProvider):
    def __init__(self, path, lose_reply=False):
        super().__init__(path, lose_reply)
        self.calls = []

    def lookup(self, op):
        self.calls.append(("lookup", op))
        return super().lookup(op)

    def send(self, op, payload):
        self.calls.append(("send", op, payload))
        return super().send(op, payload)


class PersonalHostTests(DurableCase):
    def prepared(self, *, expires=100, op="notice-1"):
        path, target = self.db("personal.sqlite"), self.db("provider.sqlite")
        personal.save_draft(path, "draft-1", "fictional-inbox", "带上营地手册", 0)
        personal.approve_draft(path, "draft-1", 1, op, "approval-1", "host", expires, 0)
        personal.queue_approved(path, "approval-1", "host", 0)
        return path, target

    def test_persistent_version_compare_and_swap_and_old_approval_cannot_queue(self):
        path = self.db()
        self.assertEqual(personal.save_draft(path, "draft", "blue-box", "first", 0), 1)
        personal.approve_draft(path, "draft", 1, "op", "grant", "host", 100, 0)
        self.assertEqual(personal.save_draft(path, "draft", "red-box", "second", 1), 2)
        with self.assertRaises(ValueError):
            personal.save_draft(path, "draft", "wrong", "stale", 1)
        with self.assertRaises(PermissionError):
            personal.queue_approved(path, "grant", "host", 1)
        with self.assertRaises(PermissionError):
            personal.approve_draft(path, "draft", 1, "op", "another", "host", 100, 1)
        state = personal.inspect(path)
        self.assertEqual(state["drafts"][0]["body"], "second")
        self.assertEqual(state["approvals"][0]["used"], 0)
        self.assertEqual(state["dispatch_jobs"], [])

    def test_consumption_and_job_are_atomic_and_repeated_enqueue_is_idempotent(self):
        path = self.db()
        personal.save_draft(path, "draft", "box", "notice")
        personal.approve_draft(path, "draft", 1, "op", "grant", "host", 100, 0)
        db = sqlite3.connect(path)
        try:
            db.execute("CREATE TRIGGER block_job BEFORE INSERT ON dispatch_jobs BEGIN SELECT RAISE(ABORT, 'job refused'); END")
        finally:
            db.close()
        with self.assertRaises(sqlite3.IntegrityError):
            personal.queue_approved(path, "grant", "host", 1)
        self.assertEqual(personal.inspect(path)["approvals"][0]["used"], 0)
        self.assertEqual(personal.inspect(path)["dispatch_jobs"], [])
        db = sqlite3.connect(path)
        try:
            db.execute("DROP TRIGGER block_job")
            db.execute("CREATE TRIGGER block_consume BEFORE UPDATE ON approvals BEGIN SELECT RAISE(ABORT, 'consume refused'); END")
        finally:
            db.close()
        with self.assertRaises(sqlite3.IntegrityError):
            personal.queue_approved(path, "grant", "host", 1)
        self.assertEqual(personal.inspect(path)["approvals"][0]["used"], 0)
        self.assertEqual(personal.inspect(path)["dispatch_jobs"], [])
        db = sqlite3.connect(path)
        try:
            db.execute("DROP TRIGGER block_consume")
        finally:
            db.close()
        for _ in range(2):
            self.assertEqual(personal.queue_approved(path, "grant", "host", 2), "op")
        state = personal.inspect(path)
        self.assertEqual(len(state["dispatch_jobs"]), 1)
        self.assertEqual(state["approvals"][0]["used"], 1)

    def test_explicit_actor_expiry_and_approval_identity_each_reject_without_consumption(self):
        for index, (actor, now) in enumerate([("model", 0), ("host", 5), ("host", True)]):
            path = self.db(str(index) + ".sqlite")
            personal.save_draft(path, "draft", "box", "notice")
            personal.approve_draft(path, "draft", 1, "op", "grant", "host", 5, 0)
            with self.assertRaises(PermissionError):
                personal.queue_approved(path, "grant", actor, now)
            self.assertEqual(personal.inspect(path)["approvals"][0]["used"], 0)
            self.assertEqual(personal.inspect(path)["dispatch_jobs"], [])
            with self.assertRaises(ValueError):
                personal.approve_draft(path, "draft", 1, "different-op", "grant", "host", 5, 0)

    def test_queued_intent_is_immutable_and_operation_conflicts_do_not_rebind(self):
        path, _ = self.prepared()
        before = personal.inspect(path)
        with self.assertRaises(PermissionError):
            personal.save_draft(path, "draft-1", "other-box", "different", 1)
        personal.save_draft(path, "draft-2", "box-2", "new intent")
        personal.approve_draft(path, "draft-2", 1, "notice-1", "grant-2", "host", 100, 0)
        with self.assertRaises(ValueError):
            personal.queue_approved(path, "grant-2", "host", 0)
        after = personal.inspect(path)
        self.assertEqual(after["dispatch_jobs"], before["dispatch_jobs"])
        self.assertEqual(after["approvals"][1]["used"], 0)

    def test_bounded_host_recovers_unknown_reply_by_lookup_and_observes_one_actual_effect(self):
        path, target = self.prepared()
        provider = LocalProvider(target, lose_reply=True)
        try:
            result = personal.run(path, provider, "worker", clock=lambda: 1, max_steps=4)
        except BaseException as error:
            self.fail("valid recovery raised " + type(error).__name__)
        self.assertEqual(result["status"], "completed")
        self.assertEqual([row["status"] for row in result["observations"]], ["unconfirmed", "sent", "idle"])
        self.assertEqual([call[0] for call in provider.calls], ["lookup", "send", "lookup"])
        effects = self.rows(target, "SELECT op,payload FROM effects")
        self.assertEqual(len(effects), 1)
        self.assertEqual(effects[0][0], "notice-1")
        self.assertEqual(json.loads(effects[0][1]), {"to": "fictional-inbox", "body": "带上营地手册"})
        job = personal.inspect(path)["dispatch_jobs"][0]
        self.assertEqual(job["state"], "sent")
        self.assertEqual(job["receipt"], receiver.lookup(target, "notice-1"))

    def test_new_process_recovers_after_provider_commit_and_original_exception(self):
        path, target = self.prepared()
        first = self.command('''
from durable_learning import personal
from durable_learning.personal_provider import LocalReceiptProvider
class Provider(LocalReceiptProvider):
    def send(self, op, payload):
        super().send(op, payload)
        raise TimeoutError("reply lost after actual commit")
personal.dispatch_one(sys.argv[2], Provider(sys.argv[3]), "first", clock=lambda: 1)
''', path, target, check=False)
        self.assertNotEqual(first.returncode, 0)
        self.assertIn("reply lost after actual commit", first.stderr)
        self.assertEqual(personal.inspect(path)["dispatch_jobs"][0]["last_error"], "send-unconfirmed")
        second = self.command('''
import json
from durable_learning import personal
from durable_learning.personal_provider import LocalReceiptProvider
class Provider(LocalReceiptProvider):
    def send(self, op, payload): raise AssertionError("receipt already exists; never resend")
print(json.dumps(personal.dispatch_one(sys.argv[2], Provider(sys.argv[3]), "second", clock=lambda: 2)))
''', path, target)
        self.assertEqual(json.loads(second.stdout)["status"], "sent")
        self.assertEqual(len(self.rows(target, "SELECT * FROM effects")), 1)

    def test_expiry_before_actual_send_blocks_then_fresh_approval_resumes_same_intent(self):
        path, target = self.prepared(expires=5)
        ticks = iter([0, 5])
        provider = LocalProvider(target)
        stopped = personal.dispatch_one(path, provider, "worker", clock=lambda: next(ticks, 5), ttl=10)
        self.assertEqual(stopped["status"], "approval-expired")
        self.assertEqual(provider.calls, [("lookup", "notice-1")])
        self.assertEqual(self.rows(target, "SELECT * FROM effects"), [])
        self.assertEqual(personal.run(path, provider, "worker", clock=lambda: 6)["status"], "needs-approval")
        personal.approve_draft(path, "draft-1", 1, "notice-1", "renewed", "host", 30, 6)
        personal.queue_approved(path, "renewed", "host", 6)
        self.assertEqual(personal.dispatch_one(path, provider, "new-worker", clock=lambda: 7)["status"], "sent")
        self.assertEqual(self.rows(target, "SELECT op FROM effects"), [("notice-1",)])
        with self.assertRaises(PermissionError):
            personal.queue_approved(path, "approval-1", "host", 7)

    def test_existing_receipt_can_be_confirmed_after_approval_expiry_without_new_send(self):
        path, target = self.prepared(expires=5)
        with self.assertRaises(TimeoutError):
            personal.dispatch_one(path, LocalProvider(target, lose_reply=True), "first", clock=lambda: 1)
        provider = LocalProvider(target)
        self.assertEqual(personal.dispatch_one(path, provider, "recovery", clock=lambda: 20)["status"], "sent")
        self.assertEqual(provider.calls, [("lookup", "notice-1")])
        self.assertEqual(len(self.rows(target, "SELECT * FROM effects")), 1)

    def test_two_hosts_cannot_ack_a_receipt_for_same_operation_but_another_payload(self):
        first, target = self.prepared()
        self.assertEqual(personal.dispatch_one(first, LocalProvider(target), "first", clock=lambda: 1)["status"], "sent")
        other = self.db("second-host.sqlite")
        personal.save_draft(other, "other-draft", "different-box", "not the first approved body")
        personal.approve_draft(other, "other-draft", 1, "notice-1", "other-approval", "host", 5, 0)
        personal.queue_approved(other, "other-approval", "host", 0)
        for now in [1, 20]:
            provider = LocalProvider(target)
            with self.assertRaises(ValueError):
                personal.dispatch_one(other, provider, "second", clock=lambda: now)
            self.assertEqual(provider.calls, [("lookup", "notice-1")])
            self.assertEqual(personal.inspect(other)["dispatch_jobs"][0]["state"], "pending")
        self.assertEqual(len(self.rows(target, "SELECT * FROM effects")), 1)
        same = self.db("same-intent-new-host.sqlite")
        personal.save_draft(same, "restored-draft", "fictional-inbox", "带上营地手册")
        personal.approve_draft(same, "restored-draft", 1, "notice-1", "restored-approval", "host", 5, 0)
        personal.queue_approved(same, "restored-approval", "host", 0)
        provider = LocalProvider(target)
        self.assertEqual(personal.dispatch_one(same, provider, "recovery", clock=lambda: 20)["status"], "sent")
        self.assertEqual(provider.calls, [("lookup", "notice-1")])
        self.assertEqual(len(self.rows(target, "SELECT * FROM effects")), 1)

    def test_both_lookup_and_send_receipts_need_exact_operation_payload_and_receipt_facts(self):
        for source in ["lookup", "send"]:
            for changed in ["operation", "payload", "empty", "extra"]:
                path = self.db(source + changed + ".sqlite")
                personal.save_draft(path, "draft", "box", "notice")
                personal.approve_draft(path, "draft", 1, "op", "grant", "host", 100, 0)
                personal.queue_approved(path, "grant", "host", 0)
                record = {"op_id": "op", "payload": json.dumps({"to":"box","body":"notice"}, ensure_ascii=False,sort_keys=True,separators=(",",":")), "receipt": "stored-receipt"}
                if changed == "operation": record["op_id"] = "different-op"
                if changed == "payload": record["payload"] = "another-intent"
                if changed == "empty": record["receipt"] = ""
                if changed == "extra": record["passed"] = True
                class Provider:
                    def lookup(self, op): return record if source == "lookup" else None
                    def send(self, op, payload): return record
                with self.assertRaises(ValueError):
                    personal.dispatch_one(path, Provider(), "worker", clock=lambda: 1)
                self.assertEqual(personal.inspect(path)["dispatch_jobs"][0]["state"], "pending")

    def test_same_name_two_real_workers_fence_old_ack_after_takeover(self):
        path, target = self.prepared()
        first = self.process('''
import json
from durable_learning import personal
from durable_learning.personal_provider import LocalReceiptProvider
class Provider(LocalReceiptProvider):
    def send(self, op, payload):
        receipt=super().send(op, payload)
        print("effect-committed", flush=True)
        sys.stdin.readline()
        return receipt
ticks=iter([0,0,11])
print(json.dumps(personal.dispatch_one(sys.argv[2],Provider(sys.argv[3]),"same-worker",clock=lambda:next(ticks),ttl=10)),flush=True)
''', path, target)
        self.assertEqual(self.line(first), "effect-committed")
        second = self.process('''
import json
from durable_learning import personal
from durable_learning.personal_provider import LocalReceiptProvider
class Provider(LocalReceiptProvider):
    def send(self, op, payload): raise AssertionError("do not repeat an observed effect")
calls = 0
def clock():
    global calls
    calls += 1
    if calls == 1: return 10
    print("new-generation-held", flush=True)
    sys.stdin.readline()
    return 11
print(json.dumps(personal.dispatch_one(sys.argv[2],Provider(sys.argv[3]),"same-worker",clock=clock,ttl=10)),flush=True)
''', path, target)
        self.assertEqual(self.line(second), "new-generation-held")
        first.stdin.write("go\n"); first.stdin.flush()
        self.assertEqual(json.loads(self.line(first))["status"], "stale")
        first.wait(timeout=5); self.assertEqual(first.returncode, 0, first.stderr.read())
        self.assertEqual(personal.inspect(path)["dispatch_jobs"][0]["state"], "pending")
        second.stdin.write("go\n"); second.stdin.flush()
        self.assertEqual(json.loads(self.line(second))["status"], "sent")
        second.wait(timeout=5); self.assertEqual(second.returncode, 0, second.stderr.read())
        job = personal.inspect(path)["dispatch_jobs"][0]
        self.assertEqual((job["state"], job["generation"], job["owner"]), ("sent", 2, None))
        self.assertEqual(len(self.rows(target, "SELECT * FROM effects")), 1)

    def test_lease_expiring_during_lookup_never_starts_an_unqualified_effect(self):
        path, target = self.prepared()
        ticks = iter([0, 10])
        provider = LocalProvider(target)
        self.assertEqual(personal.dispatch_one(path, provider, "worker", clock=lambda: next(ticks, 10), ttl=10)["status"], "stale")
        self.assertEqual(provider.calls, [("lookup", "notice-1")])
        self.assertEqual(self.rows(target, "SELECT * FROM effects"), [])

    def test_current_payload_and_consumed_host_approval_are_rechecked_at_actual_effect_boundary(self):
        path, target = self.prepared()
        class Provider(LocalProvider):
            def lookup(provider, op):
                result = super().lookup(op)
                db = sqlite3.connect(path)
                try:
                    db.execute("UPDATE drafts SET body='changed behind the host' WHERE draft_id='draft-1'")
                    db.commit()
                finally:
                    db.close()
                return result
        provider = Provider(target)
        with self.assertRaises(PermissionError):
            personal.dispatch_one(path, provider, "worker", clock=lambda: 1)
        self.assertEqual(provider.calls, [("lookup", "notice-1")])
        self.assertEqual(self.rows(target, "SELECT * FROM effects"), [])

    def test_invalid_receipt_never_marks_sent_or_becomes_code_passed(self):
        for index, value in enumerate([True, "", {"passed": True}]):
            path = self.db(str(index) + ".sqlite")
            personal.save_draft(path, "draft", "box", "notice")
            personal.approve_draft(path, "draft", 1, "op", "grant", "host", 100, 0)
            personal.queue_approved(path, "grant", "host", 0)
            class Provider:
                def lookup(self, op): return None
                def send(self, op, payload): return value
            with self.assertRaises(ValueError):
                personal.dispatch_one(path, Provider(), "worker", clock=lambda: 1)
            self.assertEqual(personal.inspect(path)["dispatch_jobs"][0]["state"], "pending")

    def test_bounded_host_counts_failed_attempts_and_does_not_claim_completion(self):
        path, _ = self.prepared()
        calls = []
        class Provider:
            def lookup(self, op): calls.append(op); raise OSError("unavailable")
            def send(self, op, payload): raise AssertionError("do not send after failed lookup")
        result = personal.run(path, Provider(), "worker", clock=lambda: 1, max_steps=3)
        self.assertEqual(result["status"], "budget-exhausted")
        self.assertEqual(result["steps"], 3)
        self.assertEqual(calls, ["notice-1"] * 3)
        self.assertEqual(personal.inspect(path)["dispatch_jobs"][0]["state"], "pending")
        for value in [True, 0, 41, 2.0]:
            with self.assertRaises(ValueError):
                personal.run(path, Provider(), "worker", max_steps=value)

    def test_original_provider_failure_survives_local_checkpoint_failure(self):
        path, target = self.prepared()
        failure = OSError("unknown provider result")
        class Provider(LocalProvider):
            def send(provider, op, payload):
                db = sqlite3.connect(path)
                try:
                    db.execute("CREATE TRIGGER block_release BEFORE UPDATE ON dispatch_jobs BEGIN SELECT RAISE(ABORT, 'release refused'); END")
                finally:
                    db.close()
                raise failure
        caught = None
        try:
            personal.dispatch_one(path, Provider(target), "worker", clock=lambda: 1)
        except BaseException as error:
            caught = error
        self.assertIs(caught, failure)
        self.assertIsInstance(caught.checkpoint_error, sqlite3.IntegrityError)
        self.assertEqual(personal.inspect(path)["dispatch_jobs"][0]["state"], "pending")


if __name__ == "__main__":
    unittest.main(verbosity=2)
