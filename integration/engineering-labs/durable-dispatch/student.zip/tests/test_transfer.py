"""Public behavior tests for an unfamiliar capacity-and-notification challenge."""
import json
import sqlite3
import unittest

from durable_learning import registration, outbox, receiver
from tests.test_durable import DurableCase


class RegistrationTests(DurableCase):
    def test_sqlite_capacity_range_is_explicit_before_creating_database(self):
        high = self.db("high.sqlite")
        registration.create_event(high, "large", (1 << 63) - 1)
        self.assertEqual(self.rows(high, "SELECT capacity FROM events"), [((1 << 63) - 1,)])
        bad = self.db("too-large.sqlite")
        caught = None
        try:
            registration.create_event(bad, "bad", 1 << 63)
        except BaseException as error:
            caught = error
        self.assertIsInstance(caught, ValueError)
        self.assertFalse(bad.exists())

    def test_capacity_is_retained_and_boolean_or_invalid_inputs_do_not_create_database(self):
        path = self.db()
        registration.create_event(path, "camp", 2)
        registration.create_event(path, "camp", 2)
        with self.assertRaises(ValueError):
            registration.create_event(path, "camp", 5)
        self.assertEqual(self.rows(path, "SELECT * FROM events"), [("camp", 2)])
        for index, (event, capacity) in enumerate([("", 1), (True, 1), ("camp", True), ("camp", -1), ("camp", 1.0)]):
            invalid = self.db("invalid-" + str(index) + ".sqlite")
            with self.assertRaises(ValueError):
                registration.create_event(invalid, event, capacity)
            self.assertFalse(invalid.exists())

    def test_full_capacity_replay_conflicts_and_per_event_counts(self):
        path = self.db()
        registration.create_event(path, "camp", 1)
        registration.create_event(path, "walk", 1)
        self.assertIs(registration.register(path, "camp", "one", "皮皮"), True)
        self.assertIs(registration.register(path, "camp", "two", "汤圆"), False)
        self.assertIs(registration.register(path, "camp", "one", "皮皮"), True)
        for event, op, attendee in [("camp", "one", "汤圆"), ("walk", "one", "皮皮"), ("camp", "different", "皮皮"), ("missing", "new", "汤圆")]:
            with self.assertRaises(ValueError):
                registration.register(path, event, op, attendee)
        self.assertIs(registration.register(path, "walk", "walk-op", "皮皮"), True)
        self.assertEqual(self.rows(path, "SELECT op, event_id, attendee FROM bookings ORDER BY op"), [("one", "camp", "皮皮"), ("walk-op", "walk", "皮皮")])
        self.assertEqual(len(self.rows(path, "SELECT * FROM outbox")), 2)

    def test_zero_capacity_and_invalid_request_never_add_notices(self):
        path = self.db()
        registration.create_event(path, "closed", 0)
        self.assertIs(registration.register(path, "closed", "op", "皮皮"), False)
        for event, op, attendee in [("closed", "", "皮皮"), ("closed", "op", {}), (True, "op", "皮皮")]:
            with self.assertRaises(ValueError):
                registration.register(path, event, op, attendee)
        self.assertEqual(self.rows(path, "SELECT * FROM bookings"), [])
        self.assertEqual(self.rows(path, "SELECT * FROM outbox"), [])

    def test_failed_notice_insert_cannot_take_a_seat(self):
        path = self.db()
        registration.create_event(path, "camp", 1)
        db = sqlite3.connect(path)
        try:
            db.execute("CREATE TRIGGER reject_notice BEFORE INSERT ON outbox BEGIN SELECT RAISE(ABORT, 'notice blocked'); END")
        finally:
            db.close()
        with self.assertRaises(sqlite3.IntegrityError):
            registration.register(path, "camp", "op", "皮皮")
        self.assertEqual(self.rows(path, "SELECT * FROM bookings"), [])
        self.assertEqual(self.rows(path, "SELECT * FROM outbox"), [])

    def test_replay_after_delivery_keeps_receipt_and_one_effect(self):
        path, target = self.db(), self.db("receiver.sqlite")
        registration.create_event(path, "camp", 1)
        registration.register(path, "camp", "op", "皮皮")
        payload = json.dumps({"event": "camp", "attendee": "皮皮"}, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        self.assertEqual(self.rows(path, "SELECT op, payload, state, receipt FROM outbox"), [("op", payload, "pending", None)])
        self.assertEqual(outbox.deliver(path, lambda op, text: receiver.receive(target, op, text)), 1)
        before = self.rows(path, "SELECT * FROM outbox")
        self.assertIs(registration.register(path, "camp", "op", "皮皮"), True)
        self.assertEqual(self.rows(path, "SELECT * FROM outbox"), before)
        self.assertEqual(outbox.deliver(path, lambda *_: self.fail("already delivered")), 0)
        self.assertEqual(self.rows(target, "SELECT op, payload FROM effects"), [("op", payload)])

    def test_real_process_restart_preserves_seat_and_replay(self):
        path = self.db()
        registration.create_event(path, "camp", 1)
        first = self.command('from durable_learning.registration import register\nprint(register(sys.argv[2], "camp", "op", "皮皮"))', path)
        self.assertEqual(first.stdout.strip(), "True")
        second = self.command('from durable_learning.registration import register\nprint(register(sys.argv[2], "camp", "op", "皮皮"))\nprint(register(sys.argv[2], "camp", "other", "汤圆"))', path)
        self.assertEqual(second.stdout.splitlines(), ["True", "False"])
        self.assertEqual(len(self.rows(path, "SELECT * FROM bookings")), 1)

    def test_two_real_processes_compete_for_one_seat(self):
        path = self.db()
        registration.create_event(path, "camp", 1)
        source = '''
import json
from durable_learning.registration import register
print("ready", flush=True)
sys.stdin.readline()
print(json.dumps(register(sys.argv[2], "camp", sys.argv[3], sys.argv[3])), flush=True)
'''
        children = [self.process(source, path, "alpha"), self.process(source, path, "beta")]
        for child in children:
            self.assertEqual(self.line(child), "ready")
        for child in children:
            child.stdin.write("go\n"); child.stdin.flush()
        values = [json.loads(self.line(child)) for child in children]
        for child in children:
            child.wait(timeout=5)
            self.assertEqual(child.returncode, 0, child.stderr.read())
        self.assertEqual(sorted(values), [False, True])
        self.assertEqual(len(self.rows(path, "SELECT * FROM bookings")), 1)
        self.assertEqual(len(self.rows(path, "SELECT * FROM outbox")), 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
