"""阶段九独立迁移。只读本合同设计，不照搬参考实现。

将航次改期文件转换成持久草稿；绝不能自行批准或发送。
"""


def prepare_trip_batch(path, source, batch_id):
    """返回按 draft_id 排序的本批草稿ID列表。

    batch_id 非空str；source为UTF-8 JSON文件，最多65536原始字节、顶层list。
    每行恰有 trip_id/recipient/previous_departure/departure/cancelled 五键。
    前两项非空str；两个时间是非负exact int；cancelled是exact bool。
    同一(trip_id, recipient)重复属于歧义，ValueError；先核完整文件。
    不取消且时间没变的记录无草稿，取消即使时间没变也需通知。
    ID为 'trip-'+sha256(json.dumps([batch_id,trip_id,recipient],
        ensure_ascii=False,separators=(',',':')).encode('utf-8')).hexdigest()。
    正文：取消为'航次 {trip_id} 已取消。'；否则为
    '航次 {trip_id} 由 {previous_departure} 改至 {departure}。'。
    使用personal的drafts表，version=1；不写approvals/jobs，也不产生effect。

    增加 trip_batches(batch_id TEXT PRIMARY KEY, source_sha256 TEXT NOT NULL,
                      draft_ids_json TEXT NOT NULL)。SHA绑定原始文件字节。
    新批次的所有草稿及批记录必须一起提交或一起回滚；不能留下半批。
    相同批号+原文件重放不得增版本、重置授权或重新派送。
    同批号换了文件字节、已有草稿版本/收件人/正文改变，都ValueError并保留原件。
    文件格式/字段错误ValueError，文件I/O和SQLite错误原样传播。
    """
    raise NotImplementedError("独立完成只生成草稿的原子批计划")
