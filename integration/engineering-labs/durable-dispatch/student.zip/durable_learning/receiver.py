"""阶段二。先读 lessons/02-receipts.md。所有 effect 都是本地虚构通知。"""

def receive(path, op, payload):
    """执行一次意图并返回不透明的非空字符串回执。

    op、payload 均为非空 str，坏值在建库前抛 ValueError。
    effects(id INTEGER PRIMARY KEY, op TEXT NOT NULL, payload TEXT NOT NULL)
    receipts(op TEXT PRIMARY KEY, payload TEXT NOT NULL, receipt TEXT NOT NULL)
    同 op/同 payload 返回原回执，不再新增 effect；同 op/不同 payload 抛
    ValueError 且不改旧数据。不同 op 即使 payload 一样也属于不同意图。
    effect 与 receipt 必须原子提交；连接在所有路径关闭。
    本练习的去重记忆是 receipts：删去它不会撤销 effects，重放可再次产生效果。
    """
    raise NotImplementedError("实现持久回执与真实效果的同事务提交")

def lookup(path, op):
    """非空 str op；初始化两表后返回已有 receipt 或 None，不产生 effect。
    坏 op 在建库前抛 ValueError；所有连接关闭。
    """
    raise NotImplementedError("实现只读回执查询")
