"""阶段四。先读 lessons/04-fencing.md。时钟由调用者显式提供。"""

def claim(path, owner, now, ttl=10):
    """竞争一个任务的写入资格，成功返回严格递增的 generation:int，否则 None。

    jobs(id INTEGER PRIMARY KEY, owner TEXT, until REAL NOT NULL,
         generation INTEGER NOT NULL, result TEXT, state TEXT NOT NULL)
    初始化单行 id=1, owner=NULL, until=0, generation=0, result=NULL, state='pending'。
    owner 非空 str；now 有限 int/float 且不为 bool；ttl 有限正 int/float 不为 bool；
    now+ttl 必须有限。坏参数在建库前抛 ValueError。
    只有 pending 且 until<=now 才能接手；接手后 generation 加一，until=now+ttl。
    合法代次最多2**63-1；已到上限的可领取任务 RuntimeError 且不改库，不回绕。
    同名字再次接手也必须新一代。重启不重置代次；两个进程竞争只有一个赢家。
    """
    raise NotImplementedError("实现持久租期与代次竞争")

def publish(path, owner, generation, now, result):
    """仅当 pending、同 owner/代次且 now<until 时写 result 并改 done；返回 None。

    owner 非空 str；generation 为1..2**63-1的 int 非 bool；now 有限 int/float 非 bool；
    result 为 str；坏参数在建库前抛 PermissionError。过期、旧代次、错 owner、已完成均
    PermissionError 且数据库不变。所有连接关闭。
    """
    raise NotImplementedError("让实际写入点拒绝过期持有者")
