"""阶段一。先读 lessons/01-sqlite.md；保留函数接口，自己实现。"""

def save_checkpoint(path, name, text, crash=False):
    """把同一 name/text 同时插入 progress 和 notes，成功返回 None。

    两表均为 (name TEXT PRIMARY KEY, value TEXT NOT NULL)。name 非空 str，
    text 为 str（可以为空），crash 必须是 bool；坏参数在建库前抛 ValueError。
    name 已存在时抛 sqlite3.IntegrityError，原值不改。
    crash=True 在两项写入之间抛含 interrupted 的 RuntimeError，不能留下半份。
    成功、重复、异常均关闭本次连接；已经提交的旧记录必须保留。
    """
    raise NotImplementedError("实现同一事务中的两份记录")
