"""阶段五。先读 lessons/05-approval.md；仅串行、内存中的宿主授权练习。"""
import json

def authorize(grant, actor, action, args, now):
    """验证一次授权、消费 used，成功返回 None。

    args 必须恰有 to/body 两个 str 值；它的标准字符串是
    json.dumps(args, sort_keys=True, allow_nan=False)。grant 是宿主给的 dict，
    至少含 actor/action/args_json/expires_at/used；请求 actor/action 为非空 str，
    与 grant 完全相等，args_json 为前述字符串，expires_at 与 now 均 exact int，
    now<expires_at，used is False。缺字段/坏类型/不匹配均 PermissionError，
    不改 grant/args。不把 grant 中额外无关元数据当成权限。
    """
    raise NotImplementedError("验证精确参数并消费一次授权")

def execute_approved(grant, actor, action, args, now, effect):
    """把刚验证的快照交给 effect，原样返回结果；拒绝时绝不调用 effect。
    effect 失败也保留 used=True，原异常原样传播，避免不确定效果被无条件重放。
    effect 修改收到的 dict 不能反向改请求 args。本包不提供多进程授权服务器。
    """
    raise NotImplementedError("把实际执行绑定到审核过的参数")
