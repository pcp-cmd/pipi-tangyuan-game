"""阶段六。先读 lessons/06-retry-deadline.md；Python 3.11 或以上。"""
import asyncio

class TransientError(Exception):
    """调用者明确声明可重试的临时失败。"""

async def retry(operation, attempts=3, base_delay=0.01, sleep=asyncio.sleep):
    """最多调用 attempts 次；仅 TransientError 可重试。
    attempts 为正 int 非 bool；base_delay 为有限非负 int/float 非 bool；坏值
    在任何 operation/sleep 前 ValueError。两次失败之间等待 base_delay*2**i，
    i 从 0 开始；末次失败后不等待，原异常原样传播。成功保留结果对象身份。
    永久错误与取消立即传播。sleep 是可注入的 async 函数。
    """
    raise NotImplementedError("有限重试，保留真实失败与取消")

async def with_deadline(operation, seconds):
    """用一个总时限包围整个 async operation（包括其中重试等待）。
    seconds 为有限非负 int/float 非 bool；非法先 ValueError。
    到期抛 TimeoutError，并等待被取消工作的 finally 清理完成；不吞取消。
    """
    raise NotImplementedError("整个操作共享一个截止时间")
