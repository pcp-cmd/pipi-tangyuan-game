"""阶段三。先读 lessons/03-outbox.md；发送方与接收方是两个数据库。"""

def enqueue(path, op, payload, crash=False):
    """同事务保存业务订单与待发送消息；返回 None。

    orders(op TEXT PRIMARY KEY, payload TEXT NOT NULL)
    outbox(op TEXT PRIMARY KEY, payload TEXT NOT NULL, state TEXT NOT NULL, receipt TEXT)
    op/payload 非空 str；crash 必须 bool；坏参数在建库前抛 ValueError。
    新消息 state='pending', receipt=NULL。重复同一 op/payload 不改变已存在的
    state/receipt；改 payload 抛 ValueError。存在订单但缺消息/内容或状态不一致时
    抛 RuntimeError，不凭猜测修复。pending 必须 receipt=NULL；sent 必须非空 str 回执。crash=True 在两次写入之间抛 RuntimeError，
    不能留下半份。所有连接关闭；历史订单保留。
    """
    raise NotImplementedError("实现业务记录与待发送记录的原子保存")

def deliver(path, send, crash=False):
    """按 op 字典序串行发送本轮看到的 pending 消息，返回本次确认条数 int。

    send(op, payload) 是调用者提供的边界；调用期间不持有 SQLite 连接。
    返回非空 str 回执才可把本地 pending 改 sent 并记录 receipt；其他值抛
    ValueError，当前项保留 pending。send 的异常原样传播，后续项不发送。
    crash=True 在 send 返回后、本地确认前抛 RuntimeError，当前项仍 pending。
    重试仍用同 op 和 payload；sent 不再发送。crash 必须 bool。
    初始化与 enqueue 相同的表；本函数不承诺多个发送者之间恰好一次调用。
    """
    raise NotImplementedError("实现可恢复的串行发送和确认")
