"""陌生迁移。先完成六阶段，再读 lessons/07-transfer.md；没有完整解法。"""

def create_event(path, event_id, capacity):
    """建立一个容量固定的活动；返回 None。
    event_id 非空 str；capacity 为 0..2**63-1 的 int 非 bool；坏参数在建库前 ValueError。
    events(event_id TEXT PRIMARY KEY, capacity INTEGER NOT NULL)
    bookings(op TEXT PRIMARY KEY, event_id TEXT NOT NULL, attendee TEXT NOT NULL,
             UNIQUE(event_id, attendee))
    outbox(op TEXT PRIMARY KEY, payload TEXT NOT NULL, state TEXT NOT NULL, receipt TEXT)
    重复同容量无副作用；改原容量 ValueError，历史不变。
    """
    raise NotImplementedError("实现容量固定的活动初始化")

def register(path, event_id, op, attendee):
    """提交一个报名意图；有名额且原子落盘返回 True，满员返回 False（exact bool）。
    三个业务参数都为非空 str，坏参数 ValueError。未知活动 ValueError。
    同 op/同活动/同参加者重放 True，即使后来满员，且不重置通知的 sent/receipt。
    同 op 改内容或同活动同参加者换 op 均 ValueError；不同活动容量分别计算。
    新报名与 pending/NULL 通知同事务；payload 严格为
    json.dumps({'event':event_id,'attendee':attendee}, ensure_ascii=False,
               sort_keys=True, separators=(',',':'))。
    零容量不接单。两个真实进程抢最后名额恰有一个 True、一条报名和一条通知。
    发送通知复用 outbox.deliver；本函数本身不执行外部发送。所有连接关闭。
    """
    raise NotImplementedError("独立设计容量、重放与通知的一致性")
