"""Reviewed local adapter. Lookup returns stored intent facts, not caller claims."""
import sqlite3

from . import receiver


class LocalReceiptProvider:
    def __init__(self, path, lose_reply=False):
        if type(lose_reply) is not bool:
            raise ValueError("lose_reply must be boolean")
        self.path = path
        self.lose_reply = lose_reply

    def lookup(self, op):
        receiver.lookup(self.path, op)  # Initializes the documented tables, with no effect.
        db = sqlite3.connect(self.path)
        try:
            row = db.execute("SELECT op,payload,receipt FROM receipts WHERE op=?", (op,)).fetchone()
            return None if row is None else {"op_id": row[0], "payload": row[1], "receipt": row[2]}
        finally:
            db.close()

    def send(self, op, payload):
        receiver.receive(self.path, op, payload)
        if self.lose_reply:
            raise TimeoutError("local fictional effect committed; reply deliberately lost")
        # Read the persisted operation/payload/receipt binding after the actual commit.
        return self.lookup(op)
