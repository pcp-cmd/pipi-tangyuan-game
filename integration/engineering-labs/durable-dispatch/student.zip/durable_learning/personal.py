"""阶段八：持久草稿 → 精确批准 → 有界派送 → 查回执恢复。

先读 lessons/08-personal-host.md。以下表名和列是可观察合同，SQL写法自选。
drafts(draft_id TEXT PRIMARY KEY, version INTEGER, recipient TEXT, body TEXT)
approvals(approval_id TEXT PRIMARY KEY, draft_id TEXT, version INTEGER,
          op_id TEXT, payload_json TEXT, actor TEXT, expires_at REAL, used INTEGER)
dispatch_jobs(op_id TEXT PRIMARY KEY, draft_id TEXT, version INTEGER,
              payload_json TEXT, actor TEXT, approval_id TEXT, state TEXT,
              generation INTEGER, owner TEXT, lease_until REAL,
              receipt TEXT, last_error TEXT)
所有非主键列按用途约束非空，owner/receipt/last_error 未有值时为 NULL。
批准和任务中的 payload_json 使用以下稳定编码：
json.dumps({"to": recipient, "body": body}, ensure_ascii=False,
           sort_keys=True, separators=(",", ":"))。
回调不能在仍持有数据库写事务时执行。自报 passed 不属于完成证据。
"""
import time


def save_draft(path, draft_id, recipient, body, expected_version=0):
    """返回新版本；新草稿 expected_version=0 得到1，之后逐次加1。

    ID/收件人/正文须为非空 str；expected_version 须为非负 exact int。
    版本不匹配 ValueError，原件不变；检查与更新在同一事务。
    某草稿已有任意 dispatch_jobs 时 PermissionError，不可改动已排队意图。
    新意图应使用新的 draft_id。异常时原有草稿/授权/任务完整保留。
    """
    raise NotImplementedError("保存有版本的草稿，拒绝旧版本覆盖")


def approve_draft(path, draft_id, version, op_id, approval_id, actor, expires_at, now):
    """可信宿主在展示并明确批准后调用；返回 approval_id。

    ID/actor 为非空 str；version 正 exact int；now/expires_at 有限 int/float
    且不接收 bool，now < expires_at。缺当前版本或时间不合格 PermissionError。
    持久绑定当前草稿版本、真实 payload、op_id、actor、期限，初始 used=0。
    相同 approval_id 与全部原事实重放可返回原ID；更换其中一项 ValueError。
    此函数不发送，不写 dispatch_jobs，不把模型提议当成批准来源。
    """
    raise NotImplementedError("把实际批准绑定到当前持久草稿")


def queue_approved(path, approval_id, actor, now):
    """重新核对批准、actor、当前草稿版本/内容、期限；成功返回原 op_id。

    无批准、now>=expires_at、坏时钟/身份/当前草稿不匹配 PermissionError。
    同一 op_id 不得绑定不同 draft/version/payload/actor（ValueError）。
    消费批准 used=1 与创建任务在同一事务：任务初始 pending、generation=0、
    owner=NULL、lease_until=0、receipt/last_error=NULL。任一写入失败全部回滚。
    同一已消费批准与同一当前任务重交不重复建任务或重置完成状态。
    新批准可续办同一个未完成且不可变的意图：替换 approval_id、改 pending、
    generation 加1撤销旧工人、清 owner/lease/last_error。sent 不续办。
    旧批准不得借此取得新任务或新批准的权限。
    """
    raise NotImplementedError("原子消费精确批准并登记同一意图")


def inspect(path):
    """返回 drafts/approvals/dispatch_jobs 三个键，各为真实行的 dict 列表。

    分别按 draft_id/approval_id/op_id 排序。新数据库的列表为空。
    读实际持久表，不从先前函数返回值或 passed 字段制造完成状态。
    """
    raise NotImplementedError("读取可独立核对的数据库事实")


def dispatch_one(path, provider, worker, *, clock=time.time, ttl=10):
    """处理至多一个任务；返回 {status, op_id}。

    worker 非空 str；时钟为有限 int/float（非bool），ttl 有限正数且加法有限。
    在同一事务取得按 op_id 排序的首个 pending 且 lease_until<=now 的任务，
    generation 每次加1，记录 owner/lease_until。没有可取任务返回 idle/None。
    任务必须仍匹配已消费批准及当前草稿；不匹配 PermissionError。

    先在事务之外 provider.lookup(op_id)。None 才可能发送：在真正调用 send
    前重新核对 state/owner/generation/lease、当前批准内容和 expires_at。
    旧资格返回 stale；过期则标 blocked、清 owner/lease，返回 approval-expired。
    合格时 provider.send(op_id, payload_json)，重试不得另造 op_id。

    lookup/send 的有效回执恰有 op_id/payload/receipt 三键，前两项必须匹配
    当前任务，receipt 是非空 str；错误/别的意图/自报 passed 均 ValueError。
    只有匹配的持久回执才能确认，即使批准现已过期也无需再次发送。
    确认更新还须匹配当前 owner/generation/state 且 now<lease_until；不再合格
    返回 stale，不覆盖新工人的记录；成功为 sent，存 receipt、清 lease/owner/error。

    回调异常原对象传播；仅清理仍属于本代次的租期，保留 pending 和
    lookup-unconfirmed 或 send-unconfirmed。若该清理也失败，原异常仍是主异常，
    加 checkpoint_error 属性及仅含错误类型的 note，不把未知结果改成完成。
    """
    raise NotImplementedError("在每个实际边界重验资格，再查回执或派送")


def run(path, provider, worker, *, clock=time.time, ttl=10, max_steps=8):
    """有界宿主；max_steps 为1..40的 exact int，否则 ValueError。

    每次 dispatch_one（包括失败尝试）占1步，只把 OSError 转成
    {status:'unconfirmed',errorType:异常类型}；其他异常原样传播。
    保存每步真实 observation，不因错误而缩小分母或偷偷追加尝试。
    idle时读取任务：有pending→waiting-for-lease，有blocked→needs-approval，
    全sent且非空→completed，没有任务→idle。预算用尽为 budget-exhausted。
    返回 {status, steps, observations}；这是运行状态，不是学习成绩。
    """
    raise NotImplementedError("有限次推进，明确未确认、等待与完成")
