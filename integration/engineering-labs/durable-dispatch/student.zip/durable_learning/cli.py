"""A real local workspace driver. No external message is ever sent."""
import argparse
import json
import math
from pathlib import Path
import sqlite3
import sys
import time

from . import checkpoint, receiver, outbox, fenced_store, registration, personal, reminder_plan
from .personal_provider import LocalReceiptProvider


def _tables(path, names):
    if not path.exists():
        return {name: [] for name in names}
    db = sqlite3.connect(path)
    db.row_factory = sqlite3.Row
    try:
        present = {row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
        return {name: [dict(row) for row in db.execute("SELECT * FROM " + name)] if name in present else [] for name in names}
    finally:
        db.close()


def inspect_workspace(workspace):
    return {
        "checkpoint": _tables(workspace / "checkpoint.sqlite", ["progress", "notes"]),
        "sender": _tables(workspace / "sender.sqlite", ["orders", "outbox"]),
        "receiver": _tables(workspace / "receiver.sqlite", ["effects", "receipts"]),
        "leases": _tables(workspace / "leases.sqlite", ["jobs"]),
        "registration": _tables(workspace / "registration.sqlite", ["events", "bookings", "outbox"]),
        "personal": _tables(workspace / "personal.sqlite", ["drafts", "approvals", "dispatch_jobs", "trip_batches"]),
        "personal_receiver": _tables(workspace / "personal-receiver.sqlite", ["effects", "receipts"]),
    }


def parser():
    result = argparse.ArgumentParser(description="本地可靠派送实验：只写专用目录的SQLite，不发真实邮件。")
    result.add_argument("--workspace", type=Path, required=True, help="自己创建的专用实验目录")
    commands = result.add_subparsers(dest="command", required=True)
    commands.add_parser("inspect", help="从数据库独立读取实际表，不信函数自报结果")
    for name in ["checkpoint", "queue"]:
        child = commands.add_parser(name)
        child.add_argument("name")
        child.add_argument("text")
        child.add_argument("--interrupt", action="store_true")
    dispatch = commands.add_parser("dispatch")
    dispatch.add_argument("--lose-reply", action="store_true")
    dispatch.add_argument("--interrupt", action="store_true")
    claim = commands.add_parser("claim")
    claim.add_argument("owner")
    claim.add_argument("now", type=float)
    claim.add_argument("--ttl", type=float, default=10)
    publish = commands.add_parser("publish")
    publish.add_argument("owner")
    publish.add_argument("generation", type=int)
    publish.add_argument("now", type=float)
    publish.add_argument("result")
    event = commands.add_parser("event", help="迁移任务：创建容量固定的营地活动")
    event.add_argument("event_id")
    event.add_argument("capacity", type=int)
    book = commands.add_parser("book", help="迁移任务：占一个名额并登记通知")
    book.add_argument("event_id")
    book.add_argument("operation")
    book.add_argument("attendee")
    notices = commands.add_parser("deliver-bookings", help="迁移任务：派送报名通知")
    notices.add_argument("--lose-reply", action="store_true")
    notices.add_argument("--interrupt", action="store_true")
    draft = commands.add_parser("draft", help="组合工程：持久保存一份有版本的虚构通知草稿")
    draft.add_argument("draft_id"); draft.add_argument("recipient"); draft.add_argument("body")
    draft.add_argument("--expected-version", type=int, default=0)
    approve = commands.add_parser("approve-draft", help="逐项显示实际草稿；只有明确键入批准才写授权")
    approve.add_argument("draft_id"); approve.add_argument("version", type=int)
    approve.add_argument("operation"); approve.add_argument("approval_id")
    approve.add_argument("--actor", default="learner")
    approve.add_argument("--expires-in", type=float, default=300)
    queued = commands.add_parser("queue-approved", help="重新核对当前版本、身份与期限，再消费批准")
    queued.add_argument("approval_id"); queued.add_argument("--actor", default="learner")
    for command in ["personal-send", "personal-run"]:
        worker = commands.add_parser(command, help="组合工程：先查回执，再按当前批准派送或恢复")
        worker.add_argument("--worker", default="local-worker")
        worker.add_argument("--lease-seconds", type=float, default=10)
        worker.add_argument("--lose-reply", action="store_true")
        if command == "personal-run":
            worker.add_argument("--steps", type=int, default=8)
    trips = commands.add_parser("plan-trips", help="陌生迁移：从改期清单原子创建草稿，绝不自动批准")
    trips.add_argument("source", type=Path); trips.add_argument("batch_id")
    return result


def main(argv=None):
    args = parser().parse_args(argv)
    workspace = args.workspace.resolve()
    try:
        workspace.mkdir(parents=True, exist_ok=True)
        if args.command == "inspect":
            value = inspect_workspace(workspace)
        elif args.command == "checkpoint":
            checkpoint.save_checkpoint(workspace / "checkpoint.sqlite", args.name, args.text, args.interrupt)
            value = {"stored": args.name}
        elif args.command == "queue":
            outbox.enqueue(workspace / "sender.sqlite", args.name, args.text, args.interrupt)
            value = {"accepted": args.name}
        elif args.command in {"dispatch", "deliver-bookings"}:
            def send(op, payload):
                receipt = receiver.receive(workspace / "receiver.sqlite", op, payload)
                if args.lose_reply:
                    raise TimeoutError("local provider committed; reply was deliberately lost")
                return receipt
            database = "sender.sqlite" if args.command == "dispatch" else "registration.sqlite"
            value = {"confirmed": outbox.deliver(workspace / database, send, args.interrupt)}
        elif args.command == "event":
            registration.create_event(workspace / "registration.sqlite", args.event_id, args.capacity)
            value = {"event": args.event_id, "capacity": args.capacity}
        elif args.command == "book":
            value = {"accepted": registration.register(workspace / "registration.sqlite", args.event_id, args.operation, args.attendee)}
        elif args.command == "draft":
            value = {"version": personal.save_draft(workspace / "personal.sqlite", args.draft_id, args.recipient, args.body, args.expected_version)}
        elif args.command == "approve-draft":
            if not math.isfinite(args.expires_in) or args.expires_in <= 0:
                raise ValueError("approval duration must be finite and positive")
            drafts = personal.inspect(workspace / "personal.sqlite")["drafts"]
            draft = next((row for row in drafts if row["draft_id"] == args.draft_id and row["version"] == args.version), None)
            if draft is None:
                raise PermissionError("the displayed draft version is no longer current")
            expires = time.time() + args.expires_in
            shown = {**draft, "operation": args.operation, "approval_id": args.approval_id, "actor": args.actor, "expires_at": expires}
            print(json.dumps(shown, ensure_ascii=False, sort_keys=True), file=sys.stderr)
            phrase = "APPROVE " + args.approval_id
            print("只会记录本地虚构通知。确认上述具体内容，请输入 " + phrase + "；其他输入均取消：", file=sys.stderr)
            if input().strip() != phrase:
                raise PermissionError("no explicit host approval was given")
            value = {"approval_id": personal.approve_draft(workspace / "personal.sqlite", args.draft_id, args.version, args.operation, args.approval_id, args.actor, expires, time.time())}
        elif args.command == "queue-approved":
            value = {"op_id": personal.queue_approved(workspace / "personal.sqlite", args.approval_id, args.actor, time.time())}
        elif args.command in {"personal-send", "personal-run"}:
            options = {"ttl": args.lease_seconds}
            if args.command == "personal-run":
                options["max_steps"] = args.steps
            operation = personal.run if args.command == "personal-run" else personal.dispatch_one
            value = operation(workspace / "personal.sqlite", LocalReceiptProvider(workspace / "personal-receiver.sqlite", args.lose_reply), args.worker, **options)
        elif args.command == "plan-trips":
            value = {"draft_ids": reminder_plan.prepare_trip_batch(workspace / "personal.sqlite", args.source, args.batch_id)}
        elif args.command == "claim":
            value = {"generation": fenced_store.claim(workspace / "leases.sqlite", args.owner, args.now, args.ttl)}
        else:
            fenced_store.publish(workspace / "leases.sqlite", args.owner, args.generation, args.now, args.result)
            value = {"published": args.result}
    except (OSError, ValueError, PermissionError, RuntimeError, sqlite3.Error, EOFError) as error:
        print(json.dumps({"errorType": type(error).__name__, "message": str(error)}, ensure_ascii=False), file=sys.stderr)
        return 2
    print(json.dumps(value, ensure_ascii=False, sort_keys=True))
    return 0
