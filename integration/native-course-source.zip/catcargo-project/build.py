from pathlib import Path
import argparse
import shutil
import tempfile
import zipapp

parser = argparse.ArgumentParser(description='把标准库项目打成pyz，无需联网或安装依赖。')
parser.add_argument('output', type=Path)
args = parser.parse_args()
with tempfile.TemporaryDirectory(prefix='catcargo-build-') as temporary:
    stage = Path(temporary)
    shutil.copytree(Path(__file__).parent / 'catcargo', stage / 'catcargo', ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    zipapp.create_archive(stage, args.output, main='catcargo.cli:main')
print(args.output)
