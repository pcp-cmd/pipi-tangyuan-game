import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from catcargo.core import totals
from catcargo.files import build_report


class CargoTests(unittest.TestCase):
    def test_quoted_names_and_returns(self):
        self.assertEqual(totals('item,qty\n"红,蓝",2\n"红,蓝",-1\n'), {'红,蓝': 1})

    def test_malformed_csv_and_header(self):
        for text in ['"item,qty\n', 'item,qty\n"灯,2\n', 'item,qty,extra\na,2,x\n']:
            with self.subTest(text=text), self.assertRaises(ValueError):
                totals(text)

    def test_bad_input_preserves_existing_target(self):
        with tempfile.TemporaryDirectory() as directory:
            source, target = Path(directory) / 'in.csv', Path(directory) / 'out.json'
            source.write_text('item,qty\n灯,no\n', encoding='utf-8')
            target.write_text('keep', encoding='utf-8')
            with self.assertRaises(ValueError):
                build_report(source, target)
            self.assertEqual(target.read_text(encoding='utf-8'), 'keep')

    def test_cli_and_packaged_process(self):
        root = Path(__file__).resolve().parents[1]
        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            source, target = directory / 'in.csv', directory / 'out.json'
            source.write_text('item,qty\n灯,4\n灯,-1\n', encoding='utf-8')
            normal = subprocess.run([sys.executable, '-m', 'catcargo', str(source), str(target)], cwd=root, capture_output=True, text=True)
            self.assertEqual(normal.returncode, 0, normal.stderr)
            self.assertEqual(json.loads(target.read_text(encoding='utf-8')), {'灯': 3})
            package = directory / 'catcargo.pyz'
            subprocess.run([sys.executable, 'build.py', str(package)], cwd=root, check=True, capture_output=True)
            target.unlink()
            packaged = subprocess.run([sys.executable, str(package), str(source), str(target)], cwd=directory, capture_output=True, text=True)
            self.assertEqual(packaged.returncode, 0, packaged.stderr)
            self.assertEqual(json.loads(target.read_text(encoding='utf-8')), {'灯': 3})
            rejected = subprocess.run([sys.executable, str(package)], cwd=directory, capture_output=True, text=True)
            self.assertEqual(rejected.returncode, 2)


if __name__ == '__main__':
    unittest.main()
