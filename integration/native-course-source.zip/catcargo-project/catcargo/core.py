import csv
from io import StringIO


def totals(text: str) -> dict[str, int]:
    reader = csv.DictReader(StringIO(text, newline=''), strict=True)
    result = {}
    try:
        if reader.fieldnames != ['item', 'qty']:
            raise ValueError('expected item,qty header')
        for row in reader:
            if set(row) != {'item', 'qty'} or row['item'] is None or not row['item'].strip() or row['qty'] is None:
                raise ValueError('invalid row')
            result[row['item']] = result.get(row['item'], 0) + int(row['qty'])
    except csv.Error as error:
        raise ValueError('invalid CSV') from error
    return result
