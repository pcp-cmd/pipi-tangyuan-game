import argparse
from pathlib import Path
from .files import build_report


def main(argv=None):
    parser = argparse.ArgumentParser(description='汇总UTF-8货运CSV，写出JSON报告。')
    parser.add_argument('source', type=Path)
    parser.add_argument('target', type=Path)
    args = parser.parse_args(argv)
    try:
        result = build_report(args.source, args.target)
    except (OSError, ValueError) as error:
        parser.exit(2, f'报告未完成：{error}\n')
    print(f'写出 {len(result)} 种货物')
    return 0
