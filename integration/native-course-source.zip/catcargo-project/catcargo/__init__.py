"""Standard-library cargo report teaching project."""
