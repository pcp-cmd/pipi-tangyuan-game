import json
from pathlib import Path
from .core import totals


def build_report(source: Path, target: Path) -> dict[str, int]:
    with source.open(encoding='utf-8', newline='') as handle:
        result = totals(handle.read())
    with target.open('w', encoding='utf-8') as handle:
        json.dump(result, handle, ensure_ascii=False, sort_keys=True)
        handle.write('\n')
    return result
