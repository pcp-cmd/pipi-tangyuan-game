"""Public examples for the changed requirement, not a mastery certificate."""
import json
from pathlib import Path
import tempfile
import unittest
from stockledger.core import prepare_report
from stockledger.files import build_report
from stockledger.cli import main


class ReserveTests(unittest.TestCase):
    def test_exact_boundary_deducts_order_only(self):
        stock, orders = {"水": 9, "笔": 1}, {"水": 5}
        result = prepare_report(stock, orders, reserve=4)
        self.assertEqual(result, {"ready": True, "stock": {"水": 4, "笔": 1}, "missing": {}})
        self.assertIs(result["ready"], True)
        self.assertEqual(stock, {"水": 9, "笔": 1})
        self.assertEqual(orders, {"水": 5})

    def test_shortage_is_shippable_gap_and_no_partial_deduction(self):
        result = prepare_report({"水": 9, "笔": 1}, {"水": 6, "笔": 2}, reserve=4)
        self.assertEqual(result, {"ready": False, "stock": {"水": 9, "笔": 1}, "missing": {"水": 1, "笔": 2}})
        self.assertIs(result["ready"], False)

    def test_zero_and_empty_orders_do_not_require_reserve(self):
        self.assertEqual(prepare_report({}, {}, reserve=5), {"ready": True, "stock": {}, "missing": {}})
        self.assertEqual(prepare_report({"水": 1}, {"纸": 0}, reserve=5),
                         {"ready": True, "stock": {"水": 1, "纸": 0}, "missing": {}})

    def test_bad_reserve_is_not_accepted_even_with_empty_orders(self):
        for value in [-1, True, False, 1.0, "2", None]:
            with self.subTest(value=value), self.assertRaises(ValueError):
                prepare_report({}, {}, reserve=value)

    def test_file_boundary_and_cli_forward_reserve(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            stock, orders, report = root/"s.csv", root/"o.csv", root/"r.json"
            stock.write_text("item,qty\n纸,8\n", encoding="utf-8")
            orders.write_text("item,qty\n纸,6\n", encoding="utf-8")
            expected = {"ready": False, "stock": {"纸": 8}, "missing": {"纸": 1}}
            self.assertEqual(build_report(stock, orders, report, reserve=3), expected)
            self.assertEqual(main([str(stock),str(orders),str(report),"--reserve","3"]), 0)
            self.assertEqual(json.loads(report.read_text(encoding="utf-8")), expected)

    def test_bad_reserve_preserves_old_report(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            stock,orders,report=root/"s.csv",root/"o.csv",root/"r.json"
            stock.write_text("item,qty\n纸,8\n",encoding="utf-8")
            orders.write_text("item,qty\n纸,6\n",encoding="utf-8")
            report.write_text("旧交班记录",encoding="utf-8")
            with self.assertRaises(ValueError):
                build_report(stock,orders,report,reserve=-1)
            self.assertEqual(report.read_text(encoding="utf-8"),"旧交班记录")
            self.assertEqual(main([str(stock),str(orders),str(report),"--reserve","-1"]),2)
            self.assertEqual(report.read_text(encoding="utf-8"),"旧交班记录")


if __name__ == "__main__":
    unittest.main()
