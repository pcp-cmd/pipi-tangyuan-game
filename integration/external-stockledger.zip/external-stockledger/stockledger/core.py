"""Pure data rules: no file access, no print, no global ledger."""


def parse_quantities(text):
    """CSV item,qty -> {name: total}. Preserve names; require nonnegative integers.

    Accept quoted commas/newlines and repeat rows. Reject malformed quotes, wrong headers, row
    widths, blank-only names, blank data rows, bad integer text and negatives with ValueError.
    Python's int(text) syntax is the quantity contract (signs/space are valid).
    """
    raise NotImplementedError("Implement CSV parsing and validation in core.py")


def prepare_report(stock, orders, reserve=0):
    """Return {'ready': bool, 'stock': dict, 'missing': dict} without input mutation.

    reserve must be an exact nonnegative int (bool is not an amount).
    For each ordered item, only max(stock quantity - reserve, 0) can be shipped.
    Missing means additional shippable units needed for that order. An order of
    zero needs no units, even when the item is absent or already below reserve.
    If any shortage exists, report all positive gaps and retain stock values.
    Otherwise deduct all order quantities in a new stock dict. Zero quantities
    remain meaningful; an ordered zero-quantity absent item becomes a zero key.
    On success, deduct the actual order only, never the reserve itself.
    """
    raise NotImplementedError("Implement the all-or-nothing decision in core.py")
