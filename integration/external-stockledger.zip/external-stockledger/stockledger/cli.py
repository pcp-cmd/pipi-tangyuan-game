"""CLI arguments are text; main translates errors into process status."""
import argparse
from .files import build_report


def main(argv=None):
    parser = argparse.ArgumentParser(description="Build an inventory decision report")
    parser.add_argument("stock", help="UTF-8 stock CSV")
    parser.add_argument("orders", help="UTF-8 orders CSV")
    parser.add_argument("report", help="output JSON")
    parser.add_argument("--reserve", type=int, default=0, help="nonnegative safety stock per ordered item")
    args = parser.parse_args(argv)
    # Implement: pass args.reserve to build_report exactly once. Return 0 on success. On ValueError
    # or OSError, print a useful diagnostic to sys.stderr and return 2.
    # Do not hide unrelated programming errors (such as NotImplementedError).
    raise NotImplementedError("Connect CLI to the report builder in cli.py")
